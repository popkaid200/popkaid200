import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "users_db.json");

// Middleware
app.use(express.json());

// Helper to hash password
function hashPassword(password: string) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

// Helper to read database
interface User {
  username: string;
  passwordHash: string;
  highScore: number;
  joinedAt: string;
  lastPlayedAt?: string;
}

function readDB(): User[] {
  try {
    if (!fs.existsSync(DB_FILE)) {
      // Seed with some awesome high-scoring pro players for immersion!
      const seedUsers: User[] = [
        {
          username: "CyberSentinel",
          passwordHash: hashPassword("proPass123"),
          highScore: 85,
          joinedAt: new Date().toISOString(),
        },
        {
          username: "NeonReaper",
          passwordHash: hashPassword("proPass456"),
          highScore: 72,
          joinedAt: new Date().toISOString(),
        },
        {
          username: "ViperGamer",
          passwordHash: hashPassword("proPass789"),
          highScore: 59,
          joinedAt: new Date().toISOString(),
        },
      ];
      fs.writeFileSync(DB_FILE, JSON.stringify(seedUsers, null, 2));
      return seedUsers;
    }
    const data = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    console.error("Error reading db", error);
    return [];
  }
}

// Helper to write database
function writeDB(users: User[]) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(users, null, 2));
  } catch (error) {
    console.error("Error writing db", error);
  }
}

// API Routes
// 1. Register User
app.post("/api/register", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: "กรุณากรอก Username และ Password" });
  }

  const trimmedUsername = username.trim();
  if (trimmedUsername.length < 3) {
    return res.status(400).json({ error: "Username ต้องมีความยาวอย่างน้อย 3 ตัวอักษร" });
  }

  const users = readDB();
  const exists = users.find(
    (u) => u.username.toLowerCase() === trimmedUsername.toLowerCase()
  );

  if (exists) {
    return res.status(400).json({ error: "Username นี้มีผู้ใช้งานแล้ว" });
  }

  const newUser: User = {
    username: trimmedUsername,
    passwordHash: hashPassword(password),
    highScore: 0,
    joinedAt: new Date().toISOString(),
  };

  users.push(newUser);
  writeDB(users);

  res.json({ success: true, message: "ลงทะเบียนสำเร็จแล้ว!" });
});

// 2. Login User
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: "กรุณากรอก Username และ Password" });
  }

  const users = readDB();
  const user = users.find(
    (u) => u.username.toLowerCase() === username.trim().toLowerCase()
  );

  if (!user || user.passwordHash !== hashPassword(password)) {
    return res.status(400).json({ error: "Username หรือ Password ไม่ถูกต้อง" });
  }

  res.json({
    success: true,
    user: {
      username: user.username,
      highScore: user.highScore,
      joinedAt: user.joinedAt,
    },
  });
});

// 3. Save / Update Score
app.post("/api/save-score", (req, res) => {
  const { username, score } = req.body;

  if (!username || typeof score !== "number") {
    return res.status(400).json({ error: "ข้อมูลคะแนนไม่สมบูรณ์" });
  }

  const users = readDB();
  const userIndex = users.findIndex(
    (u) => u.username.toLowerCase() === username.trim().toLowerCase()
  );

  if (userIndex === -1) {
    return res.status(404).json({ error: "ไม่พบผู้ใช้งานนี้" });
  }

  const previousHighScore = users[userIndex].highScore;
  const isNewRecord = score > previousHighScore;

  if (isNewRecord) {
    users[userIndex].highScore = score;
  }
  users[userIndex].lastPlayedAt = new Date().toISOString();

  writeDB(users);

  res.json({
    success: true,
    score,
    previousHighScore,
    isNewRecord,
    highScore: users[userIndex].highScore,
  });
});

// 4. Get Leaderboard
app.get("/api/leaderboard", (req, res) => {
  const users = readDB();
  // Sort by high score descending
  const leaderboard = users
    .map((u) => ({
      username: u.username,
      highScore: u.highScore,
      joinedAt: u.joinedAt,
    }))
    .sort((a, b) => b.highScore - a.highScore)
    .slice(0, 10); // top 10

  res.json(leaderboard);
});

// Setup Vite Dev Server / Static Asset Serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`E-Sports Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

export interface UserSession {
  username: string;
  highScore: number;
  joinedAt: string;
}

export interface LeaderboardEntry {
  username: string;
  highScore: number;
  joinedAt: string;
}

export interface PHPFile {
  name: string;
  path: string;
  description: string;
  language: "php" | "sql" | "markdown" | "text";
}

export const PHP_FILES_LIST: PHPFile[] = [
  {
    name: "db.php",
    path: "/php-xampp/db.php",
    description: "ไฟล์เชื่อมต่อฐานข้อมูล MySQL ด้วย PDO และเปิดโหมดดักจับ Exception",
    language: "php"
  },
  {
    name: "schema.sql",
    path: "/php-xampp/schema.sql",
    description: "คำสั่งสร้างฐานข้อมูล esports_db ตาราง users และใส่ข้อมูลผู้เล่นจำลองระดับสูง",
    language: "sql"
  },
  {
    name: "index.php",
    path: "/php-xampp/index.php",
    description: "หน้าแรกของเว็บไซต์ มีเนื้อหาเกริ่นนำประวัติทีมและฟอร์มสำหรับ Login เข้าสู่ระบบ",
    language: "php"
  },
  {
    name: "register.php",
    path: "/php-xampp/register.php",
    description: "หน้าลงทะเบียนผู้สมัครใหม่ พร้อมระบบตรวจสอบการซ้ำซ้อนและการ Hash รหัสผ่าน (Bcrypt) เพื่อความปลอดภัย",
    language: "php"
  },
  {
    name: "game.php",
    path: "/php-xampp/game.php",
    description: "หน้าประลอง AR มินิเกมจับกล้องเว็บแคมดักจับตำแหน่งมือผู้เล่น แตะดาวสะสมคะแนน และมีตารางผู้นำแสดงคู่กัน",
    language: "php"
  },
  {
    name: "save_score.php",
    path: "/php-xampp/save_score.php",
    description: "API แบบ POST สำหรับประมวลผล เปรียบเทียบ และอัปเดตคะแนนสถิติสูงสุด (High Score) ของผู้เล่นใน MySQL",
    language: "php"
  },
  {
    name: "get_leaderboard_api.php",
    path: "/php-xampp/get_leaderboard_api.php",
    description: "API ดึงสถิติผู้เล่น 10 อันดับแรกส่งกลับเป็น JSON เพื่อนำมารีเฟรชตารางจัดอันดับในเกมสดๆ",
    language: "php"
  },
  {
    name: "logout.php",
    path: "/php-xampp/logout.php",
    description: "ไฟล์ทำลาย Session และออกจากระบบอย่างปลอดภัย",
    language: "php"
  },
  {
    name: "readme.txt",
    path: "/php-xampp/readme.txt",
    description: "คู่มือแนะแนวการติดตั้ง รัน Apache/MySQL บน XAMPP และนำระบบขึ้นทดสอบสั้นๆ",
    language: "text"
  }
];

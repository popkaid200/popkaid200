import React, { useState, useEffect } from "react";
import { 
  Trophy, Gamepad2, LogOut, UserPlus, LogIn, Code, AlertCircle, 
  Check, Sparkles, Shield, Cpu, ChevronRight, Zap, Play, Terminal 
} from "lucide-react";
import { UserSession, LeaderboardEntry } from "./types";
import GameArena from "./components/GameArena";
import DeveloperHub from "./components/DeveloperHub";

export default function App() {
  // Screen and session management
  const [activeTab, setActiveTab] = useState<"demo" | "code">("demo");
  const [demoScreen, setDemoScreen] = useState<"landing" | "register" | "game">("landing");
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  // Form states
  const [loginUsername, setLoginUsername] = useState<string>("");
  const [loginPassword, setLoginPassword] = useState<string>("");
  const [loginError, setLoginError] = useState<string>("");
  const [loginSuccess, setLoginSuccess] = useState<string>("");

  const [regUsername, setRegUsername] = useState<string>("");
  const [regPassword, setRegPassword] = useState<string>("");
  const [regConfirmPassword, setRegConfirmPassword] = useState<string>("");
  const [regError, setRegError] = useState<string>("");

  // Load user session from localStorage and load leaderboard on mount
  useEffect(() => {
    const savedUser = localStorage.getItem("esports_session");
    if (savedUser) {
      const parsed = JSON.parse(savedUser);
      setCurrentUser(parsed);
      setDemoScreen("game");
    }
    refreshLeaderboard();
  }, []);

  // Fetch leaderboard statistics from Express server API
  const refreshLeaderboard = () => {
    fetch("/api/leaderboard")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setLeaderboard(data);
        }
      })
      .catch((err) => {
        console.error("ล้มเหลวในการดึงบอร์ดคะแนน", err);
      });
  };

  // Login handler
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoginSuccess("");

    if (!loginUsername || !loginPassword) {
      setLoginError("กรุณากรอกข้อมูลให้ครบทุกช่อง");
      return;
    }

    fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: loginUsername, password: loginPassword }),
    })
      .then((res) => {
        if (!res.ok) {
          return res.json().then((err) => {
            throw new Error(err.error || "Login ล้มเหลว");
          });
        }
        return res.json();
      })
      .then((data) => {
        if (data.success && data.user) {
          const sessionUser: UserSession = {
            username: data.user.username,
            highScore: data.user.highScore,
            joinedAt: data.user.joinedAt,
          };
          setCurrentUser(sessionUser);
          localStorage.setItem("esports_session", JSON.stringify(sessionUser));
          setDemoScreen("game");
          setLoginUsername("");
          setLoginPassword("");
        }
      })
      .catch((err: any) => {
        setLoginError(err.message);
      });
  };

  // Register handler
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError("");

    if (!regUsername || !regPassword || !regConfirmPassword) {
      setRegError("กรุณากรอกข้อมูลให้ครบถ้วนทุกช่อง");
      return;
    }

    if (regUsername.trim().length < 3) {
      setRegError("Username ต้องมีความยาวอย่างน้อย 3 ตัวอักษร");
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError("รหัสผ่านทั้งสองช่องไม่ตรงกัน");
      return;
    }

    fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: regUsername, password: regPassword }),
    })
      .then((res) => {
        if (!res.ok) {
          return res.json().then((err) => {
            throw new Error(err.error || "การลงทะเบียนล้มเหลว");
          });
        }
        return res.json();
      })
      .then((data) => {
        if (data.success) {
          setLoginSuccess("ลงทะเบียนสำเร็จแล้ว! กรุณาเข้าสู่ระบบด้วยบัญชีของคุณ");
          setDemoScreen("landing");
          setRegUsername("");
          setRegPassword("");
          setRegConfirmPassword("");
          refreshLeaderboard();
        }
      })
      .catch((err: any) => {
        setRegError(err.message);
      });
  };

  // Logout handler
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("esports_session");
    setDemoScreen("landing");
  };

  // Update high score in active local session
  const updateHighScore = (newScore: number) => {
    if (currentUser) {
      const updated = { ...currentUser, highScore: newScore };
      setCurrentUser(updated);
      localStorage.setItem("esports_session", JSON.stringify(updated));
    }
  };

  return (
    <div className="min-h-screen bg-cyber-dark text-gray-200 font-sans selection:bg-cyber-accent/30 selection:text-white flex flex-col scanlines">
      
      {/* Top Main Persistent Header - Switch between Preview Portal and Source Code */}
      <header className="bg-[#0b0c12] border-b-2 border-cyber-light sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 py-3">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center space-x-3">
            <div className="p-1.5 bg-cyber-accent/10 rounded-xl border border-cyber-accent/20">
              <Gamepad2 className="w-6 h-6 text-cyber-accent animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-xl font-black font-display tracking-wider text-white">NEXUS</span>
                <span className="text-xs bg-cyber-pink text-white px-1.5 py-0.5 rounded font-display font-bold tracking-widest">COVENANT</span>
              </div>
              <p className="text-[10px] text-gray-500 font-display tracking-wider uppercase">E-Sports Recruitment Portal</p>
            </div>
          </div>

          {/* Toggle between Interactive Demo and XAMPP Source Code */}
          <div className="flex items-center bg-cyber-dark p-1 rounded-xl border border-cyber-light max-w-md w-full md:w-auto">
            <button
              onClick={() => setActiveTab("demo")}
              className={`flex-1 md:flex-none flex items-center justify-center space-x-2 px-6 py-2.5 rounded-lg text-xs font-bold font-display uppercase tracking-widest transition cursor-pointer ${
                activeTab === "demo"
                  ? "bg-gradient-to-r from-cyber-accent to-cyber-blue text-cyber-dark font-black shadow-lg"
                  : "text-gray-400 hover:text-white"
              }`}
              id="tab-play-demo"
            >
              <Gamepad2 className="w-4 h-4" />
              <span>🎮 เล่นจำลองระบบ</span>
            </button>

            <button
              onClick={() => setActiveTab("code")}
              className={`flex-1 md:flex-none flex items-center justify-center space-x-2 px-6 py-2.5 rounded-lg text-xs font-bold font-display uppercase tracking-widest transition cursor-pointer ${
                activeTab === "code"
                  ? "bg-gradient-to-r from-cyber-pink to-purple-600 text-white font-black shadow-lg"
                  : "text-gray-400 hover:text-white"
              }`}
              id="tab-php-code"
            >
              <Code className="w-4 h-4" />
              <span>💻 โค้ด XAMPP (PHP)</span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 py-8">
        {activeTab === "demo" ? (
          /* ========================================================
             DEMO TAB: RUNS INTERACTIVE FULL-STACK PORTAL SIMULATOR
             ======================================================== */
          <div className="w-full">
            {demoScreen === "landing" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                {/* Left panel: Lore & recruitment details */}
                <div className="lg:col-span-7 space-y-6">
                  <div className="inline-flex items-center space-x-2 bg-cyber-accent/10 border border-cyber-accent/30 px-3 py-1 rounded-full text-[10px] text-cyber-accent font-display tracking-widest">
                    <span className="w-2 h-2 rounded-full bg-cyber-accent animate-ping"></span>
                    <span>RECRUITMENT STAGE ACTIVE</span>
                  </div>

                  <h1 className="text-4xl md:text-5xl font-black font-display tracking-tight text-white leading-tight">
                    ก้าวสู่การเป็นนักกีฬา <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyber-accent via-cyber-blue to-cyber-pink glow-accent">
                      E-SPORTS มืออาชีพ
                    </span>
                  </h1>

                  <p className="text-gray-400 text-sm md:text-base leading-relaxed">
                    ยินดีต้อนรับสู่ <span className="text-white font-bold font-display">NEXUS COVENANT</span> ทีมสัญชาติไทยระดับแนวหน้า 
                    เราไม่เพียงแค่มองหาคนเล่นเกมเก่ง แต่เรากำลังเฟ้นหาผู้มีความสามารถที่มี "สมาธิ" และ "การตอบสนองขั้นสูง" (Reflex) 
                    เพื่อมาร่วมทีมลุยศึกระดับประเทศและชิงแชมป์เอเชียในปีนี้!
                  </p>

                  {/* High stats blocks */}
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="bg-cyber-gray p-4 rounded-xl border border-cyber-light flex items-center space-x-3.5">
                      <Cpu className="w-8 h-8 text-cyber-accent shrink-0" />
                      <div>
                        <div className="text-white font-display text-lg font-bold">120+ fps</div>
                        <div className="text-[10px] text-gray-500 uppercase font-display tracking-wider">Reflex Threshold</div>
                      </div>
                    </div>
                    <div className="bg-cyber-gray p-4 rounded-xl border border-cyber-light flex items-center space-x-3.5">
                      <Sparkles className="w-8 h-8 text-cyber-blue shrink-0 animate-pulse" />
                      <div>
                        <div className="text-white font-display text-lg font-bold">฿1.5M+</div>
                        <div className="text-[10px] text-gray-500 uppercase font-display tracking-wider">Prize Pool Share</div>
                      </div>
                    </div>
                  </div>

                  {/* Quick visual steps */}
                  <div className="p-5 bg-cyber-light/10 rounded-xl border border-cyber-blue/20">
                    <h3 className="text-white font-bold font-display text-xs uppercase mb-3 flex items-center gap-1.5">
                      <span className="text-cyber-blue text-xs">●</span> ขั้นตอนการสมัครและทดสอบความสามารถ
                    </h3>
                    <ul className="text-xs text-gray-400 space-y-2.5">
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-cyber-accent shrink-0 mt-0.5" />
                        <span>สมัครบัญชีเพื่อเปิดแฟ้มประวัติผู้เล่นของคุณทางแผงด้านขวา</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-cyber-blue shrink-0 mt-0.5" />
                        <span>ล็อกอินเข้าสู่ระบบเพื่อปลดล็อกโมดูลและเริ่มการทดสอบ <strong className="text-cyber-accent">AR Reflex Tester</strong></span>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-cyber-pink shrink-0 mt-0.5" />
                        <span>อนุญาตกล้องเว็บแคม ใช้ท่าทางมือ (Hand Tracking) แตะเป้าหมายดวงดาวเพื่อเก็บคะแนนสะสม</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-cyber-yellow shrink-0 mt-0.5" />
                        <span>ผู้เล่นที่ทำคะแนนสะสมสูงสุด 10 อันดับแรกจะได้รับการพิจารณาคัดเลือกเข้าสู่แคมป์จริงทันที!</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Right panel: Login form */}
                <div className="lg:col-span-5 w-full max-w-md mx-auto">
                  <div className="bg-cyber-gray border-2 border-cyber-light p-8 rounded-2xl box-glow-accent relative">
                    <div className="absolute top-0 right-8 -translate-y-1/2 bg-cyber-accent text-cyber-dark text-[9px] font-display font-black tracking-widest px-3 py-1 rounded-sm uppercase">
                      SECURE SIGN IN
                    </div>

                    <h2 className="text-xl font-black font-display tracking-tight text-white mb-6 uppercase">LOGIN TO PORTAL</h2>

                    {/* Success Alert */}
                    {loginSuccess && (
                      <div className="bg-cyber-accent/10 border border-cyber-accent/30 text-cyber-accent px-4 py-3 rounded-lg text-xs mb-6 flex items-start gap-2">
                        <Check className="w-4 h-4 mt-0.5 shrink-0" />
                        <span>{loginSuccess}</span>
                      </div>
                    )}

                    {/* Error Alert */}
                    {loginError && (
                      <div className="bg-cyber-pink/10 border border-cyber-pink/30 text-cyber-pink px-4 py-3 rounded-lg text-xs mb-6 flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                        <span>{loginError}</span>
                      </div>
                    )}

                    <form onSubmit={handleLogin} className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-display font-bold tracking-wider text-gray-400 uppercase mb-2">Username</label>
                        <input
                          type="text"
                          required
                          value={loginUsername}
                          onChange={(e) => setLoginUsername(e.target.value)}
                          placeholder="กรอก Username ของคุณ"
                          className="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-accent focus:ring-1 focus:ring-cyber-accent outline-none text-white font-mono transition"
                          id="login-username-input"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-display font-bold tracking-wider text-gray-400 uppercase mb-2">Password</label>
                        <input
                          type="password"
                          required
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          placeholder="กรอก Password ของคุณ"
                          className="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-accent focus:ring-1 focus:ring-cyber-accent outline-none text-white font-mono transition"
                          id="login-password-input"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-gradient-to-r from-cyber-accent to-cyber-blue text-cyber-dark font-display font-black text-xs py-4 rounded-xl hover:opacity-95 transition shadow-lg tracking-widest uppercase cursor-pointer"
                        id="btn-login-submit"
                      >
                        ENTER PORTAL
                      </button>
                    </form>

                    <div className="mt-6 pt-6 border-t border-cyber-light text-center">
                      <p className="text-xs text-gray-500">
                        ยังไม่มีบัญชีสมาชิกผู้สมัคร? 
                        <button
                          onClick={() => setDemoScreen("register")}
                          className="text-cyber-accent hover:underline font-bold ml-1.5 cursor-pointer"
                          id="btn-goto-register"
                        >
                          สมัครสมาชิกที่นี่
                        </button>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {demoScreen === "register" && (
              <div className="max-w-md mx-auto py-8">
                <div className="bg-cyber-gray border-2 border-cyber-light p-8 rounded-2xl box-glow-pink relative">
                  <div className="absolute top-0 right-8 -translate-y-1/2 bg-cyber-pink text-white text-[9px] font-display font-black tracking-widest px-3 py-1 rounded-sm uppercase">
                    RECRUIT ACCOUNT
                  </div>

                  <h2 className="text-xl font-black font-display tracking-tight text-white mb-2 uppercase">CREATE IDENTITY</h2>
                  <p className="text-xs text-gray-400 mb-6">สร้างโปรไฟล์ผู้เล่นเพื่อเปิดแฟ้มข้อมูลและเริ่มรับสิทธิ์การทดสอบ</p>

                  {/* Error Alert */}
                  {regError && (
                    <div className="bg-cyber-pink/10 border border-cyber-pink/30 text-cyber-pink px-4 py-3 rounded-lg text-xs mb-6 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>{regError}</span>
                    </div>
                  )}

                  <form onSubmit={handleRegister} className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-display font-bold tracking-wider text-gray-400 uppercase mb-2">Username</label>
                      <input
                        type="text"
                        required
                        value={regUsername}
                        onChange={(e) => setRegUsername(e.target.value)}
                        placeholder="กรอกชื่อผู้ใช้ (ขั้นต่ำ 3 ตัวอักษร)"
                        className="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-pink focus:ring-1 focus:ring-cyber-pink outline-none text-white font-mono transition"
                        id="register-username-input"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-display font-bold tracking-wider text-gray-400 uppercase mb-2">Password</label>
                      <input
                        type="password"
                        required
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="ตั้งรหัสผ่านความปลอดภัย"
                        className="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-pink focus:ring-1 focus:ring-cyber-pink outline-none text-white font-mono transition"
                        id="register-password-input"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-display font-bold tracking-wider text-gray-400 uppercase mb-2">Confirm Password</label>
                      <input
                        type="password"
                        required
                        value={regConfirmPassword}
                        onChange={(e) => setRegConfirmPassword(e.target.value)}
                        placeholder="กรอกรหัสผ่านอีกครั้ง"
                        className="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-pink focus:ring-1 focus:ring-cyber-pink outline-none text-white font-mono transition"
                        id="register-confirm-input"
                      />
                    </div>

                    <div className="text-[10px] text-gray-500 py-1.5 leading-relaxed">
                      ข้อมูลบัญชีการทดสอบและรหัสผ่านจะถูกจัดเก็บแบบเข้ารหัสพาสเวิร์ด (SHA-256 / Bcrypt) ในระบบ Express/MySQL ป้องกันการรั่วไหล 100%
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-cyber-pink to-purple-600 text-white font-display font-black text-xs py-4 rounded-xl hover:opacity-95 transition shadow-lg tracking-widest uppercase cursor-pointer"
                      id="btn-register-submit"
                    >
                      SUBMIT REGISTRATION
                    </button>
                  </form>

                  <div className="mt-6 pt-6 border-t border-cyber-light text-center">
                    <p class="text-xs text-gray-500">
                      มีบัญชีโปรไฟล์อยู่แล้ว? 
                      <button
                        onClick={() => setDemoScreen("landing")}
                        className="text-cyber-accent hover:underline font-bold ml-1.5 cursor-pointer"
                        id="btn-back-to-login"
                      >
                        ล็อกอินเข้าสู่ระบบ
                      </button>
                    </p>
                  </div>
                </div>
              </div>
            )}

            {demoScreen === "game" && currentUser && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Left Panel: Active user session, instructions, and Game arena component (8 columns) */}
                <div className="lg:col-span-8 flex flex-col space-y-6">
                  {/* Active Player HUD */}
                  <div className="bg-[#0b0c12] border-2 border-cyber-light p-6 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-6 box-glow-accent relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-cyber-accent/5 rounded-full blur-2xl pointer-events-none"></div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-xl bg-cyber-accent/10 border-2 border-cyber-accent/30 flex items-center justify-center font-display font-black text-cyber-accent text-lg">
                        NC
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] text-gray-500 tracking-wider uppercase font-display">ACTIVE RECRUIT PROFILE</p>
                        <h3 className="text-lg font-black text-white font-mono flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-cyber-accent animate-pulse"></span>
                          {currentUser.username}
                        </h3>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="text-[10px] text-gray-500 tracking-wider uppercase font-display">YOUR HIGH SCORE</p>
                        <p className="text-2xl font-black text-cyber-accent font-display tracking-tight glow-accent">
                          {currentUser.highScore} <span className="text-xs font-normal text-gray-400">pts</span>
                        </p>
                      </div>

                      <div className="h-10 w-px bg-cyber-light"></div>

                      <button
                        onClick={handleLogout}
                        className="p-3 bg-cyber-pink/15 hover:bg-cyber-pink border border-cyber-pink/30 hover:border-cyber-pink rounded-xl text-cyber-pink hover:text-white transition cursor-pointer flex items-center gap-1.5 text-xs font-bold font-display uppercase tracking-wider"
                        id="btn-logout"
                      >
                        <LogOut className="w-4 h-4" />
                        <span className="hidden sm:inline">LOGOUT</span>
                      </button>
                    </div>
                  </div>

                  {/* Canvas Game Arena Component */}
                  <GameArena 
                    currentUser={currentUser} 
                    onUpdateHighScore={updateHighScore} 
                    onRefreshLeaderboard={refreshLeaderboard} 
                  />
                </div>

                {/* Right Panel: Top pro leaders scoreboard (4 columns) */}
                <div className="lg:col-span-4 space-y-6">
                  <div className="bg-cyber-gray border-2 border-cyber-light p-6 rounded-2xl box-glow-blue">
                    <h3 className="text-sm font-black font-display tracking-widest text-white uppercase border-b border-cyber-light pb-4 mb-4 flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-cyber-yellow" /> TOP CONTENDERS
                    </h3>

                    <div className="space-y-2">
                      {leaderboard.length === 0 ? (
                        <p className="text-xs text-gray-500 py-6 text-center font-mono">กำลังประมวลผลข้อมูลผู้นำ...</p>
                      ) : (
                        leaderboard.map((player, idx) => {
                          const isCurrent = player.username.toLowerCase() === currentUser.username.toLowerCase();
                          const rankColor = 
                            idx === 0 ? "text-cyber-yellow" : 
                            idx === 1 ? "text-cyber-blue" : 
                            idx === 2 ? "text-cyber-pink" : "text-gray-500";
                          
                          return (
                            <div 
                              key={idx}
                              className={`flex items-center justify-between p-3.5 rounded-xl border transition ${
                                isCurrent 
                                  ? "border-cyber-accent bg-cyber-accent/5" 
                                  : "border-cyber-light/40 bg-cyber-dark/40 hover:bg-cyber-light/10"
                              }`}
                            >
                              <div className="flex items-center space-x-3">
                                <span className={`w-6 text-center font-display font-black text-xs ${rankColor}`}>
                                  #{idx + 1}
                                </span>
                                <span className="text-sm font-bold text-white font-mono">{player.username}</span>
                                {isCurrent && (
                                  <span className="text-[8px] bg-cyber-accent text-cyber-dark px-1.5 py-0.5 rounded uppercase font-bold font-display">YOU</span>
                                )}
                              </div>
                              <span className="text-sm font-bold text-cyber-accent font-display">{player.highScore} pts</span>
                            </div>
                          );
                        })
                      )}
                    </div>

                    <div className="mt-6 pt-4 border-t border-cyber-light text-center">
                      <p className="text-[10px] text-gray-500 leading-relaxed uppercase tracking-wider">
                        สถิติตารางผู้นำอัปเดตแบบเรียลไทม์ผ่าน REST APIs ทันทีเมื่อผู้เข้าเล่นทำลายสถิติใหม่สำเร็จ
                      </p>
                    </div>
                  </div>

                  {/* Mini Shield specs */}
                  <div className="bg-cyber-gray/35 border border-cyber-light p-5 rounded-2xl space-y-4">
                    <h4 className="text-xs font-black font-display tracking-wider text-white uppercase flex items-center gap-1.5">
                      <Shield className="w-4 h-4 text-cyber-accent" /> RECRUITMENT REQUIREMENTS
                    </h4>
                    <div className="space-y-2 text-[11px] text-gray-400 leading-relaxed">
                      <p>
                        • ผู้ท้าชิงต้องลงทะเบียนด้วยข้อมูล Username / Password ที่ถูกต้อง
                      </p>
                      <p>
                        • การตรวจจับตำแหน่งมือ AR จะใช้กล้องเว็บแคมดักจับจุดพิกัดในพิกเซลเฟรม (หากไม่มีกล้อง สามารถเล่นด้วยโหมดเมาส์ Fallback)
                      </p>
                      <p>
                        • เมื่อหมดเวลา 30 วินาที คะแนนจะบันทึกตรงสู่ฐานข้อมูล SQLite/MySQL ของผู้ใช้เพื่อคำนวณทำเนียบผู้นำ 10 อันดับแรก
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            )}
          </div>
        ) : (
          /* ========================================================
             CODE TAB: RUNS CYBERPUNK CODE EXPLORER & INSTRUCTIONS
             ======================================================== */
          <div className="w-full">
            <DeveloperHub />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-cyber-light bg-[#08090d] py-8 text-center text-xs text-gray-500 shrink-0 mt-12">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-display font-medium tracking-wider text-gray-400">NEXUS COVENANT E-SPORTS CLUB RECRUITMENT SYSTEM</p>
          <p>© 2026 NEXUS COVENANT. Powered by React, Tailwind, Handtrack.js, and PHP/MySQL for XAMPP.</p>
        </div>
      </footer>

    </div>
  );
}

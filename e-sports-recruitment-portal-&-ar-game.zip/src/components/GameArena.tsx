import React, { useEffect, useRef, useState } from "react";
import { Play, RotateCcw, Video, MousePointer, ShieldAlert, Award, Star } from "lucide-react";
import { UserSession } from "../types";

interface GameArenaProps {
  currentUser: UserSession | null;
  onUpdateHighScore: (newScore: number) => void;
  onRefreshLeaderboard: () => void;
}

interface GameStar {
  x: number;
  y: number;
  size: number;
  pulse: number;
  pulseSpeed: number;
  color: string;
  angle: number;
  spinSpeed: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  decay: number;
  color: string;
}

export default function GameArena({ currentUser, onUpdateHighScore, onRefreshLeaderboard }: GameArenaProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Game state
  const [isModelLoaded, setIsModelLoaded] = useState<boolean>(false);
  const [modelLoadingError, setModelLoadingError] = useState<boolean>(false);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [isMouseActive, setIsMouseActive] = useState<boolean>(false);
  const [isGameRunning, setIsGameRunning] = useState<boolean>(false);
  const [showStartOverlay, setShowStartOverlay] = useState<boolean>(false);
  const [showGameOverOverlay, setShowGameOverOverlay] = useState<boolean>(false);
  const [hudScore, setHudScore] = useState<number>(0);
  const [hudTimer, setHudTimer] = useState<number>(30);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveResultMsg, setSaveResultMsg] = useState<string>("");
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);

  // Backend tracking variables (use refs inside requestAnimationFrame loops to prevent closure stale values)
  const scoreRef = useRef<number>(0);
  const timerRef = useRef<number>(30);
  const pointerRef = useRef<{ x: number; y: number; active: boolean }>({ x: 320, y: 240, active: false });
  const starsRef = useRef<GameStar[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const modelRef = useRef<any>(null);
  const animationFrameId = useRef<number | null>(null);
  const gameIntervalId = useRef<any>(null);
  const trackingIntervalId = useRef<any>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Dynamically load Handtrack.js script
  useEffect(() => {
    const scriptId = "handtrack-cdn-script";
    let script = document.getElementById(scriptId) as HTMLScriptElement;

    const initializeModel = () => {
      const handtrack = (window as any).handtrack;
      if (!handtrack) {
        setModelLoadingError(true);
        return;
      }

      const modelParams = {
        flipHorizontal: true,
        maxNumBoxes: 1,
        iouThreshold: 0.5,
        scoreThreshold: 0.55,
      };

      handtrack
        .load(modelParams)
        .then((lmodel: any) => {
          modelRef.current = lmodel;
          setIsModelLoaded(true);
          setShowStartOverlay(true);
        })
        .catch((err: any) => {
          console.error("โมเดลล้มเหลว", err);
          setModelLoadingError(true);
        });
    };

    if (script) {
      if ((window as any).handtrack) {
        initializeModel();
      } else {
        script.addEventListener("load", initializeModel);
      }
    } else {
      script = document.createElement("script");
      script.id = scriptId;
      script.src = "https://cdn.jsdelivr.net/npm/handtrackjs/dist/handtrack.min.js";
      script.async = true;
      document.head.appendChild(script);
      script.addEventListener("load", initializeModel);
    }

    return () => {
      // Clean up running animations & intervals when components unmount
      if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
      if (gameIntervalId.current) clearInterval(gameIntervalId.current);
      if (trackingIntervalId.current) clearInterval(trackingIntervalId.current);

      const handtrack = (window as any).handtrack;
      if (handtrack && isCameraActive && videoRef.current) {
        try {
          handtrack.stopVideo(videoRef.current);
        } catch (e) {
          console.warn("หยุดวิดีโอกล้องไม่สำเร็จ", e);
        }
      }
    };
  }, []);

  // Audio synthethizer beeps
  const playPointBeep = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.type = "triangle";
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(1174.66, ctx.currentTime + 0.15); // D6

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.15);

      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch (e) {
      // Ignore audio contexts blocks before gesture click
    }
  };

  const playGameOverTone = () => {
    try {
      if (!audioCtxRef.current) return;
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(220, ctx.currentTime); // A3
      osc.frequency.linearRampToValueAtTime(110, ctx.currentTime + 0.5); // A2

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.5);

      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    } catch (e) {}
  };

  // Start Camera
  const startCamera = () => {
    const handtrack = (window as any).handtrack;
    if (!handtrack || !videoRef.current || !modelRef.current) return;

    setIsCameraActive(false);
    setIsMouseActive(false);

    handtrack
      .startVideo(videoRef.current)
      .then((status: boolean) => {
        if (status) {
          setIsCameraActive(true);
          setShowStartOverlay(true);
          startTrackingLoop();
        } else {
          alert("สิทธิ์กล้องถูกปฏิเสธ หรือมีปัญหาการเปิดกล้อง จะเปิดใช้งานระบบเมาส์ทดแทนอัตโนมัติ");
          activateMouseMode();
        }
      })
      .catch((err: any) => {
        console.error("Camera fail", err);
        activateMouseMode();
      });
  };

  // Activate Mouse mode fallback
  const activateMouseMode = () => {
    setIsCameraActive(false);
    setIsMouseActive(true);
    setShowStartOverlay(true);

    const canvas = canvasRef.current;
    if (!canvas) return;

    // Attach mouse move coordinates to tracking pointer
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      pointerRef.current.x = (e.clientX - rect.left) * (640 / rect.width);
      pointerRef.current.y = (e.clientY - rect.top) * (480 / rect.height);
      pointerRef.current.active = true;
    };

    canvas.addEventListener("mousemove", handleMouseMove);
    return () => {
      canvas.removeEventListener("mousemove", handleMouseMove);
    };
  };

  // Start hand tracking loop
  const startTrackingLoop = () => {
    if (!modelRef.current || trackingIntervalId.current) return;

    trackingIntervalId.current = setInterval(() => {
      if (videoRef.current && isCameraActive) {
        modelRef.current.detect(videoRef.current).then((predictions: any[]) => {
          if (predictions && predictions.length > 0) {
            const p = predictions[0];
            pointerRef.current.x = p.bbox[0] + p.bbox[2] / 2;
            pointerRef.current.y = p.bbox[1] + p.bbox[3] / 2;
            pointerRef.current.active = true;
          } else {
            pointerRef.current.active = false;
          }
        });
      }
    }, 50);
  };

  // Game helpers
  const spawnStar = () => {
    const size = Math.random() * 15 + 15;
    const colors = ["#00ffaa", "#00f0ff", "#ff0055", "#fff500"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    starsRef.current.push({
      x: Math.random() * (640 - 60) + 30,
      y: Math.random() * (480 - 60) + 30,
      size: size,
      pulse: 0,
      pulseSpeed: Math.random() * 0.1 + 0.05,
      color: randomColor,
      angle: Math.random() * Math.PI * 2,
      spinSpeed: (Math.random() - 0.5) * 0.05,
    });
  };

  const spawnParticles = (x: number, y: number, color: string) => {
    for (let i = 0; i < 15; i++) {
      particlesRef.current.push({
        x: x,
        y: y,
        vx: (Math.random() - 0.5) * 8,
        vy: (Math.random() - 0.5) * 8,
        size: Math.random() * 4 + 1,
        alpha: 1,
        decay: Math.random() * 0.03 + 0.02,
        color: color,
      });
    }
  };

  // Main game loop (runs inside RequestAnimationFrame)
  const gameLoop = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    ctx.clearRect(0, 0, 640, 480);

    // 1. Draw Background
    ctx.save();
    if (isCameraActive && videoRef.current) {
      // Flip camera source horizontally (Mirror)
      ctx.translate(640, 0);
      ctx.scale(-1, 1);
      ctx.globalAlpha = 0.45;
      ctx.drawImage(videoRef.current, 0, 0, 640, 480);
    } else {
      // Cyber Sci-Fi grid
      ctx.fillStyle = "#090a10";
      ctx.fillRect(0, 0, 640, 480);

      ctx.strokeStyle = "#121624";
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < 640; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 480);
        ctx.stroke();
      }
      for (let y = 0; y < 480; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(640, y);
        ctx.stroke();
      }
    }
    ctx.restore();

    // 2. Draw & Collision Star objects
    const currentStars = starsRef.current;
    for (let i = currentStars.length - 1; i >= 0; i--) {
      const s = currentStars[i];
      s.pulse += s.pulseSpeed;
      s.angle += s.spinSpeed;
      const radius = s.size / 2 + Math.sin(s.pulse) * 3;

      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(s.angle);
      ctx.shadowBlur = 15;
      ctx.shadowColor = s.color;
      ctx.fillStyle = s.color;

      ctx.beginPath();
      const spikes = 5;
      let rot = (Math.PI / 2) * 3;
      const step = Math.PI / spikes;

      ctx.moveTo(0, -radius);
      for (let k = 0; k < spikes; k++) {
        ctx.lineTo(Math.cos(rot) * radius, Math.sin(rot) * radius);
        rot += step;
        ctx.lineTo(Math.cos(rot) * (radius / 2), Math.sin(rot) * (radius / 2));
        rot += step;
      }
      ctx.lineTo(0, -radius);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      // Check collision with pointer (webcam center hand or mouse coordinates)
      const pointer = pointerRef.current;
      if (pointer.active) {
        const dist = Math.hypot(pointer.x - s.x, pointer.y - s.y);
        if (dist < radius + 25) {
          playPointBeep();
          spawnParticles(s.x, s.y, s.color);

          // Update Score
          scoreRef.current += 1;
          setHudScore(scoreRef.current);

          // Remove old star and spawn a new one
          currentStars.splice(i, 1);
          spawnStar();
        }
      }
    }

    // 3. Process Particles explosion effect
    const currentParticles = particlesRef.current;
    for (let i = currentParticles.length - 1; i >= 0; i--) {
      const p = currentParticles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= p.decay;

      if (p.alpha <= 0) {
        currentParticles.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 4. Draw pointer crosshair
    const pointer = pointerRef.current;
    if (pointer.active) {
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = "#00ffaa";
      ctx.strokeStyle = "#00ffaa";
      ctx.lineWidth = 2.5;

      // Outer target ring
      ctx.beginPath();
      ctx.arc(pointer.x, pointer.y, 20, 0, Math.PI * 2);
      ctx.stroke();

      // Target lines
      ctx.beginPath();
      ctx.moveTo(pointer.x - 28, pointer.y);
      ctx.lineTo(pointer.x - 12, pointer.y);
      ctx.moveTo(pointer.x + 12, pointer.y);
      ctx.lineTo(pointer.x + 28, pointer.y);
      ctx.moveTo(pointer.x, pointer.y - 28);
      ctx.lineTo(pointer.x, pointer.y - 12);
      ctx.moveTo(pointer.x, pointer.y + 12);
      ctx.lineTo(pointer.x, pointer.y + 28);
      ctx.stroke();

      // Center dot
      ctx.fillStyle = "#00ffaa";
      ctx.beginPath();
      ctx.arc(pointer.x, pointer.y, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Recurse game frame
    animationFrameId.current = requestAnimationFrame(gameLoop);
  };

  // Start the 30 seconds countdown game
  const startGame = () => {
    setShowStartOverlay(false);
    setShowGameOverOverlay(false);
    setHudScore(0);
    setHudTimer(30);

    scoreRef.current = 0;
    timerRef.current = 30;
    starsRef.current = [];
    particlesRef.current = [];

    // Spawn 4 initial target stars
    for (let i = 0; i < 4; i++) {
      spawnStar();
    }

    setIsGameRunning(true);

    // Audio Context Init
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }

    // 30 Seconds timer countdown
    gameIntervalId.current = setInterval(() => {
      timerRef.current -= 1;
      setHudTimer(timerRef.current);

      if (timerRef.current <= 0) {
        endGame();
      }
    }, 1000);

    // Start request animation frame cycle
    animationFrameId.current = requestAnimationFrame(gameLoop);
  };

  // End Game & submit score to Express server API
  const endGame = () => {
    setIsGameRunning(false);
    playGameOverTone();

    if (gameIntervalId.current) clearInterval(gameIntervalId.current);
    if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);

    setShowGameOverOverlay(true);
    setIsSaving(true);
    setSaveResultMsg("");
    setIsNewRecord(false);

    // Send score to node express backend api
    fetch("/api/save-score", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: currentUser?.username || "Guest",
        score: scoreRef.current,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        setIsSaving(false);
        if (data.success) {
          setIsNewRecord(data.isNewRecord);
          if (data.isNewRecord) {
            setSaveResultMsg(`🔥 ยินดีด้วย! คุณทำสถิติสูงสุดใหม่สำเร็จ: ${data.highScore} คะแนน!`);
            onUpdateHighScore(data.highScore);
          } else {
            setSaveResultMsg(`บันทึกคะแนนรอบล่าสุดสำเร็จ! สถิติสูงสุดเดิมของคุณคือ ${data.highScore} คะแนน`);
          }
          // Refresh leaderboards
          onRefreshLeaderboard();
        } else {
          setSaveResultMsg(`บันทึกคะแนนล้มเหลว: ${data.error}`);
        }
      })
      .catch((err) => {
        console.error(err);
        setIsSaving(false);
        setSaveResultMsg("ไม่สามารถติดต่อเซิร์ฟเวอร์ฐานข้อมูลได้ คะแนนถูกบันทึกในเซสชันภายในชั่วคราว");
      });
  };

  const handleRetry = () => {
    setShowGameOverOverlay(false);
    setShowStartOverlay(true);
  };

  return (
    <div className="flex flex-col space-y-4 w-full">
      {/* Game controls header */}
      <div className="bg-cyber-gray border border-cyber-light p-5 rounded-2xl flex flex-wrap justify-between items-center gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 bg-cyber-accent/10 text-cyber-accent px-2 py-0.5 rounded text-[10px] font-display font-bold tracking-wider uppercase border border-cyber-accent/20">
            AR Reflex Arena
          </div>
          <h2 className="text-sm font-black font-display tracking-widest text-white uppercase">RECRUIT TEST METHOD</h2>
          <p className="text-[11px] text-gray-400">เลื่อนปัดมือผ่านเว็บแคมของคุณเพื่อสะสมดาวดึงศักยภาพการตอบสนอง</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={startCamera}
            disabled={!isModelLoaded || isCameraActive}
            className={`px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition cursor-pointer ${
              isCameraActive
                ? "bg-cyber-accent/10 border-cyber-accent/50 text-cyber-accent"
                : "bg-cyber-blue/10 border-cyber-blue/30 text-cyber-blue hover:bg-cyber-blue hover:text-cyber-dark"
            }`}
            id="btn-cam-react"
          >
            <Video className="w-3.5 h-3.5" />
            <span>{isCameraActive ? "📷 กล้องพร้อมใช้" : "📷 เริ่มทดสอบด้วยกล้อง"}</span>
          </button>

          <button
            onClick={activateMouseMode}
            className={`px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition cursor-pointer ${
              isMouseActive
                ? "bg-cyber-accent/10 border-cyber-accent/50 text-cyber-accent"
                : "bg-cyber-light border-cyber-light hover:bg-white hover:text-cyber-dark text-white"
            }`}
            id="btn-mouse-react"
          >
            <MousePointer className="w-3.5 h-3.5" />
            <span>🖱️ เล่นด้วยเมาส์ (Fallback)</span>
          </button>
        </div>
      </div>

      {/* Main interactive Canvas */}
      <div
        className="relative bg-[#020305] rounded-2xl border-2 border-cyber-light overflow-hidden flex items-center justify-center box-glow-blue w-full h-[480px] select-none"
        style={{ minHeight: "480px" }}
      >
        {/* Hidden video element for handpose prediction inputs */}
        <video
          ref={videoRef}
          id="react-video-feed"
          autoPlay
          playsInline
          muted
          width="640"
          height="480"
          className="hidden"
        ></video>

        {/* Game Stage Canvas */}
        <canvas
          ref={canvasRef}
          width="640"
          height="480"
          className="w-full h-full max-w-[640px] max-h-[480px] bg-cyber-dark z-10"
        ></canvas>

        {/* Loading Handtrack AI models overlay */}
        {!isModelLoaded && !modelLoadingError && (
          <div className="absolute inset-0 bg-cyber-dark/95 z-25 flex flex-col items-center justify-center space-y-4">
            <div className="w-12 h-12 border-4 border-cyber-accent border-t-transparent rounded-full animate-spin"></div>
            <p className="text-cyber-accent font-display font-bold tracking-widest text-xs animate-pulse">
              LOADING COMPILING AR HANDTRACK AI MODEL...
            </p>
            <p className="text-[10px] text-gray-500 max-w-xs text-center leading-relaxed">
              ไลบรารีตรวจจับพิกัดปัญญาประดิษฐ์กำลังดาวน์โหลดไฟล์โครงข่ายประสาทเทียมเข้ามาประมวลผลภายในเบราว์เซอร์ของคุณเป็นครั้งแรก
            </p>
          </div>
        )}

        {/* Tensorflow load failures fallback alert panel */}
        {modelLoadingError && (
          <div className="absolute inset-0 bg-cyber-dark/95 z-25 flex flex-col items-center justify-center space-y-4 p-6">
            <ShieldAlert className="w-12 h-12 text-cyber-pink" />
            <div className="text-center space-y-1">
              <p className="text-cyber-pink font-bold font-display text-sm">COULD NOT BOOT AI HANDTRACK MODEL</p>
              <p className="text-xs text-gray-400 max-w-sm">
                เบราว์เซอร์ของคุณบล็อกการคอมไพล์ Tensorflow WebGL หรือถูกจำกัดในเฟรมเวิร์ก แนะนำให้สลับใช้โหมดสำรองควบคุมด้วยเมาส์ได้ทันที
              </p>
            </div>
            <button
              onClick={activateMouseMode}
              className="bg-white hover:bg-gray-100 text-cyber-dark font-display font-black px-6 py-3 rounded-xl text-xs uppercase tracking-widest cursor-pointer"
            >
              PLAY WITH MOUSE (FALLBACK)
            </button>
          </div>
        )}

        {/* Game start button overlay */}
        {showStartOverlay && !isGameRunning && (
          <div className="absolute inset-0 bg-cyber-dark/85 backdrop-blur-sm z-20 flex flex-col items-center justify-center space-y-6">
            <div className="text-center space-y-2">
              <Star className="w-10 h-10 text-cyber-accent mx-auto animate-bounce" />
              <h3 className="text-2xl font-black font-display text-transparent bg-clip-text bg-gradient-to-r from-cyber-accent to-cyber-blue uppercase tracking-widest">
                READY TO REFLEX?
              </h3>
              <p className="text-xs text-gray-400 max-w-xs">
                {isCameraActive
                  ? "กางฝ่ามือของคุณและปัดเคลื่อนไหวเล็งตำแหน่งเป้าหมายดวงดาวเพื่อสะสมแต้มคะแนนภายในเวลา 30 วินาที!"
                  : "เลื่อนเมาส์โบกตำแหน่งเป้าหมายเข้าจับคู่อัญมณีดวงดาวให้รวดเร็วที่สุด!"}
              </p>
            </div>

            <button
              onClick={startGame}
              className="bg-cyber-accent text-cyber-dark font-display font-black px-8 py-4 rounded-xl text-xs tracking-widest uppercase cursor-pointer transition transform hover:scale-105 duration-300 flex items-center gap-2 shadow-lg"
              id="btn-react-start-game"
            >
              <Play className="w-4 h-4 fill-cyber-dark" />
              <span>START CHALLENGE</span>
            </button>
          </div>
        )}

        {/* Game over submission loader & details overlay */}
        {showGameOverOverlay && (
          <div className="absolute inset-0 bg-cyber-dark/95 backdrop-blur-md z-20 flex flex-col items-center justify-center space-y-6">
            <div className="text-center space-y-2">
              <Award className="w-12 h-12 text-cyber-pink mx-auto" />
              <p className="text-cyber-pink font-display font-black text-3xl tracking-widest uppercase">TEST TIME OVER!</p>
              <p className="text-xs text-gray-400">สถิติคะแนนสะสมรอบนี้ของคุณ</p>
              <p className="text-6xl font-black font-display text-white">{hudScore}</p>
            </div>

            {isSaving && (
              <div className="flex items-center gap-2 text-xs text-cyber-blue animate-pulse">
                <div className="w-3 h-3 border-2 border-cyber-blue border-t-transparent rounded-full animate-spin"></div>
                <span>กำลังประมวลผลฐานข้อมูลและคำนวณอันดับลีดเดอร์บอร์ด...</span>
              </div>
            )}

            {!isSaving && saveResultMsg && (
              <div
                className={`p-4 rounded-xl max-w-xs text-center border ${
                  isNewRecord
                    ? "bg-cyber-accent/10 border-cyber-accent/30 text-cyber-accent"
                    : "bg-cyber-light/40 border-cyber-light/80 text-gray-300"
                }`}
              >
                <p className="text-xs font-semibold leading-relaxed">{saveResultMsg}</p>
              </div>
            )}

            <button
              onClick={handleRetry}
              className="bg-cyber-blue text-cyber-dark hover:opacity-90 font-display font-black px-6 py-3 rounded-xl text-xs tracking-widest uppercase cursor-pointer flex items-center gap-1.5 transition"
              id="btn-react-retry"
            >
              <RotateCcw className="w-4 h-4" />
              <span>PLAY AGAIN</span>
            </button>
          </div>
        )}

        {/* Active HUD overlays on canvas */}
        {isGameRunning && (
          <div className="absolute top-4 left-4 right-4 z-15 flex justify-between items-center pointer-events-none">
            {/* Score */}
            <div className="bg-cyber-gray/95 border border-cyber-light px-4 py-2 rounded-xl">
              <span className="text-gray-500 text-[9px] uppercase font-display block">SCORE</span>
              <span className="text-xl font-black font-display text-white">
                {hudScore < 10 ? "0" + hudScore : hudScore}
              </span>
            </div>

            {/* Timer */}
            <div className="bg-cyber-gray/95 border border-cyber-pink/40 px-4 py-2 rounded-xl text-center">
              <span className="text-gray-500 text-[9px] uppercase font-display block font-semibold">TIMER</span>
              <span
                className={`text-xl font-black font-display ${
                  hudTimer <= 10 ? "text-cyber-pink animate-pulse" : "text-cyber-blue"
                }`}
              >
                {hudTimer}s
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

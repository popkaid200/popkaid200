import React, { useState, useEffect } from "react";
import { PHP_FILES_LIST, PHPFile } from "../types";
import { FileCode, Download, Copy, Check, Terminal, Database, HelpCircle, Server } from "lucide-react";

export default function DeveloperHub() {
  const [selectedFile, setSelectedFile] = useState<PHPFile>(PHP_FILES_LIST[0]);
  const [fileContent, setFileContent] = useState<string>("กำลังโหลดรหัสโค้ด...");
  const [copied, setCopied] = useState<boolean>(false);
  const [cachedContent, setCachedContent] = useState<Record<string, string>>({});

  useEffect(() => {
    if (cachedContent[selectedFile.path]) {
      setFileContent(cachedContent[selectedFile.path]);
      return;
    }

    setFileContent("กำลังโหลดรหัสโค้ด...");
    fetch(selectedFile.path)
      .then((res) => {
        if (!res.ok) throw new Error("ไม่สามารถดึงไฟล์ได้");
        return res.text();
      })
      .then((text) => {
        setFileContent(text);
        setCachedContent((prev) => ({ ...prev, [selectedFile.path]: text }));
      })
      .catch((err) => {
        setFileContent(`ไม่พบรหัสโค้ดหรือเกิดข้อผิดพลาดในการดึงข้อมูล: ${err.message}`);
      });
  }, [selectedFile, cachedContent]);

  const handleCopy = () => {
    navigator.clipboard.writeText(fileContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start w-full">
      {/* Left panel: File Selector & XAMPP Tutorial (5 columns) */}
      <div className="lg:col-span-5 space-y-6">
        {/* Source Files list */}
        <div className="bg-cyber-gray border border-cyber-light p-6 rounded-2xl box-glow-accent">
          <h3 className="text-sm font-black font-display tracking-widest text-white uppercase border-b border-cyber-light pb-4 mb-4 flex items-center gap-2">
            <span className="text-cyber-accent text-lg">📂</span> XAMPP / PHP SOURCE FILES
          </h3>
          <p className="text-xs text-gray-400 mb-4 leading-relaxed">
            ไฟล์โค้ด PHP, SQL, และคู่มือติดตั้งฉบับภาษาไทย สำหรับรันแบบ Local บนคอมพิวเตอร์ผ่านโปรแกรม XAMPP
          </p>

          <div className="space-y-2">
            {PHP_FILES_LIST.map((file) => {
              const isSelected = file.name === selectedFile.name;
              return (
                <button
                  key={file.name}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-3 rounded-xl border flex items-start gap-3 transition duration-200 cursor-pointer ${
                    isSelected
                      ? "border-cyber-accent bg-cyber-accent/10 text-white"
                      : "border-cyber-light/60 bg-cyber-dark/40 hover:bg-cyber-light/20 text-gray-300"
                  }`}
                  id={`btn-file-${file.name.replace(".", "-")}`}
                >
                  <FileCode className={`w-5 h-5 mt-0.5 shrink-0 ${isSelected ? "text-cyber-accent animate-pulse" : "text-gray-500"}`} />
                  <div>
                    <div className="text-xs font-bold font-mono tracking-tight">{file.name}</div>
                    <div className="text-[10px] text-gray-400 mt-1 leading-normal">{file.description}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* XAMPP Setup Tutorial */}
        <div className="bg-cyber-gray border border-cyber-light p-6 rounded-2xl">
          <h3 className="text-sm font-black font-display tracking-widest text-white uppercase border-b border-cyber-light pb-4 mb-4 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-cyber-blue" /> QUICK SETUP TUTORIAL
          </h3>

          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-cyber-accent/10 text-cyber-accent font-display font-bold text-xs flex items-center justify-center shrink-0 border border-cyber-accent/30">
                1
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5 text-cyber-accent" /> คัดลอกโค้ด
                </p>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  ดาวน์โหลดไฟล์ทั้งหมดไปวางในโฟลเดอร์ <code className="text-cyber-accent font-mono bg-cyber-dark px-1 py-0.5 rounded">htdocs</code> ของ XAMPP เช่น <code className="text-gray-300 font-mono">C:/xampp/htdocs/esports/</code>
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-cyber-blue/10 text-cyber-blue font-display font-bold text-xs flex items-center justify-center shrink-0 border border-cyber-blue/30">
                2
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-cyber-blue" /> สร้างฐานข้อมูล
                </p>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  เปิด XAMPP Control Panel กด Start Apache และ MySQL แล้วเข้าไปที่ <code className="text-cyber-blue font-mono">http://localhost/phpmyadmin/</code> เพื่อสร้าง DB ชื่อ <code className="text-white font-mono">esports_db</code>
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-cyber-pink/10 text-cyber-pink font-display font-bold text-xs flex items-center justify-center shrink-0 border border-cyber-pink/30">
                3
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-cyber-pink" /> รัน SQL & รันแอป
                </p>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  นำคำสั่งในไฟล์ <code className="text-cyber-pink font-mono">schema.sql</code> ไปรันในแท็บ SQL ของ phpMyAdmin แล้วเปิดใช้งานแอปผ่านทาง <code className="text-white font-mono">http://localhost/esports/</code>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right panel: Active Code Editor Display (7 columns) */}
      <div className="lg:col-span-7 space-y-4">
        <div className="bg-[#05060b] border-2 border-cyber-light rounded-2xl overflow-hidden box-glow-blue flex flex-col h-[650px]">
          {/* Editor Header */}
          <div className="bg-cyber-gray px-6 py-4 border-b border-cyber-light flex justify-between items-center shrink-0">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-cyber-pink"></span>
              <span className="w-3 h-3 rounded-full bg-cyber-yellow"></span>
              <span className="w-3 h-3 rounded-full bg-cyber-accent"></span>
              <span className="text-xs font-mono font-bold text-white ml-2">{selectedFile.name}</span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="bg-cyber-light/40 hover:bg-cyber-light text-gray-300 hover:text-white px-3 py-1.5 rounded-lg text-xs font-semibold border border-cyber-light flex items-center gap-1.5 transition cursor-pointer"
                id="btn-copy-code"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-cyber-accent" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? "คัดลอกแล้ว!" : "คัดลอกโค้ด"}</span>
              </button>

              <a
                href={selectedFile.path}
                download={selectedFile.name}
                className="bg-cyber-blue text-cyber-dark hover:opacity-90 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                id="btn-download-code"
              >
                <Download className="w-3.5 h-3.5" />
                <span>ดาวน์โหลด</span>
              </a>
            </div>
          </div>

          {/* Editor Area with line numbers */}
          <div className="flex-grow overflow-auto font-mono text-xs p-6 bg-[#030407] text-gray-300 selection:bg-cyber-accent/20 selection:text-white leading-relaxed flex">
            {/* Simulated Line Numbers */}
            <div className="select-none text-right pr-4 text-gray-600 border-r border-cyber-light/25 mr-4 text-[11px]">
              {fileContent.split("\n").map((_, i) => (
                <div key={i} className="h-5">
                  {i + 1}
                </div>
              ))}
            </div>

            {/* Code Body */}
            <pre className="flex-grow whitespace-pre overflow-x-auto text-[11px] text-left">
              <code className="block h-full">{fileContent}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}

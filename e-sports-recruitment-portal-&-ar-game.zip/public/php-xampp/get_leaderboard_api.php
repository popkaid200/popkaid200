<?php
// get_leaderboard_api.php - ส่งคืนทำเนียบผู้นำในรูปแบบ JSON เพื่ออัปเดตแบบเรียลไทม์
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

try {
    $stmt = $pdo->query("SELECT username, high_score FROM users ORDER BY high_score DESC LIMIT 10");
    $leaderboard = $stmt->fetchAll();
    
    // ตรวจสอบและแปลงชนิดข้อมูลตัวเลขคะแนนสะสม
    foreach ($leaderboard as &$row) {
        $row['high_score'] = intval($row['high_score']);
    }
    
    echo json_encode($leaderboard, JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'ไม่สามารถดึงข้อมูลทำเนียบได้: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>

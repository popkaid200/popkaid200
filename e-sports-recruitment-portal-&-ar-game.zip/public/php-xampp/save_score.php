<?php
// save_score.php - API สำหรับรับค่าคะแนนมาอัปเดตในฐานข้อมูล
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once 'db.php';

// ตรวจสอบว่าเข้าสู่ระบบอยู่หรือไม่
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'กรุณาเข้าสู่ระบบก่อนอัปเดตคะแนน'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// รับข้อมูล JSON จาก Request Body
$input_data = file_get_contents('php://input');
$data = json_decode($input_data, true);

if (!isset($data['score']) || !is_numeric($data['score'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'ข้อมูลคะแนนไม่สมบูรณ์หรือไม่ถูกต้อง'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$score = intval($data['score']);
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

try {
    // ดึงคะแนนเดิมมาเปรียบเทียบ
    $stmt = $pdo->prepare("SELECT high_score FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $current_high = $stmt->fetchColumn();

    $is_new_record = false;
    $updated_high_score = $current_high;

    // ถ้าคะแนนรอบล่าสุดสูงกว่าคะแนนเดิม ให้ทำการอัปเดต
    if ($score > $current_high) {
        $stmt_update = $pdo->prepare("UPDATE users SET high_score = ?, last_played_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt_update->execute([$score, $user_id]);
        
        $is_new_record = true;
        $updated_high_score = $score;
        $_SESSION['high_score'] = $score; // อัปเดตใน session
    } else {
        // อัปเดตเวลาที่เข้าเล่นล่าสุดอย่างเดียว
        $stmt_update_time = $pdo->prepare("UPDATE users SET last_played_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt_update_time->execute([$user_id]);
    }

    echo json_encode([
        'success' => true,
        'username' => $username,
        'score' => $score,
        'previous_high' => intval($current_high),
        'high_score' => intval($updated_high_score),
        'is_new_record' => $is_new_record,
        'message' => $is_new_record ? 'ยินดีด้วย! คุณทำลายสถิติใหม่สำเร็จ!' : 'บันทึกคะแนนรอบล่าสุดสำเร็จ'
    ], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>

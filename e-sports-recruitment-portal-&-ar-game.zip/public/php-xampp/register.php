<?php
// register.php - หน้าลงทะเบียนสมาชิกใหม่
session_start();
require_once 'db.php';

$error = '';

if (isset($_SESSION['username'])) {
    header('Location: game.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($username) || empty($password) || empty($confirm_password)) {
        $error = 'กรุณากรอกข้อมูลให้ครบถ้วนทุกช่อง';
    } elseif (strlen($username) < 3) {
        $error = 'Username ต้องมีความยาวอย่างน้อย 3 ตัวอักษร';
    } elseif ($password !== $confirm_password) {
        $error = 'รหัสผ่านทั้งสองช่องไม่ตรงกัน';
    } else {
        try {
            // ตรวจสอบว่ามี username นี้อยู่แล้วหรือยัง
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $exists = $stmt->fetchColumn();

            if ($exists > 0) {
                $error = 'Username นี้มีผู้ใช้งานในระบบแล้ว';
            } else {
                // Hash รหัสผ่านเพื่อความปลอดภัยขั้นสูง (Bcrypt)
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // บันทึกลงฐานข้อมูล
                $stmt = $pdo->prepare("INSERT INTO users (username, password, high_score) VALUES (?, ?, 0)");
                $stmt->execute([$username, $hashed_password]);

                header('Location: index.php?registered=1');
                exit;
            }
        } catch (PDOException $e) {
            $error = 'เกิดข้อผิดพลาดในการลงทะเบียน: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สมัครเข้าทีม - NEXUS COVENANT</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@400;600;800;900&display=swap" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        display: ['Orbitron', 'sans-serif'],
                    },
                    colors: {
                        cyber: {
                            dark: '#090a0f',
                            gray: '#12141c',
                            light: '#1e2130',
                            accent: '#00ffaa',
                            pink: '#ff0055',
                            blue: '#00f0ff',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background-color: #090a0f;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(255, 0, 85, 0.05) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(0, 240, 255, 0.05) 0%, transparent 40%);
        }
        .glow-pink {
            text-shadow: 0 0 10px rgba(255, 0, 85, 0.5);
        }
        .box-glow {
            box-shadow: 0 0 15px rgba(255, 0, 85, 0.15);
        }
        .scanline {
            background: linear-gradient(
                rgba(18, 16, 16, 0) 50%, 
                rgba(0, 0, 0, 0.25) 50%
            ), linear-gradient(
                90deg, 
                rgba(255, 0, 0, 0.06), 
                rgba(0, 255, 0, 0.02), 
                rgba(0, 0, 255, 0.06)
            );
            background-size: 100% 4px, 6px 100%;
        }
    </style>
</head>
<body class="text-gray-200 font-sans min-h-screen flex flex-col justify-between scanline">

    <!-- Header / Navbar -->
    <header class="border-b border-cyber-light bg-cyber-dark/80 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <span class="text-2xl font-black font-display tracking-wider text-cyber-pink glow-pink">NEXUS</span>
                <span class="text-xs bg-cyber-accent text-cyber-dark px-2 py-0.5 rounded font-display font-bold tracking-widest">COVENANT</span>
            </div>
            <div>
                <a href="index.php" class="text-sm font-semibold text-cyber-accent hover:text-white transition duration-300">เข้าสู่ระบบ</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-lg mx-auto px-4 py-16 w-full flex-grow flex items-center justify-center">
        <div class="bg-cyber-gray/95 border-2 border-cyber-light p-8 rounded-2xl box-glow relative w-full">
            <div class="absolute top-0 right-8 -translate-y-1/2 bg-cyber-pink text-white text-xs font-display font-black tracking-widest px-3 py-1 rounded-sm uppercase">
                RECRUIT ACCOUNT
            </div>

            <h2 class="text-2xl font-black font-display tracking-tight text-white mb-2">CREATE IDENTITY</h2>
            <p class="text-gray-400 text-xs mb-6">สมัครสมาชิกเพื่อเปิดแฟ้มประวัติและเข้าทดสอบความสามารถ</p>

            <!-- Error Alert -->
            <?php if ($error): ?>
                <div class="bg-cyber-pink/10 border border-cyber-pink/50 text-cyber-pink px-4 py-3 rounded-lg text-xs mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-4">
                <div>
                    <label class="block text-xs font-display font-semibold tracking-wider text-gray-400 uppercase mb-2">Username</label>
                    <input type="text" name="username" required placeholder="ขั้นต่ำ 3 ตัวอักษร"
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                           class="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-pink focus:ring-1 focus:ring-cyber-pink outline-none text-white font-mono transition duration-200">
                </div>

                <div>
                    <label class="block text-xs font-display font-semibold tracking-wider text-gray-400 uppercase mb-2">Password</label>
                    <input type="password" name="password" required placeholder="ตั้งรหัสผ่านของคุณ"
                           class="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-pink focus:ring-1 focus:ring-cyber-pink outline-none text-white font-mono transition duration-200">
                </div>

                <div>
                    <label class="block text-xs font-display font-semibold tracking-wider text-gray-400 uppercase mb-2">Confirm Password</label>
                    <input type="password" name="confirm_password" required placeholder="กรอกรหัสผ่านอีกครั้ง"
                           class="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-pink focus:ring-1 focus:ring-cyber-pink outline-none text-white font-mono transition duration-200">
                </div>

                <div class="text-xs text-gray-500 py-2 leading-relaxed">
                    เมื่อกดลงทะเบียน ข้อมูลโปรไฟล์ของคุณจะได้รับการบันทึกอย่างปลอดภัยในรูปแบบการ Hash รหัสผ่าน (Bcrypt) 
                    เพื่อป้องกันการเข้าถึงข้อมูลส่วนตัวโดยไม่ได้รับอนุญาต
                </div>

                <button type="submit" 
                        class="w-full bg-gradient-to-r from-cyber-pink to-purple-600 text-white font-display font-black text-sm py-4 rounded-xl hover:opacity-90 transition duration-300 shadow-lg tracking-widest uppercase cursor-pointer">
                    SUBMIT REGISTRATION
                </button>
            </form>

            <div class="mt-6 pt-6 border-t border-cyber-light text-center">
                <p class="text-xs text-gray-500">
                    มีบัญชีอยู่แล้ว? 
                    <a href="index.php" class="text-cyber-accent hover:underline font-bold ml-1">ล็อกอินที่นี่</a>
                </p>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="border-t border-cyber-light bg-cyber-dark/40 py-6 text-center text-xs text-gray-600">
        <div class="max-w-6xl mx-auto px-4">
            <p>© 2026 NEXUS COVENANT E-Sports Club. All Rights Reserved.</p>
        </div>
    </footer>

</body>
</html>

<?php
// logout.php - ทำลาย Session และออกจากระบบเพื่อความปลอดภัย
session_start();

// ล้างตัวแปรเซสชันทั้งหมด
$_SESSION = array();

// ทำลายคุ้กกี้เซสชันถ้ามี
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// ทำลายเซสชัน
session_destroy();

// รีไดเรกต์กลับหน้าหลัก
header("Location: index.php");
exit;
?>

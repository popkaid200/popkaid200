<?php
// index.php - หน้าเกริ่นนำทีมและหน้าเข้าสู่ระบบ
session_start();
require_once 'db.php';

$error = '';
$success = '';

if (isset($_SESSION['username'])) {
    header('Location: game.php');
    exit;
}

if (isset($_GET['registered'])) {
    $success = 'ลงทะเบียนสำเร็จ! กรุณาเข้าสู่ระบบเพื่อทดสอบฝีมือ';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = 'กรุณากรอก Username และ Password ให้ครบถ้วน';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // เก็บข้อมูลเข้า Session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['high_score'] = $user['high_score'];
                
                header('Location: game.php');
                exit;
            } else {
                $error = 'Username หรือ Password ไม่ถูกต้อง';
            }
        } catch (PDOException $e) {
            $error = 'เกิดข้อผิดพลาด: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NEXUS COVENANT - E-Sports Recruitment</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@400;600;800;900&display=swap" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        display: ['Orbitron', 'sans-serif'],
                    },
                    colors: {
                        cyber: {
                            dark: '#090a0f',
                            gray: '#12141c',
                            light: '#1e2130',
                            accent: '#00ffaa',
                            pink: '#ff0055',
                            blue: '#00f0ff',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background-color: #090a0f;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(0, 240, 255, 0.05) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(255, 0, 85, 0.05) 0%, transparent 40%);
        }
        .glow-accent {
            text-shadow: 0 0 10px rgba(0, 255, 170, 0.5);
        }
        .box-glow {
            box-shadow: 0 0 15px rgba(0, 255, 170, 0.15);
        }
        .scanline {
            background: linear-gradient(
                rgba(18, 16, 16, 0) 50%, 
                rgba(0, 0, 0, 0.25) 50%
            ), linear-gradient(
                90deg, 
                rgba(255, 0, 0, 0.06), 
                rgba(0, 255, 0, 0.02), 
                rgba(0, 0, 255, 0.06)
            );
            background-size: 100% 4px, 6px 100%;
        }
    </style>
</head>
<body class="text-gray-200 font-sans min-h-screen flex flex-col justify-between scanline">

    <!-- Header / Navbar -->
    <header class="border-b border-cyber-light bg-cyber-dark/80 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <span class="text-2xl font-black font-display tracking-wider text-cyber-accent glow-accent">NEXUS</span>
                <span class="text-xs bg-cyber-pink text-white px-2 py-0.5 rounded font-display font-bold tracking-widest">COVENANT</span>
            </div>
            <div>
                <a href="register.php" class="text-sm font-semibold text-cyber-blue hover:text-white transition duration-300">สมัครสมาชิกใหม่</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-6xl mx-auto px-4 py-12 flex-grow flex flex-col lg:flex-row items-center gap-12 w-full">
        <!-- Team Lore / Recruitment Details -->
        <div class="lg:w-1/2 space-y-6">
            <div class="inline-flex items-center space-x-2 bg-cyber-light/50 border border-cyber-accent/30 px-3 py-1 rounded-full text-xs text-cyber-accent font-display tracking-widest">
                <span class="w-2 h-2 rounded-full bg-cyber-accent animate-ping"></span>
                <span>RECRUITMENT STAGE ACTIVE</span>
            </div>
            
            <h1 class="text-4xl md:text-5xl font-black font-display tracking-tight text-white leading-tight">
                ก้าวสู่การเป็นนักกีฬา <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyber-accent via-cyber-blue to-cyber-pink glow-accent">
                    E-SPORTS มืออาชีพ
                </span>
            </h1>
            
            <p class="text-gray-400 text-base md:text-lg leading-relaxed">
                ยินดีต้อนรับสู่ <span class="text-white font-bold font-display">NEXUS COVENANT</span> ทีมสัญชาติไทยระดับแนวหน้า 
                เราไม่เพียงแค่มองหาคนเล่นเกมเก่ง แต่เรากำลังเฟ้นหาผู้มีความสามารถที่มี "สมาธิ" และ "การตอบสนองขั้นสูง" (Reflex) 
                เพื่อมาร่วมทีมลุยศึกระดับประเทศและชิงแชมป์เอเชียในปีนี้!
            </p>

            <div class="grid grid-cols-2 gap-4 pt-4">
                <div class="bg-cyber-gray/80 p-4 rounded-xl border border-cyber-light">
                    <div class="text-cyber-accent font-display text-2xl font-bold">120+ fps</div>
                    <div class="text-xs text-gray-500 uppercase font-display">Reflex Threshold</div>
                </div>
                <div class="bg-cyber-gray/80 p-4 rounded-xl border border-cyber-light">
                    <div class="text-cyber-blue font-display text-2xl font-bold">฿1,500,000+</div>
                    <div class="text-xs text-gray-500 uppercase font-display">Prize Pool Share</div>
                </div>
            </div>

            <div class="p-5 bg-cyber-light/20 rounded-xl border border-cyber-blue/20">
                <h3 class="text-white font-bold font-display text-sm uppercase mb-2 flex items-center gap-2">
                    <span class="text-cyber-blue">●</span> ขั้นตอนการสมัครและทดสอบ
                </h3>
                <ol class="list-decimal list-inside text-xs text-gray-400 space-y-2">
                    <li>สมัครบัญชีเพื่อสร้างโปรไฟล์ผู้เล่นของคุณ</li>
                    <li>ล็อกอินเข้าสู่ระบบและเริ่มการทดสอบ <strong class="text-cyber-accent">AR Reflex Tester</strong></li>
                    <li>ใช้ท่าทางมือ (Hand Tracking) แตะเป้าหมายดวงดาวเพื่อเก็บคะแนนสะสม</li>
                    <li>ผู้เล่นที่ได้คะแนนสูงสุด 10 อันดับแรกจะได้รับการเรียกตัวเข้าทดสอบในแคมป์จริง!</li>
                </ol>
            </div>
        </div>

        <!-- Login Card -->
        <div class="lg:w-1/2 w-full max-w-md">
            <div class="bg-cyber-gray/95 border-2 border-cyber-light p-8 rounded-2xl box-glow relative">
                <div class="absolute top-0 right-8 -translate-y-1/2 bg-cyber-accent text-cyber-dark text-xs font-display font-black tracking-widest px-3 py-1 rounded-sm uppercase">
                    SECURE SIGN IN
                </div>

                <h2 class="text-2xl font-black font-display tracking-tight text-white mb-6">LOGIN TO PORTAL</h2>

                <!-- Success Alert -->
                <?php if ($success): ?>
                    <div class="bg-cyber-accent/10 border border-cyber-accent/50 text-cyber-accent px-4 py-3 rounded-lg text-xs mb-6">
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>

                <!-- Error Alert -->
                <?php if ($error): ?>
                    <div class="bg-cyber-pink/10 border border-cyber-pink/50 text-cyber-pink px-4 py-3 rounded-lg text-xs mb-6">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" class="space-y-4">
                    <div>
                        <label class="block text-xs font-display font-semibold tracking-wider text-gray-400 uppercase mb-2">Username</label>
                        <input type="text" name="username" required placeholder="กรอก Username ของคุณ"
                               class="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-accent focus:ring-1 focus:ring-cyber-accent outline-none text-white font-mono transition duration-200">
                    </div>

                    <div>
                        <label class="block text-xs font-display font-semibold tracking-wider text-gray-400 uppercase mb-2">Password</label>
                        <input type="password" name="password" required placeholder="กรอก Password ของคุณ"
                               class="w-full bg-cyber-dark border border-cyber-light rounded-xl px-4 py-3 text-sm focus:border-cyber-accent focus:ring-1 focus:ring-cyber-accent outline-none text-white font-mono transition duration-200">
                    </div>

                    <button type="submit" 
                            class="w-full bg-gradient-to-r from-cyber-accent to-cyber-blue text-cyber-dark font-display font-black text-sm py-4 rounded-xl hover:opacity-90 transition duration-300 shadow-lg tracking-widest uppercase cursor-pointer">
                        ENTER PORTAL
                    </button>
                </form>

                <div class="mt-6 pt-6 border-t border-cyber-light text-center">
                    <p class="text-xs text-gray-500">
                        ยังไม่มีบัญชีใช่หรือไม่? 
                        <a href="register.php" class="text-cyber-accent hover:underline font-bold ml-1">สมัครสมาชิกที่นี่</a>
                    </p>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="border-t border-cyber-light bg-cyber-dark/40 py-6 text-center text-xs text-gray-600">
        <div class="max-w-6xl mx-auto px-4">
            <p>© 2026 NEXUS COVENANT E-Sports Club. Powered by Handtrack.js & PHP/MySQL.</p>
        </div>
    </footer>

</body>
</html>

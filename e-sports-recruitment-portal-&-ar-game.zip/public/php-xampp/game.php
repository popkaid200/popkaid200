<?php
// game.php - หน้าเล่นเกม AR ด้วย Handtrack.js สำหรับส่งคะแนน
session_start();
require_once 'db.php';

// บังคับล็อกอิน
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$username = $_SESSION['username'];
$high_score = $_SESSION['high_score'];

// ดึงทำเนียบผู้นำ (Leaderboard) มาแสดงสดๆ ข้างๆ บอร์ดเกม
$leaderboard = [];
try {
    $stmt = $pdo->query("SELECT username, high_score FROM users ORDER BY high_score DESC LIMIT 10");
    $leaderboard = $stmt->fetchAll();
} catch (PDOException $e) {
    // เงียบไว้ก่อน
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AR Star Catcher - NEXUS COVENANT</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@400;600;800;900&display=swap" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Handtrack.js Library CDN -->
    <script src="https://cdn.jsdelivr.net/npm/handtrackjs/dist/handtrack.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        display: ['Orbitron', 'sans-serif'],
                    },
                    colors: {
                        cyber: {
                            dark: '#090a0f',
                            gray: '#12141c',
                            light: '#1e2130',
                            accent: '#00ffaa',
                            pink: '#ff0055',
                            blue: '#00f0ff',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background-color: #090a0f;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(0, 240, 255, 0.05) 0%, transparent 60%);
        }
        .glow-accent { text-shadow: 0 0 10px rgba(0, 255, 170, 0.5); }
        .glow-pink { text-shadow: 0 0 10px rgba(255, 0, 85, 0.5); }
        .glow-blue { text-shadow: 0 0 10px rgba(0, 240, 255, 0.5); }
        .box-glow { box-shadow: 0 0 15px rgba(0, 255, 170, 0.15); }
        .scanline {
            background: linear-gradient(
                rgba(18, 16, 16, 0) 50%, 
                rgba(0, 0, 0, 0.2) 50%
            ), linear-gradient(
                90deg, 
                rgba(255, 0, 0, 0.03), 
                rgba(0, 255, 0, 0.01), 
                rgba(0, 0, 255, 0.03)
            );
            background-size: 100% 4px, 6px 100%;
        }
    </style>
</head>
<body class="text-gray-200 font-sans min-h-screen flex flex-col justify-between scanline">

    <!-- Header / Navbar -->
    <header class="border-b border-cyber-light bg-cyber-dark/90 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div class="flex items-center space-x-2">
                <span class="text-2xl font-black font-display tracking-wider text-cyber-accent glow-accent">NEXUS</span>
                <span class="text-xs bg-cyber-pink text-white px-2 py-0.5 rounded font-display font-bold tracking-widest">COVENANT</span>
            </div>
            
            <div class="flex items-center space-x-6">
                <div class="text-right">
                    <p class="text-xs text-gray-500 uppercase tracking-widest">ACTIVE PROFILE</p>
                    <p class="text-sm font-bold text-white font-mono flex items-center gap-2 justify-end">
                        <span class="w-2 h-2 rounded-full bg-cyber-accent animate-pulse"></span>
                        <?php echo htmlspecialchars($username); ?>
                    </p>
                </div>
                <div class="h-8 w-px bg-cyber-light"></div>
                <div class="text-right">
                    <p class="text-xs text-gray-500 uppercase tracking-widest">YOUR BEST</p>
                    <p class="text-sm font-bold text-cyber-accent font-display glow-accent">
                        <span id="nav-high-score"><?php echo intval($high_score); ?></span> pts
                    </p>
                </div>
                <div class="h-8 w-px bg-cyber-light"></div>
                <a href="logout.php" class="text-xs bg-cyber-pink/20 hover:bg-cyber-pink text-cyber-pink hover:text-white px-3 py-1.5 rounded-lg border border-cyber-pink/30 font-display uppercase tracking-widest transition duration-300">
                    LOGOUT
                </a>
            </div>
        </div>
    </header>

    <!-- Main Game Area -->
    <main class="max-w-7xl mx-auto px-4 py-8 w-full flex-grow grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Left panel: Webcam & Game Arena (8 columns) -->
        <div class="lg:col-span-8 flex flex-col space-y-4">
            
            <!-- Game Info and Controller -->
            <div class="bg-cyber-gray border border-cyber-light p-4 rounded-2xl flex flex-wrap justify-between items-center gap-4">
                <div class="space-y-1">
                    <h1 class="text-lg font-black font-display tracking-wider text-white">AR STAR CATCHER</h1>
                    <p class="text-xs text-gray-400">ควบคุมด้วยการเคลื่อนไหวของมือผ่านกล้อง หรือสลับใช้เมาส์หากกล้องไม่พร้อม</p>
                </div>
                <div class="flex items-center gap-2">
                    <button id="btn-camera" class="bg-cyber-blue/10 hover:bg-cyber-blue hover:text-cyber-dark text-cyber-blue px-3 py-2 rounded-xl text-xs font-semibold border border-cyber-blue/30 transition duration-300 flex items-center gap-1.5 cursor-pointer">
                        📷 เริ่มกล้อง/สแกนมือ
                    </button>
                    <button id="btn-mouse" class="bg-cyber-light/50 hover:bg-white hover:text-cyber-dark text-white px-3 py-2 rounded-xl text-xs font-semibold border border-gray-600 transition duration-300 cursor-pointer">
                        🖱️ เล่นด้วยเมาส์ (Fallback)
                    </button>
                </div>
            </div>

            <!-- The Webcam / Canvas Stage Container -->
            <div class="relative bg-black rounded-2xl border-2 border-cyber-light overflow-hidden flex items-center justify-center box-glow" style="min-height: 480px;">
                
                <!-- Webcam Hidden Video Element (used as input for detection) -->
                <video id="video-feed" autoplay playsinline muted width="640" height="480" class="hidden"></video>
                
                <!-- Game Interactive Canvas -->
                <canvas id="game-canvas" width="640" height="480" class="w-full h-full max-w-[640px] max-h-[480px] bg-cyber-dark z-20"></canvas>

                <!-- AR Model Loading Overlay -->
                <div id="loader-overlay" class="absolute inset-0 bg-cyber-dark/95 z-30 flex flex-col items-center justify-center space-y-4">
                    <div class="w-12 h-12 border-4 border-cyber-accent border-t-transparent rounded-full animate-spin"></div>
                    <p class="text-cyber-accent font-display font-bold tracking-widest text-sm animate-pulse">LOADING AI AR HANDTRACKING MODEL...</p>
                    <p class="text-xs text-gray-500 max-w-xs text-center">ดาวน์โหลดโมเดลในเบราว์เซอร์ครั้งแรกอาจใช้เวลาสักครู่</p>
                </div>

                <!-- Ready to Start Button Overlay -->
                <div id="start-overlay" class="absolute inset-0 bg-cyber-dark/80 backdrop-blur-sm z-30 flex flex-col items-center justify-center space-y-6 hidden">
                    <div class="text-center space-y-2">
                        <h2 class="text-3xl font-black font-display text-white tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyber-accent to-cyber-blue">READY TO START?</h2>
                        <p class="text-xs text-gray-400">ควบคุมด้วยการกางมือของคุณ แล้วเลื่อนปัดเพื่อจับดวงดาว!</p>
                    </div>
                    <button id="btn-start-game" class="bg-cyber-accent hover:bg-cyber-accent/80 text-cyber-dark font-display font-black px-8 py-4 rounded-xl text-sm tracking-widest uppercase cursor-pointer transition transform hover:scale-105 duration-300">
                        START CHALLENGE
                    </button>
                </div>
                
                <!-- Game Over Score Submission Overlay -->
                <div id="gameover-overlay" class="absolute inset-0 bg-cyber-dark/90 backdrop-blur-md z-30 flex flex-col items-center justify-center space-y-6 hidden">
                    <div class="text-center space-y-2">
                        <p class="text-cyber-pink font-display font-black text-4xl tracking-widest glow-pink">TIME UP!</p>
                        <p class="text-sm text-gray-400">คะแนนที่ได้ในรอบนี้</p>
                        <p id="final-score" class="text-6xl font-black font-display text-white">0</p>
                    </div>
                    
                    <div id="saving-indicator" class="flex items-center gap-2 text-xs text-cyber-blue animate-pulse">
                        <div class="w-3 h-3 border-2 border-cyber-blue border-t-transparent rounded-full animate-spin"></div>
                        <span>กำลังอัปโหลดและประมวลผลสถิติในระบบ...</span>
                    </div>

                    <div id="saving-result" class="text-center p-4 bg-cyber-light/40 border border-cyber-accent/30 rounded-xl max-w-xs hidden">
                        <p class="text-cyber-accent text-xs font-bold" id="saving-message">สถิติอัปเดตเรียบร้อย!</p>
                    </div>

                    <button id="btn-retry" class="bg-cyber-blue hover:bg-cyan-400 text-cyber-dark font-display font-black px-6 py-3 rounded-xl text-xs tracking-widest uppercase cursor-pointer">
                        PLAY AGAIN
                    </button>
                </div>

                <!-- HUD Top Overlays on Canvas -->
                <div id="hud-stats" class="absolute top-4 left-4 right-4 z-20 flex justify-between items-center pointer-events-none hidden">
                    <!-- Score -->
                    <div class="bg-cyber-gray/90 border border-cyber-light px-4 py-2 rounded-xl">
                        <span class="text-gray-400 text-[10px] uppercase font-display block">SCORE</span>
                        <span id="hud-score" class="text-2xl font-black font-display text-white">00</span>
                    </div>

                    <!-- Timer -->
                    <div class="bg-cyber-gray/90 border border-cyber-pink/40 px-4 py-2 rounded-xl text-center">
                        <span class="text-gray-400 text-[10px] uppercase font-display block">TIME REMAINING</span>
                        <span id="hud-timer" class="text-2xl font-black font-display text-cyber-pink glow-pink">30s</span>
                    </div>
                </div>

                <!-- Hand Tracking Center Marker (Aesthetic) -->
                <div id="cursor-tracker" class="absolute w-8 h-8 border-2 border-dashed border-cyber-accent rounded-full -translate-x-1/2 -translate-y-1/2 pointer-events-none z-20 hidden">
                    <div class="w-1.5 h-1.5 bg-cyber-accent rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                </div>
            </div>

            <!-- Tips & Instructions -->
            <div class="bg-cyber-gray/30 border border-cyber-light p-4 rounded-2xl text-xs text-gray-400 leading-relaxed">
                <span class="text-white font-bold uppercase font-display text-cyber-accent">💡 เคล็ดลับโปรเพลย์เยอร์:</span> 
                พยายามให้อัญมณีดวงดาวอยู่ในระดับกลางกล้อง, แสงสว่างในห้องต้องเพียงพอเพื่อความรวดเร็วในการตรวจจับมือ 
                หากกล้องมีความล่าช้า สามารถเปลี่ยนไปเล่นด้วยระบบเมาส์ (Mouse Fallback) เพื่อประลองความเร็วแบบใช้สายตาและการเล็งได้ทันที!
            </div>
        </div>

        <!-- Right panel: Leaderboard & Stats (4 columns) -->
        <div class="lg:col-span-4 space-y-6">
            
            <!-- Recruitment Leaderboard Box -->
            <div class="bg-cyber-gray border-2 border-cyber-light p-6 rounded-2xl box-glow">
                <h3 class="text-sm font-black font-display tracking-widest text-white uppercase border-b border-cyber-light pb-4 mb-4 flex items-center gap-2">
                    <span class="text-cyber-accent text-xl">🏆</span> TOP CONTENDERS
                </h3>

                <div class="space-y-2" id="leaderboard-container">
                    <?php if (empty($leaderboard)): ?>
                        <p class="text-xs text-gray-500 py-4 text-center">ยังไม่มีผู้ท้าชิงคะแนนสูงสุดในขณะนี้</p>
                    <?php else: ?>
                        <?php foreach ($leaderboard as $index => $player): ?>
                            <div class="flex items-center justify-between p-3 rounded-xl border border-cyber-light/40 bg-cyber-dark/40 hover:bg-cyber-light/20 transition duration-200">
                                <div class="flex items-center space-x-3">
                                    <span class="w-6 text-center font-display font-black text-xs <?php 
                                        if ($index == 0) echo 'text-cyber-yellow';
                                        elseif ($index == 1) echo 'text-cyber-blue';
                                        elseif ($index == 2) echo 'text-cyber-pink';
                                        else echo 'text-gray-500';
                                    ?>">
                                        #<?php echo $index + 1; ?>
                                    </span>
                                    <span class="text-sm font-semibold text-white font-mono"><?php echo htmlspecialchars($player['username']); ?></span>
                                    <?php if ($player['username'] === $username): ?>
                                        <span class="text-[8px] bg-cyber-accent text-cyber-dark px-1.5 py-0.5 rounded uppercase font-bold font-display">YOU</span>
                                    <?php endif; ?>
                                </div>
                                <span class="text-sm font-bold text-cyber-accent font-display"><?php echo intval($player['high_score']); ?> pts</span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="mt-6 pt-4 border-t border-cyber-light text-center">
                    <p class="text-[10px] text-gray-500 leading-relaxed uppercase tracking-wider">
                        อันดับจะอัปเดตสดแบบเรียลไทม์เมื่อผู้สมัครทำคะแนนได้ใหม่
                    </p>
                </div>
            </div>
            
        </div>
    </main>

    <!-- Footer -->
    <footer class="border-t border-cyber-light bg-cyber-dark/40 py-6 text-center text-xs text-gray-600">
        <div class="max-w-7xl mx-auto px-4">
            <p>© 2026 NEXUS COVENANT E-Sports Club. Real-time AR Webcam System.</p>
        </div>
    </footer>

    <!-- Game Logic Script -->
    <script>
        // กำหนดพารามิเตอร์เริ่มต้น
        const canvas = document.getElementById('game-canvas');
        const ctx = canvas.getContext('2d');
        const video = document.getElementById('video-feed');
        const loaderOverlay = document.getElementById('loader-overlay');
        const startOverlay = document.getElementById('start-overlay');
        const gameoverOverlay = document.getElementById('gameover-overlay');
        const hudStats = document.getElementById('hud-stats');
        const hudScore = document.getElementById('hud-score');
        const hudTimer = document.getElementById('hud-timer');
        const finalScore = document.getElementById('final-score');
        const cursorTracker = document.getElementById('cursor-tracker');
        
        // ข้อมูลเกมนับคะแนน
        let model = null;
        let isCameraActive = false;
        let isMouseActive = false;
        let isGameRunning = false;
        let score = 0;
        let timeLeft = 30;
        let gameInterval = null;
        let detectionInterval = null;
        let loopRequestId = null;

        // ตำแหน่งของพอยน์เตอร์ควบคุม (มือ หรือ เมาส์)
        let pointer = { x: 320, y: 240, active: false };

        // โครงสร้างวัตถุ "ดาว" ในสเตจ
        let stars = [];
        let particles = []; // เอฟเฟกต์ระเบิดเมื่อโดนดาว

        // Web Audio Context สำหรับบีปสะสมแต้มแบบเรียลไทม์
        let audioCtx = null;
        function playPointSound() {
            try {
                if (!audioCtx) {
                    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                }
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // โน้ต D5
                osc.frequency.exponentialRampToValueAtTime(1174.66, audioCtx.currentTime + 0.15); // โน้ต D6
                
                gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
                gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
                
                osc.start();
                osc.stop(audioCtx.currentTime + 0.15);
            } catch (e) {
                // เบราเซอร์บางรุ่นบล็อกเสียงก่อนผู้ใช้อินเตอร์แอกทีฟ
            }
        }

        function playGameOverSound() {
            try {
                if (!audioCtx) return;
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(220, audioCtx.currentTime); // A3
                osc.frequency.linearRampToValueAtTime(110, audioCtx.currentTime + 0.5); // A2
                gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
                gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.5);
            } catch (e) {}
        }

        // เริ่มโหลดโมเดล Handtrack.js ตอนเข้าหน้าเว็บ
        const modelParams = {
            flipHorizontal: true,   // พลิกซ้ายขวาให้เหมือนส่องกระจก
            maxNumBoxes: 1,         // แทรกกิ้งเฉพาะมือหลักมือเดียวเพื่อความลื่นไหล
            iouThreshold: 0.5,
            scoreThreshold: 0.55     // ความเชื่อมั่นขั้นต่ำว่าเป็นมือ
        };

        // ดาวน์โหลดโมเดล
        handtrack.load(modelParams).then(lmodel => {
            model = lmodel;
            loaderOverlay.classList.add('hidden');
            startOverlay.classList.remove('hidden');
        }).catch(err => {
            console.error("โหลดโมเดลไม่สำเร็จ: ", err);
            loaderOverlay.innerHTML = `
                <div class="text-center p-6 bg-cyber-pink/20 border border-cyber-pink rounded-xl max-w-sm">
                    <p class="text-cyber-pink font-bold font-display text-lg mb-2">ERROR LOADING AR MODEL</p>
                    <p class="text-xs text-gray-400 mb-4">โหลดไลบรารีตรวจจับมือไม่สำเร็จ หรือเบราเซอร์ของคุณบล็อกฟีเจอร์นี้</p>
                    <button onclick="useMouseDirectly()" class="bg-white text-cyber-dark font-bold font-display px-4 py-2 rounded-lg text-xs uppercase cursor-pointer">
                        PLAY WITH MOUSE INSTEAD
                    </button>
                </div>
            `;
        });

        // ฟังก์ชันเริ่มกล้อง
        function initCamera() {
            startOverlay.classList.add('hidden');
            loaderOverlay.innerHTML = `
                <div class="w-12 h-12 border-4 border-cyber-blue border-t-transparent rounded-full animate-spin"></div>
                <p class="text-cyber-blue font-display font-bold text-sm">ACCESSING WEBCAM...</p>
                <p class="text-[11px] text-gray-500">กรุณาอนุญาตสิทธิ์การใช้งานกล้องในเบราเซอร์</p>
            `;
            loaderOverlay.classList.remove('hidden');

            handtrack.startVideo(video).then(status => {
                if (status) {
                    isCameraActive = true;
                    isMouseActive = false;
                    loaderOverlay.classList.add('hidden');
                    startOverlay.classList.remove('hidden');
                    startDetectionLoop();
                } else {
                    alert("เปิดกล้องล้มเหลว! สลับระบบไปใช้โหมดเมาส์อัตโนมัติ");
                    useMouseDirectly();
                }
            }).catch(err => {
                console.error("เกิดข้อผิดพลาดกล้อง", err);
                useMouseDirectly();
            });
        }

        // โหมดเมาส์ Fallback กรณีไม่มีกล้องหรือสปีดตรวจจับช้า
        function useMouseDirectly() {
            isCameraActive = false;
            isMouseActive = true;
            loaderOverlay.classList.add('hidden');
            startOverlay.classList.remove('hidden');
            
            // เปิดใช้งาน Marker ติดตามเมาส์
            canvas.addEventListener('mousemove', (e) => {
                const rect = canvas.getBoundingClientRect();
                pointer.x = (e.clientX - rect.left) * (canvas.width / rect.width);
                pointer.y = (e.clientY - rect.top) * (canvas.height / rect.height);
                pointer.active = true;
            });
        }

        document.getElementById('btn-camera').addEventListener('click', () => {
            if (!isCameraActive) {
                initCamera();
            }
        });

        document.getElementById('btn-mouse').addEventListener('click', () => {
            useMouseDirectly();
        });

        function useMouseDirectlyFromButton() {
            useMouseDirectly();
        }

        // เริ่มตรวจจับตำแหน่งมือ
        function startDetectionLoop() {
            if (!model || !isCameraActive) return;
            
            detectionInterval = setInterval(() => {
                model.detect(video).then(predictions => {
                    if (predictions && predictions.length > 0) {
                        const p = predictions[0];
                        // หาจุดศูนย์กลางของกรอบตรวจจับมือ
                        pointer.x = p.bbox[0] + p.bbox[2]/2;
                        pointer.y = p.bbox[1] + p.bbox[3]/2;
                        pointer.active = true;
                        
                        // อัปเดต Marker UI นอกแคนวาส
                        cursorTracker.style.left = `${(pointer.x / canvas.width) * 100}%`;
                        cursorTracker.style.top = `${(pointer.y / canvas.height) * 100}%`;
                        cursorTracker.classList.remove('hidden');
                    } else {
                        pointer.active = false;
                        cursorTracker.classList.add('hidden');
                    }
                });
            }, 50); // อัปเดตพิกัดมือทุกๆ 50ms
        }

        // ฟังก์ชันสร้างดาวสุ่มตำแหน่งในแกน X Y
        function spawnStar() {
            const size = Math.random() * 15 + 15; // 15px - 30px
            const colors = ['#00ffaa', '#00f0ff', '#ff0055', '#fff500'];
            const randomColor = colors[Math.floor(Math.random() * colors.length)];
            
            stars.push({
                x: Math.random() * (canvas.width - 60) + 30,
                y: Math.random() * (canvas.height - 60) + 30,
                size: size,
                pulse: 0,
                pulseSpeed: Math.random() * 0.1 + 0.05,
                color: randomColor,
                angle: Math.random() * Math.PI * 2,
                spinSpeed: (Math.random() - 0.5) * 0.05
            });
        }

        // สร้างเอฟเฟกต์อนุภาคกระจาย
        function spawnParticles(x, y, color) {
            for (let i = 0; i < 15; i++) {
                particles.push({
                    x: x,
                    y: y,
                    vx: (Math.random() - 0.5) * 8,
                    vy: (Math.random() - 0.5) * 8,
                    size: Math.random() * 4 + 1,
                    alpha: 1,
                    decay: Math.random() * 0.03 + 0.02,
                    color: color
                });
            }
        }

        // เริ่มจับเวลาการทดสอบ
        function startTimer() {
            timeLeft = 30;
            hudTimer.innerText = `${timeLeft}s`;
            hudTimer.classList.remove('text-cyber-pink');
            hudTimer.classList.add('text-cyber-accent');

            gameInterval = setInterval(() => {
                timeLeft--;
                hudTimer.innerText = `${timeLeft}s`;

                if (timeLeft <= 10) {
                    hudTimer.classList.remove('text-cyber-accent');
                    hudTimer.classList.add('text-cyber-pink');
                    hudTimer.classList.add('animate-pulse');
                }

                if (timeLeft <= 0) {
                    endGame();
                }
            }, 1000);
        }

        // หน้าต่างจบเกมและการเคลียร์พารามิเตอร์
        function endGame() {
            isGameRunning = false;
            clearInterval(gameInterval);
            if (loopRequestId) cancelAnimationFrame(loopRequestId);
            
            playGameOverSound();
            
            hudStats.classList.add('hidden');
            finalScore.innerText = score;
            gameoverOverlay.classList.remove('hidden');
            
            document.getElementById('saving-indicator').classList.remove('hidden');
            document.getElementById('saving-result').classList.add('hidden');

            // บันทึกคะแนนผ่าน API (save_score.php)
            fetch('save_score.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ score: score })
            })
            .then(res => res.json())
            .then(resData => {
                document.getElementById('saving-indicator').classList.add('hidden');
                const resultBox = document.getElementById('saving-result');
                const msgText = document.getElementById('saving-message');
                resultBox.classList.remove('hidden');
                
                if (resData.success) {
                    if (resData.is_new_record) {
                        msgText.className = "text-cyber-accent text-xs font-bold font-display uppercase tracking-wider glow-accent";
                        msgText.innerText = `🔥 NEW HIGH SCORE! สถิติใหม่สำเร็จ: ${resData.high_score} คะแนน!`;
                        
                        // อัปเดตสถิติในหน้าเพจด้วย
                        document.getElementById('nav-high-score').innerText = resData.high_score;
                    } else {
                        msgText.className = "text-cyber-blue text-xs font-bold";
                        msgText.innerText = `คะแนนบันทึกแล้ว! สถิติสูงสุดของคุณคือ ${resData.high_score}`;
                    }
                    
                    // เรียกโหลดทำเนียบผู้นำใหม่มาแสดง
                    refreshLeaderboard();
                } else {
                    msgText.className = "text-cyber-pink text-xs";
                    msgText.innerText = `ล้มเหลว: ${resData.error}`;
                }
            })
            .catch(err => {
                document.getElementById('saving-indicator').classList.add('hidden');
                const resultBox = document.getElementById('saving-result');
                const msgText = document.getElementById('saving-message');
                resultBox.classList.remove('hidden');
                msgText.className = "text-cyber-pink text-xs";
                msgText.innerText = "ไม่สามารถติดต่อเซิร์ฟเวอร์เพื่อเชื่อมต่อฐานข้อมูล";
                console.error(err);
            });
        }

        // ดึงทำเนียบผู้นำสดมาแสดงทันที
        function refreshLeaderboard() {
            fetch('get_leaderboard_api.php')
            .then(res => res.json())
            .then(board => {
                const container = document.getElementById('leaderboard-container');
                if (board && board.length > 0) {
                    let html = '';
                    board.forEach((player, idx) => {
                        const isCurrent = player.username.toLowerCase() === '<?php echo strtolower($username); ?>';
                        const rankClass = idx === 0 ? 'text-cyber-yellow' : (idx === 1 ? 'text-cyber-blue' : (idx === 2 ? 'text-cyber-pink' : 'text-gray-500'));
                        
                        html += `
                            <div class="flex items-center justify-between p-3 rounded-xl border border-cyber-light/40 bg-cyber-dark/40 hover:bg-cyber-light/20 transition duration-200">
                                <div class="flex items-center space-x-3">
                                    <span class="w-6 text-center font-display font-black text-xs ${rankClass}">#${idx + 1}</span>
                                    <span class="text-sm font-semibold text-white font-mono">${player.username}</span>
                                    ${isCurrent ? '<span class="text-[8px] bg-cyber-accent text-cyber-dark px-1.5 py-0.5 rounded uppercase font-bold font-display">YOU</span>' : ''}
                                </div>
                                <span class="text-sm font-bold text-cyber-accent font-display">${player.high_score} pts</span>
                            </div>
                        `;
                    });
                    container.innerHTML = html;
                }
            }).catch(e => {});
        }

        // เริ่มลูปแรนเดอร์หน้าจอเกม (Game Loop)
        function gameLoop() {
            if (!isGameRunning) return;
            
            // เคลียร์ Canvas ล้างเฟรมเก่า
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // วาดฟีดกล้องลงแคนวาสเป็นพื้นหลังในสไตล์กล้องมืดๆ เท่ๆ
            ctx.save();
            if (isCameraActive) {
                // พลิกกล้องซ้ายขวาให้หันตรงกับผู้เล่น (Mirror Mode)
                ctx.translate(canvas.width, 0);
                ctx.scale(-1, 1);
                ctx.globalAlpha = 0.45; // ความโปร่งใสของกล้อง
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            } else {
                // ถ้าสลับไปเมาส์ จะเป็นฉากหลังอวกาศมืด
                ctx.fillStyle = '#0a0b10';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // วาดเส้นตารางกริดไซไฟ
                ctx.strokeStyle = '#121622';
                ctx.lineWidth = 1;
                const gridSize = 40;
                for (let x = 0; x < canvas.width; x += gridSize) {
                    ctx.beginPath();
                    ctx.moveTo(x, 0);
                    ctx.lineTo(x, canvas.height);
                    ctx.stroke();
                }
                for (let y = 0; y < canvas.height; y += gridSize) {
                    ctx.beginPath();
                    ctx.moveTo(0, y);
                    ctx.lineTo(canvas.width, y);
                    ctx.stroke();
                }
            }
            ctx.restore();

            // จัดการวาดดาวและประมวลผลชนกัน (Collision Detection)
            for (let i = stars.length - 1; i >= 0; i--) {
                const s = stars[i];
                
                // เอฟเฟกต์กระพริบดวงดาว
                s.pulse += s.pulseSpeed;
                s.angle += s.spinSpeed;
                const radius = s.size / 2 + Math.sin(s.pulse) * 3;

                // วาดตัวดาว (รูปดาว 5 แฉก)
                ctx.save();
                ctx.translate(s.x, s.y);
                ctx.rotate(s.angle);
                ctx.shadowBlur = 15;
                ctx.shadowColor = s.color;
                
                ctx.fillStyle = s.color;
                ctx.beginPath();
                const spikes = 5;
                let rot = Math.PI / 2 * 3;
                let x = s.x;
                let y = s.y;
                const step = Math.PI / spikes;

                ctx.moveTo(0, -radius);
                for (let k = 0; k < spikes; k++) {
                    ctx.lineTo(Math.cos(rot) * radius, Math.sin(rot) * radius);
                    rot += step;
                    ctx.lineTo(Math.cos(rot) * (radius/2), Math.sin(rot) * (radius/2));
                    rot += step;
                }
                ctx.lineTo(0, -radius);
                ctx.closePath();
                ctx.fill();
                ctx.restore();

                // ตรวจสอบระยะห่างจาก Pointer มือหรือเมาส์
                if (pointer.active) {
                    const dist = Math.hypot(pointer.x - s.x, pointer.y - s.y);
                    // หากชนกันในระยะ
                    if (dist < radius + 25) {
                        playPointSound();
                        spawnParticles(s.x, s.y, s.color);
                        score++;
                        hudScore.innerText = score < 10 ? '0' + score : score;
                        
                        // เคลียร์ดาวที่ถูกกินแล้ว
                        stars.splice(i, 1);
                        
                        // สปอว์นดวงใหม่มาทันที
                        spawnStar();
                        continue;
                    }
                }
            }

            // ประมวลผลและวาดสะเก็ดเอฟเฟกต์ระเบิดดาว (Particles)
            for (let i = particles.length - 1; i >= 0; i--) {
                const p = particles[i];
                p.x += p.vx;
                p.y += p.vy;
                p.alpha -= p.decay;

                if (p.alpha <= 0) {
                    particles.splice(i, 1);
                    continue;
                }

                ctx.save();
                ctx.globalAlpha = p.alpha;
                ctx.fillStyle = p.color;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }

            // วาดพอยน์เตอร์ Marker ทับ (เมาส์ หรือ ส้มสัมผัส)
            if (pointer.active) {
                ctx.save();
                ctx.shadowBlur = 20;
                ctx.shadowColor = '#00ffaa';
                ctx.strokeStyle = '#00ffaa';
                ctx.lineWidth = 3;
                
                // วาดเป้าเล็ง HUD
                ctx.beginPath();
                ctx.arc(pointer.x, pointer.y, 20, 0, Math.PI * 2);
                ctx.stroke();
                
                ctx.beginPath();
                ctx.moveTo(pointer.x - 28, pointer.y);
                ctx.lineTo(pointer.x - 12, pointer.y);
                ctx.moveTo(pointer.x + 12, pointer.y);
                ctx.lineTo(pointer.x + 28, pointer.y);
                ctx.moveTo(pointer.x, pointer.y - 28);
                ctx.lineTo(pointer.x, pointer.y - 12);
                ctx.moveTo(pointer.x, pointer.y + 12);
                ctx.lineTo(pointer.x, pointer.y + 28);
                ctx.stroke();

                ctx.fillStyle = '#00ffaa';
                ctx.beginPath();
                ctx.arc(pointer.x, pointer.y, 4, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }

            loopRequestId = requestAnimationFrame(gameLoop);
        }

        // คอนโทรลเมื่อกดเริ่มเล่นท้าชิง
        document.getElementById('btn-start-game').addEventListener('click', () => {
            // ซ่อน Overlay เริ่มเล่น
            startOverlay.classList.add('hidden');
            gameoverOverlay.classList.add('hidden');
            hudStats.classList.remove('hidden');

            // รีเซ็ตค่าคะแนนและลูป
            score = 0;
            hudScore.innerText = '00';
            stars = [];
            particles = [];
            
            // สปอว์นดวงดาวเริ่มต้น 4 ดวงสุ่มบนจอ
            for (let i = 0; i < 4; i++) {
                spawnStar();
            }

            isGameRunning = true;
            startTimer();
            gameLoop();
        });

        // รีเพลย์เริ่มเล่นใหม่
        document.getElementById('btn-retry').addEventListener('click', () => {
            gameoverOverlay.classList.add('hidden');
            startOverlay.classList.remove('hidden');
        });
    </script>
</body>
</html>

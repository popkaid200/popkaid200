<?php
// db.php - เชื่อมต่อฐานข้อมูล MySQL ด้วย PDO
$host = 'localhost';
$dbname = 'esports_db';
$username = 'root';
$password = ''; // ค่าเริ่มต้นของ XAMPP มักจะเป็นค่าว่าง

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    // ตั้งค่าแสดงข้อผิดพลาด (Exception)
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // ตั้งค่าคืนค่าข้อมูลในรูปแบบ Array associative
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("เชื่อมต่อฐานข้อมูลล้มเหลว: " . $e->getMessage());
}
?>

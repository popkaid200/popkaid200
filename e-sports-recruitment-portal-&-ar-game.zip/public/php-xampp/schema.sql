-- สร้างฐานข้อมูล
CREATE DATABASE IF NOT EXISTS esports_db CHARACTER SET utf8 COLLATE utf8_general_ci;
USE esports_db;

-- สร้างตารางเก็บข้อมูลผู้สมัครและคะแนน
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    high_score INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_played_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ข้อมูลจำลองผู้เล่นดาวรุ่งระดับโปร (Seed Data)
INSERT INTO users (username, password, high_score) VALUES 
('CyberSentinel', '$2y$10$tZ2E/0W08Q50eT4Sve39i.V36gC9XGk75Z6S6TzR.gA7z9A7z9A7z', 85),
('NeonReaper', '$2y$10$tZ2E/0W08Q50eT4Sve39i.V36gC9XGk75Z6S6TzR.gA7z9A7z9A7z', 72),
('ViperGamer', '$2y$10$tZ2E/0W08Q50eT4Sve39i.V36gC9XGk75Z6S6TzR.gA7z9A7z9A7z', 59)
ON DUPLICATE KEY UPDATE high_score = VALUES(high_score);

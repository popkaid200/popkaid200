<?php
require_once 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Strictly require authorized login deck
if (!isset($_SESSION['user'])) {
    header('Location: register.php');
    exit;
}

$current_user = $_SESSION['user'];
include 'header.php';
?>

<main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col lg:flex-row gap-8">
    <!-- Left Column: Gameplay Canvas and controls -->
    <div class="flex-grow flex flex-col gap-6 lg:w-3/4">
        <!-- Live HUD Status -->
        <div class="bg-[#0A0A0A] border-2 border-neon-cyan/20 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
            <div class="flex items-center gap-2">
                <span class="text-slate-500 uppercase">RECRUIT:</span>
                <span class="text-neon-cyan font-bold uppercase"><?php echo htmlspecialchars($current_user['ign']); ?></span>
                <span class="text-slate-600">|</span>
                <span class="text-slate-500 uppercase">ROLE:</span>
                <span class="text-neon-purple font-bold uppercase"><?php echo htmlspecialchars($current_user['role']); ?></span>
            </div>
            <div class="flex gap-6">
                <div>SCORE: <span class="text-neon-cyan font-bold" id="hud-score">0000</span></div>
                <div>ACCURACY: <span class="text-neon-green font-bold" id="hud-accuracy">100%</span></div>
                <div>TIME: <span class="text-neon-pink font-bold" id="hud-time">45s</span></div>
            </div>
        </div>

        <!-- Canvas Game Container -->
        <div class="relative w-full aspect-video bg-black rounded-xl border-2 border-neon-cyan/20 overflow-hidden shadow-[0_0_30px_rgba(0,243,255,0.05)]" id="game-arena-container">
            <!-- Invisible Video Tag for MediaPipe -->
            <video id="webcam-video" class="absolute inset-0 w-full h-full object-cover hidden" playsinline muted></video>
            
            <!-- Main Game Canvas -->
            <canvas id="game-canvas" class="w-full h-full block relative z-10 cursor-crosshair"></canvas>

            <!-- Loading overlay for camera -->
            <div id="camera-loading" class="absolute inset-0 bg-[#050505]/90 z-20 hidden flex-col items-center justify-center text-center p-6">
                <div class="w-12 h-12 border-4 border-neon-cyan border-t-transparent rounded-full animate-spin mb-4"></div>
                <h4 class="font-display font-bold text-lg text-neon-cyan uppercase">CONNECTING TARGETING CAMERA</h4>
                <p class="text-xs text-slate-500 font-mono mt-1">Downloading tracking files & initializing handpose sensors...</p>
            </div>

            <!-- Start Overlay -->
            <div id="start-overlay" class="absolute inset-0 bg-[#050505]/95 z-20 flex flex-col items-center justify-center p-6 text-center space-y-6">
                <div class="space-y-2">
                    <h3 class="font-display font-black text-3xl text-slate-100 tracking-tighter italic uppercase">
                        VANGUARD TRIALS <br />
                        <span class="text-neon-cyan neon-text-cyan text-4xl">// READY TO LAUNCH</span>
                    </h3>
                    <p class="text-xs text-slate-400 max-w-sm font-mono uppercase tracking-wider">
                        Use your tactical mouse pointer to sweep and destroy star coordinates with micro-precision mechanics, or configure webcam tracking.
                    </p>
                </div>

                <div class="flex flex-col sm:flex-row gap-4 w-full max-w-xs justify-center">
                    <button id="btn-start-pointer" class="flex-1 py-3 px-4 bg-gradient-to-r from-neon-cyan to-neon-purple text-black font-display font-black text-xs tracking-wider uppercase rounded hover:scale-105 transition-transform cursor-pointer">
                        PLAY MOUSE MODE
                    </button>
                    <button id="btn-start-camera" class="flex-1 py-3 px-4 bg-cyber-gray border border-neon-cyan text-neon-cyan font-display font-black text-xs tracking-wider uppercase rounded hover:scale-105 hover:bg-neon-cyan/10 transition-all cursor-pointer">
                        PLAY CAMERA AR
                    </button>
                </div>
            </div>

            <!-- Game Over / Results Overlay -->
            <div id="results-overlay" class="absolute inset-0 bg-[#050505]/95 z-20 hidden flex flex-col items-center justify-center p-6 text-center space-y-6 border-4 border-neon-cyan/20">
                <div class="space-y-2">
                    <div class="text-xs font-mono text-neon-green uppercase tracking-widest font-black">Trial Sequence Complete</div>
                    <h3 class="font-display font-black text-4xl text-slate-100 tracking-tighter italic uppercase">
                        RESULT SUBMITTED
                    </h3>
                </div>

                <div class="grid grid-cols-2 gap-4 w-full max-w-xs bg-cyber-gray/80 border border-cyber-border rounded-lg p-4 font-mono text-xs">
                    <div>
                        <div class="text-slate-500 uppercase">FINAL SCORE</div>
                        <div class="text-2xl font-display font-black text-neon-cyan" id="res-score">0</div>
                    </div>
                    <div>
                        <div class="text-slate-500 uppercase">ACCURACY</div>
                        <div class="text-2xl font-display font-black text-neon-green" id="res-accuracy">0%</div>
                    </div>
                </div>

                <div class="flex gap-4 w-full max-w-xs justify-center">
                    <button id="btn-restart" class="flex-1 py-3 px-4 bg-gradient-to-r from-neon-cyan to-neon-purple text-black font-display font-black text-xs tracking-wider uppercase rounded hover:scale-105 transition-transform cursor-pointer">
                        TRY AGAIN
                    </button>
                    <a href="index.php" class="flex-1 py-3 px-4 bg-cyber-gray border border-cyber-border text-slate-300 font-display font-black text-xs tracking-wider uppercase rounded hover:scale-105 hover:bg-white/5 text-center flex items-center justify-center">
                        DASHBOARD
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Column: Instructions, Tactical HUD -->
    <div class="lg:w-1/4 flex flex-col gap-6">
        <!-- Settings Board -->
        <div class="bg-[#0A0A0A] border-2 border-neon-purple/20 rounded-xl p-6 corner-border">
            <h3 class="font-display font-bold text-lg text-slate-100 mb-4 uppercase tracking-wider flex items-center gap-2">
                <i data-lucide="sliders" class="text-neon-purple w-5 h-5"></i> Settings
            </h3>
            <div class="space-y-4 font-mono text-xs">
                <div>
                    <label class="block text-[10px] text-slate-500 uppercase tracking-widest mb-1">Input System</label>
                    <div class="grid grid-cols-2 gap-2">
                        <button id="opt-pointer" class="py-2 bg-neon-cyan/20 border border-neon-cyan text-neon-cyan text-[10px] font-bold uppercase rounded cursor-pointer">
                            MOUSE
                        </button>
                        <button id="opt-camera" class="py-2 bg-cyber-gray border border-white/10 hover:border-neon-cyan/40 text-[10px] uppercase rounded text-slate-400 cursor-pointer">
                            WEBCAM
                        </button>
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] text-slate-500 uppercase tracking-widest mb-1">Sound Master</label>
                    <button id="btn-toggle-sound" class="w-full py-2 bg-cyber-gray border border-white/10 text-slate-300 rounded uppercase flex items-center justify-center gap-2 cursor-pointer">
                        <i data-lucide="volume-2" class="w-4 h-4"></i> SOUND IS ON
                    </button>
                </div>
            </div>
        </div>

        <!-- Instructions Panel -->
        <div class="bg-[#0A0A0A] border-2 border-neon-pink/20 rounded-xl p-6 corner-border">
            <h3 class="font-display font-bold text-lg text-slate-100 mb-4 uppercase tracking-wider flex items-center gap-2">
                <i data-lucide="info" class="text-neon-pink w-5 h-5"></i> Directives
            </h3>
            <ul class="space-y-3 font-mono text-[11px] text-slate-400 uppercase leading-relaxed list-disc list-inside">
                <li>🎯 DESTROY SHINING BLUE AND PURPLE STAR COORDINATES BEFORE EXPIRED.</li>
                <li>⚡ GREEN HEALING STARS GRANT SCORE BONUS.</li>
                <li>⚠️ RED DESTRUCTIVE CORES REDUCE POINTS AND BREAK ACCURACY.</li>
                <li>🤖 WEBCAM TRACKS THE TIP OF YOUR INDEX FINGER. HOLD STEADY!</li>
            </ul>
        </div>
    </div>
</main>

<!-- Javascript Gameplay Engine -->
<script>
    // Audio Synthesizer (Zero asset dependency)
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    let soundEnabled = true;

    function playSynthSound(type) {
        if (!soundEnabled) return;
        try {
            const osc = audioCtx.createOscillator();
            const gainNode = audioCtx.createGain();
            osc.connect(gainNode);
            gainNode.connect(audioCtx.destination);

            if (type === 'hit') {
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(440, audioCtx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.1);
                gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
                gainNode.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.1);
            } else if (type === 'miss') {
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(150, audioCtx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(80, audioCtx.currentTime + 0.2);
                gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
                gainNode.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.25);
            } else if (type === 'heal') {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(600, audioCtx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.15);
                gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
                gainNode.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.15);
            } else if (type === 'danger') {
                osc.type = 'square';
                osc.frequency.setValueAtTime(300, audioCtx.currentTime);
                osc.frequency.setValueAtTime(100, audioCtx.currentTime + 0.1);
                gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
                gainNode.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.2);
            } else if (type === 'complete') {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
                osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.1); // E5
                osc.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.2); // G5
                osc.frequency.setValueAtTime(1046.50, audioCtx.currentTime + 0.3); // C6
                gainNode.gain.setValueAtTime(0.2, audioCtx.currentTime);
                gainNode.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.5);
            }
        } catch (e) {
            console.error('Synth Sound error:', e);
        }
    }

    // Toggle Sound Button
    const btnToggleSound = document.getElementById('btn-toggle-sound');
    btnToggleSound.addEventListener('click', () => {
        soundEnabled = !soundEnabled;
        if (soundEnabled) {
            btnToggleSound.innerHTML = '<i data-lucide="volume-2" class="w-4 h-4"></i> SOUND IS ON';
            btnToggleSound.className = "w-full py-2 bg-cyber-gray border border-white/10 text-slate-300 rounded uppercase flex items-center justify-center gap-2 cursor-pointer";
        } else {
            btnToggleSound.innerHTML = '<i data-lucide="volume-x" class="w-4 h-4"></i> SOUND MUTED';
            btnToggleSound.className = "w-full py-2 bg-neon-pink/10 border border-neon-pink/30 text-neon-pink rounded uppercase flex items-center justify-center gap-2 cursor-pointer";
        }
        lucide.createIcons();
    });

    // Inputs Settings Button Group
    let selectedMode = 'pointer';
    const optPointer = document.getElementById('opt-pointer');
    const optCamera = document.getElementById('opt-camera');

    function updateModeSelectionUI(mode) {
        selectedMode = mode;
        if (mode === 'pointer') {
            optPointer.className = "py-2 bg-neon-cyan/20 border border-neon-cyan text-neon-cyan text-[10px] font-bold uppercase rounded cursor-pointer";
            optCamera.className = "py-2 bg-cyber-gray border border-white/10 hover:border-neon-cyan/40 text-[10px] uppercase rounded text-slate-400 cursor-pointer";
        } else {
            optCamera.className = "py-2 bg-neon-cyan/20 border border-neon-cyan text-neon-cyan text-[10px] font-bold uppercase rounded cursor-pointer";
            optPointer.className = "py-2 bg-cyber-gray border border-white/10 hover:border-neon-cyan/40 text-[10px] uppercase rounded text-slate-400 cursor-pointer";
        }
    }

    optPointer.addEventListener('click', () => updateModeSelectionUI('pointer'));
    optCamera.addEventListener('click', () => updateModeSelectionUI('camera'));

    // Main Gameplay Logic
    const canvas = document.getElementById('game-canvas');
    const ctx = canvas.getContext('2d');
    const container = document.getElementById('game-arena-container');
    const video = document.getElementById('webcam-video');

    let gameActive = false;
    let score = 0;
    let totalTargetsSpawned = 0;
    let targetsHit = 0;
    let targetsMissed = 0;
    let timeLeft = 45;
    let targets = [];
    let particles = [];
    let timerInterval = null;

    // Tracking variables
    let cursorX = -100;
    let cursorY = -100;
    let handsInstance = null;
    let cameraInstance = null;

    // Resize canvas to fill container
    function resizeCanvas() {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    // Mouse/Touch Tracking Events on Canvas
    function getMousePos(evt) {
        const rect = canvas.getBoundingClientRect();
        return {
            x: ((evt.clientX - rect.left) / rect.width) * canvas.width,
            y: ((evt.clientY - rect.top) / rect.height) * canvas.height
        };
    }

    canvas.addEventListener('mousemove', (e) => {
        if (selectedMode === 'pointer') {
            const pos = getMousePos(e);
            cursorX = pos.x;
            cursorY = pos.y;
        }
    });

    canvas.addEventListener('click', (e) => {
        if (!gameActive) return;
        if (selectedMode === 'pointer') {
            const pos = getMousePos(e);
            triggerHitCheck(pos.x, pos.y);
        }
    });

    // Particle class
    function createExplosion(x, y, color) {
        for (let i = 0; i < 12; i++) {
            particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 8,
                vy: (Math.random() - 0.5) * 8,
                radius: Math.random() * 3 + 1,
                color: color,
                alpha: 1,
                decay: Math.random() * 0.05 + 0.02
            });
        }
    }

    // Target Class template
    function spawnTarget() {
        const types = ['normal', 'normal', 'normal', 'healing', 'danger'];
        const type = types[Math.floor(Math.random() * types.length)];
        const radius = type === 'healing' ? 18 : type === 'danger' ? 22 : 25;
        
        let color = '#00F3FF'; // cyan
        if (type === 'healing') color = '#39ff14'; // green
        if (type === 'danger') color = '#ff0055'; // pink / red

        targets.push({
            x: Math.random() * (canvas.width - radius * 4) + radius * 2,
            y: Math.random() * (canvas.height - radius * 4) + radius * 2,
            radius: radius,
            maxRadius: radius,
            pulse: 0,
            color: color,
            type: type,
            age: 0,
            lifespan: Math.random() * 1500 + 1500 // ms
        });
        totalTargetsSpawned++;
    }

    // Hit validation checks
    function triggerHitCheck(hx, hy) {
        let matched = false;
        for (let i = targets.length - 1; i >= 0; i--) {
            const t = targets[i];
            const dist = Math.hypot(t.x - hx, t.y - hy);
            if (dist <= t.radius + 15) {
                // Hit!
                targets.splice(i, 1);
                createExplosion(t.x, t.y, t.color);
                matched = true;
                
                if (t.type === 'normal') {
                    score += 100;
                    targetsHit++;
                    playSynthSound('hit');
                } else if (t.type === 'healing') {
                    score += 250;
                    targetsHit++;
                    timeLeft = Math.min(60, timeLeft + 3); // Time bonus
                    playSynthSound('heal');
                } else if (t.type === 'danger') {
                    score = Math.max(0, score - 200);
                    targetsMissed++;
                    playSynthSound('danger');
                }
                updateHUD();
                break;
            }
        }
        if (!matched) {
            targetsMissed++;
            updateHUD();
            playSynthSound('miss');
        }
    }

    // MediaPipe Handpose results callback
    function onHandposeResults(results) {
        if (!gameActive || selectedMode !== 'camera') return;
        
        if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
            const hand = results.multiHandLandmarks[0];
            // Get Index Finger Tip (Landmark 8)
            const indexTip = hand[8];
            // Mirror horizontal coordinate for comfortable play
            cursorX = (1 - indexTip.x) * canvas.width;
            cursorY = indexTip.y * canvas.height;

            // Trigger constant sweep collision check for camera (no click required)
            triggerCameraSweepCheck(cursorX, cursorY);
        }
    }

    function triggerCameraSweepCheck(cx, cy) {
        for (let i = targets.length - 1; i >= 0; i--) {
            const t = targets[i];
            const dist = Math.hypot(t.x - cx, t.y - cy);
            if (dist <= t.radius + 15) {
                // Target sweep-destroyed!
                targets.splice(i, 1);
                createExplosion(t.x, t.y, t.color);
                
                if (t.type === 'normal') {
                    score += 100;
                    targetsHit++;
                    playSynthSound('hit');
                } else if (t.type === 'healing') {
                    score += 250;
                    targetsHit++;
                    timeLeft = Math.min(60, timeLeft + 3);
                    playSynthSound('heal');
                } else {
                    score = Math.max(0, score - 200);
                    targetsMissed++;
                    playSynthSound('danger');
                }
                updateHUD();
            }
        }
    }

    // HUD Update
    function updateHUD() {
        document.getElementById('hud-score').textContent = String(score).padStart(4, '0');
        const attempts = targetsHit + targetsMissed;
        const accuracy = attempts > 0 ? Math.round((targetsHit / attempts) * 100) : 100;
        document.getElementById('hud-accuracy').textContent = accuracy + '%';
        document.getElementById('hud-time').textContent = timeLeft + 's';
    }

    // Camera Handpose Start
    async function startCameraTracking() {
        const loader = document.getElementById('camera-loading');
        loader.classList.remove('hidden');
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { width: 640, height: 480 }
            });
            video.srcObject = stream;
            video.classList.remove('hidden');
            await video.play();

            const HandsLib = window.Hands;
            const CameraLib = window.Camera;

            if (!HandsLib || !CameraLib) {
                throw new Error("Targeting models pending CDN delivery. Try pointer fallback.");
            }

            handsInstance = new HandsLib({
                locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
            });

            handsInstance.setOptions({
                maxNumHands: 1,
                modelComplexity: 1,
                minDetectionConfidence: 0.6,
                minTrackingConfidence: 0.6
            });

            handsInstance.onResults(onHandposeResults);

            cameraInstance = new CameraLib(video, {
                onFrame: async () => {
                    if (gameActive && selectedMode === 'camera') {
                        await handsInstance.send({ image: video });
                    }
                },
                width: 640,
                height: 480
            });

            await cameraInstance.start();
            loader.classList.add('hidden');
            return true;
        } catch (e) {
            console.error('AR camera tracking load failed:', e);
            alert("AR CAMERA UNAVAILABLE: Reverting to tactical mouse protocol. Check browser camera allowances.");
            loader.classList.add('hidden');
            updateModeSelectionUI('pointer');
            return false;
        }
    }

    function stopCameraTracking() {
        if (cameraInstance) {
            cameraInstance.stop();
            cameraInstance = null;
        }
        if (video.srcObject) {
            const tracks = video.srcObject.getTracks();
            tracks.forEach(t => t.stop());
            video.srcObject = null;
        }
        video.classList.add('hidden');
    }

    // Start Trial Loop
    async function startGame(mode) {
        updateModeSelectionUI(mode);
        
        if (mode === 'camera') {
            const ok = await startCameraTracking();
            if (!ok) return;
        }

        document.getElementById('start-overlay').classList.add('hidden');
        document.getElementById('results-overlay').classList.add('hidden');
        
        // Reset Stats
        score = 0;
        timeLeft = 45;
        targetsHit = 0;
        targetsMissed = 0;
        totalTargetsSpawned = 0;
        targets = [];
        particles = [];
        updateHUD();

        gameActive = true;
        audioCtx.resume();

        // Game tick Timer
        timerInterval = setInterval(() => {
            timeLeft--;
            updateHUD();
            if (timeLeft <= 0) {
                endGame();
            }
        }, 1000);

        // Spawn targets loop
        function spawnLoop() {
            if (!gameActive) return;
            if (targets.length < 5) {
                spawnTarget();
            }
            setTimeout(spawnLoop, Math.random() * 800 + 400);
        }
        spawnLoop();

        // Canvas animation frame run loop
        requestAnimationFrame(renderLoop);
    }

    // Main Canvas Render
    function renderLoop(timestamp) {
        if (!gameActive) return;

        // Clear with slight alpha to produce a neat trails sweep glow effect
        ctx.fillStyle = 'rgba(5, 5, 5, 0.3)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Render AR feed background if in camera mode
        if (selectedMode === 'camera' && video.readyState === video.HAVE_ENOUGH_DATA) {
            ctx.save();
            ctx.globalAlpha = 0.3; // blend camera under overlay grid
            // Mirror camera display
            ctx.translate(canvas.width, 0);
            ctx.scale(-1, 1);
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            ctx.restore();
        }

        // Render standard technical radar crossgrid
        ctx.strokeStyle = 'rgba(0, 243, 255, 0.05)';
        ctx.lineWidth = 1;
        // Verticals
        for (let x = 0; x < canvas.width; x += 40) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, canvas.height);
            ctx.stroke();
        }
        // Horizontals
        for (let y = 0; y < canvas.height; y += 40) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
        }

        // Render game targets
        const now = Date.now();
        for (let i = targets.length - 1; i >= 0; i--) {
            const t = targets[i];
            
            // Pulse calculations
            t.pulse = Math.sin(timestamp * 0.005) * 4;
            
            // Draw Target Core
            ctx.beginPath();
            ctx.arc(t.x, t.y, Math.max(2, t.radius + t.pulse), 0, Math.PI * 2);
            ctx.fillStyle = t.color;
            ctx.shadowBlur = 15;
            ctx.shadowColor = t.color;
            ctx.fill();
            ctx.shadowBlur = 0; // reset shadow

            // Outer Target Warning Bracket Ring
            ctx.beginPath();
            ctx.arc(t.x, t.y, t.radius + 10, 0, Math.PI * 2);
            ctx.strokeStyle = t.color + '44'; // transparency
            ctx.lineWidth = 2;
            ctx.stroke();

            // Direct Label for E-Sports technical look
            ctx.fillStyle = 'rgba(255,255,255,0.4)';
            ctx.font = '9px monospace';
            ctx.fillText(t.type.toUpperCase() + '_' + String(t.radius), t.x - 20, t.y - t.radius - 12);
        }

        // Render exploding particles
        for (let i = particles.length - 1; i >= 0; i--) {
            const p = particles[i];
            p.x += p.vx;
            p.y += p.vy;
            p.alpha -= p.decay;
            if (p.alpha <= 0) {
                particles.splice(i, 1);
                continue;
            }
            ctx.save();
            ctx.globalAlpha = p.alpha;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.fill();
            ctx.restore();
        }

        // Render custom targeting cursor crosshair
        if (cursorX > 0 && cursorY > 0) {
            ctx.strokeStyle = '#BC00FF';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            // Horizontal sweep line
            ctx.moveTo(cursorX - 15, cursorY);
            ctx.lineTo(cursorX + 15, cursorY);
            // Vertical sweep line
            ctx.moveTo(cursorX, cursorY - 15);
            ctx.lineTo(cursorX, cursorY + 15);
            ctx.stroke();

            // Core aiming dot
            ctx.beginPath();
            ctx.arc(cursorX, cursorY, 3, 0, Math.PI * 2);
            ctx.fillStyle = '#00F3FF';
            ctx.fill();
        }

        requestAnimationFrame(renderLoop);
    }

    // End Game Trial
    function endGame() {
        gameActive = false;
        clearInterval(timerInterval);
        stopCameraTracking();
        playSynthSound('complete');

        const attempts = targetsHit + targetsMissed;
        const accuracy = attempts > 0 ? Math.round((targetsHit / attempts) * 100) : 100;

        document.getElementById('res-score').textContent = score;
        document.getElementById('res-accuracy').textContent = accuracy + '%';
        document.getElementById('results-overlay').classList.remove('hidden');

        // Submit Score via AJAX/fetch
        submitScoreToCentralDatabase(score, selectedMode, accuracy);
    }

    function submitScoreToCentralDatabase(finalScore, mode, finalAccuracy) {
        const formData = new FormData();
        formData.append('score', finalScore);
        formData.append('input_mode', mode);
        formData.append('accuracy', finalAccuracy);

        fetch('save_score.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            console.log('Score matrix sync:', data);
        })
        .catch(err => {
            console.error('Matrix transmission failed:', err);
        });
    }

    // Setup action listeners
    document.getElementById('btn-start-pointer').addEventListener('click', () => startGame('pointer'));
    document.getElementById('btn-start-camera').addEventListener('click', () => startGame('camera'));
    document.getElementById('btn-restart').addEventListener('click', () => {
        document.getElementById('results-overlay').classList.add('hidden');
        document.getElementById('start-overlay').classList.remove('hidden');
    });
</script>

<?php include 'footer.php'; ?>

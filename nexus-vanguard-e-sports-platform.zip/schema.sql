-- Create Database for Nexus Vanguard Recruitment Matrix
CREATE DATABASE IF NOT EXISTS `nexus_vanguard` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `nexus_vanguard`;

-- Recruits Table (IGN, email, role, skill level)
CREATE TABLE IF NOT EXISTS `recruits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ign` varchar(50) NOT NULL UNIQUE,
  `email` varchar(100) NOT NULL UNIQUE,
  `role` varchar(50) NOT NULL,
  `skill_level` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Scores Table (Game score history)
CREATE TABLE IF NOT EXISTS `scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recruit_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `input_mode` varchar(20) NOT NULL,
  `accuracy` float NOT NULL,
  `played_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`recruit_id`) REFERENCES `recruits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed Data
INSERT INTO `recruits` (`id`, `ign`, `email`, `role`, `skill_level`) VALUES
(1, 'Viper_X', 'viper@vanguard.gg', 'Duelist', 'Radiant / Challenger'),
(2, 'ShadowRaze', 'raze@vanguard.gg', 'Initiator', 'Immortal / Grandmaster'),
(3, 'Neo_Reflex', 'neo@vanguard.gg', 'Flex', 'Diamond / Master');

INSERT INTO `scores` (`recruit_id`, `score`, `input_mode`, `accuracy`) VALUES
(1, 2450, 'pointer', 98.5),
(2, 2120, 'camera', 92.4),
(3, 1890, 'pointer', 89.2);

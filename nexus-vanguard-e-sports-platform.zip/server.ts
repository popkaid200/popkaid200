import express from 'express';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Simple custom cookie parser middleware
app.use((req, res, next) => {
  const cookieHeader = req.headers.cookie || '';
  const cookies: { [key: string]: string } = {};
  cookieHeader.split(';').forEach(cookie => {
    const parts = cookie.split('=');
    if (parts.length === 2) {
      cookies[parts[0].trim()] = parts[1].trim();
    }
  });
  (req as any).parsedCookies = cookies;
  next();
});

// Load DB
interface Recruit {
  id: number;
  ign: string;
  email: string;
  role: string;
  skill_level: string;
}

interface Score {
  id: number;
  recruit_id: number;
  score: number;
  input_mode: string;
  accuracy: number;
}

function loadDB() {
  const dbPath = path.join(process.cwd(), 'database.json');
  if (fs.existsSync(dbPath)) {
    return JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
  }
  return { recruits: [], scores: [] };
}

function saveDB(data: any) {
  const dbPath = path.join(process.cwd(), 'database.json');
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

// Emulate inclusion and simple PHP tags evaluation
function renderPhp(fileName: string, currentUser: Recruit | null): string {
  const filePath = path.join(process.cwd(), fileName);
  if (!fs.existsSync(filePath)) {
    return `File not found: ${fileName}`;
  }

  let content = fs.readFileSync(filePath, 'utf-8');

  // 1. Resolve includes
  const includeRegex = /<\?php\s+(?:include|require|include_once|require_once)\s+['"]([^'"]+)['"]\s*;\s*\?>/g;
  content = content.replace(includeRegex, (match, includeFile) => {
    return renderPhp(includeFile, currentUser);
  });

  // 2. Mock current user values
  if (currentUser) {
    const ifUserRegex = /<\?php\s+if\s*\(\$current_user\):\s*\?>([\s\S]*?)<\?php\s+else:\s*\?>([\s\S]*?)<\?php\s+endif;\s*\?>/g;
    content = content.replace(ifUserRegex, (match, ifBody, elseBody) => {
      return ifBody;
    });

    const ifUserOnlyRegex = /<\?php\s+if\s*\(\$current_user\):\s*\?>([\s\S]*?)<\?php\s+endif;\s*\?>/g;
    content = content.replace(ifUserOnlyRegex, (match, body) => {
      return body;
    });
  } else {
    const ifUserRegex = /<\?php\s+if\s*\(\$current_user\):\s*\?>([\s\S]*?)<\?php\s+else:\s*\?>([\s\S]*?)<\?php\s+endif;\s*\?>/g;
    content = content.replace(ifUserRegex, (match, ifBody, elseBody) => {
      return elseBody;
    });

    const ifUserOnlyRegex = /<\?php\s+if\s*\(\$current_user\):\s*\?>([\s\S]*?)<\?php\s+endif;\s*\?>/g;
    content = content.replace(ifUserOnlyRegex, (match, body) => {
      return '';
    });
  }

  // 3. Populate current user text
  if (currentUser) {
    content = content.replace(/<\?php\s+echo\s+htmlspecialchars\(\$current_user\['ign'\]\);\s*\?>/g, currentUser.ign);
    content = content.replace(/<\?php\s+echo\s+htmlspecialchars\(\$current_user\['role'\]\);\s*\?>/g, currentUser.role);
  }

  // 4. Handle index.php rankings loop
  if (fileName === 'index.php') {
    const db = loadDB();
    const rankings = db.scores.map((s: Score) => {
      const recruit = db.recruits.find((r: Recruit) => r.id === s.recruit_id);
      return {
        ign: recruit ? recruit.ign : 'Unknown',
        role: recruit ? recruit.role : 'Flex',
        score: s.score,
        input_mode: s.input_mode,
        accuracy: s.accuracy
      };
    }).sort((a: any, b: any) => b.score - a.score).slice(0, 10);

    let rankingsHtml = '';
    rankings.forEach((row: any, index: number) => {
      rankingsHtml += `
        <tr class="hover:bg-white/5 transition-colors">
            <td class="py-4 px-4 font-bold text-slate-400">
                #${index + 1}
            </td>
            <td class="py-4 px-4 text-slate-200 font-bold">
                ${row.ign}
            </td>
            <td class="py-4 px-4 text-slate-400">
                ${row.role}
            </td>
            <td class="py-4 px-4">
                <span class="px-2 py-0.5 rounded text-[10px] uppercase ${row.input_mode === 'camera' ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/40' : 'bg-neon-purple/20 text-neon-purple border border-neon-purple/40'}">
                    ${row.input_mode}
                </span>
            </td>
            <td class="py-4 px-4 text-neon-green">
                ${row.accuracy.toFixed(1)}%
            </td>
            <td class="py-4 px-4 text-right font-display font-bold text-neon-cyan text-sm">
                ${row.score.toLocaleString()}
            </td>
        </tr>
      `;
    });

    const rankingsRegex = /<\?php\s+if\s*\(count\(\$rankings\)\s*>\s*0\):\s*\?>([\s\S]*?)<\?php\s+endif;\s*\?>/g;
    content = content.replace(rankingsRegex, rankingsHtml);
  }

  // 5. Replace general helper tags
  content = content.replace(/<\?php\s+echo\s+date\('Y'\);\s*\?>/g, new Date().getFullYear().toString());
  content = content.replace(/<\?php\s+echo\s+date\('Y-m-d H:i:s'\);\s*\?>/g, new Date().toISOString().replace('T', ' ').substring(0, 19));

  // Strip remaining standard setup PHP tag lines at the top of files
  content = content.replace(/<\?php[\s\S]*?\?>/g, '');

  return content;
}

// Routing logic
app.get('/', (req, res) => {
  const cookies = (req as any).parsedCookies || {};
  const userId = cookies['user_id'];
  let currentUser: Recruit | null = null;
  if (userId) {
    const db = loadDB();
    currentUser = db.recruits.find((r: Recruit) => r.id === parseInt(userId)) || null;
  }
  res.send(renderPhp('index.php', currentUser));
});

app.get('/index.php', (req, res) => {
  const cookies = (req as any).parsedCookies || {};
  const userId = cookies['user_id'];
  let currentUser: Recruit | null = null;
  if (userId) {
    const db = loadDB();
    currentUser = db.recruits.find((r: Recruit) => r.id === parseInt(userId)) || null;
  }
  res.send(renderPhp('index.php', currentUser));
});

app.get('/register.php', (req, res) => {
  const cookies = (req as any).parsedCookies || {};
  const userId = cookies['user_id'];
  if (userId) {
    return res.redirect('/game.php');
  }
  res.send(renderPhp('register.php', null));
});

app.post('/register.php', (req, res) => {
  const { ign, email, role, skill_level } = req.body;
  const db = loadDB();

  let recruit = db.recruits.find((r: Recruit) => r.ign.toLowerCase() === ign.trim().toLowerCase() || r.email.toLowerCase() === email.trim().toLowerCase());
  
  if (!recruit) {
    const newId = db.recruits.length > 0 ? Math.max(...db.recruits.map((r: Recruit) => r.id)) + 1 : 1;
    recruit = {
      id: newId,
      ign: ign.trim().toUpperCase(),
      email: email.trim().toLowerCase(),
      role: role || 'Flex',
      skill_level: skill_level || 'Casual'
    };
    db.recruits.push(recruit);
    saveDB(db);
  }

  res.setHeader('Set-Cookie', `user_id=${recruit.id}; Path=/; Max-Age=900000`);
  res.redirect('/game.php');
});

app.get('/game.php', (req, res) => {
  const cookies = (req as any).parsedCookies || {};
  const userId = cookies['user_id'];
  if (!userId) {
    return res.redirect('/register.php');
  }
  const db = loadDB();
  const currentUser = db.recruits.find((r: Recruit) => r.id === parseInt(userId)) || null;
  if (!currentUser) {
    return res.redirect('/register.php');
  }
  res.send(renderPhp('game.php', currentUser));
});

app.post('/save_score.php', (req, res) => {
  const cookies = (req as any).parsedCookies || {};
  const userId = cookies['user_id'];
  if (!userId) {
    return res.status(401).json({ status: 'error', message: 'Unauthorized recruit' });
  }

  const { score, input_mode, accuracy } = req.body;
  const db = loadDB();
  const recruit = db.recruits.find((r: Recruit) => r.id === parseInt(userId));

  if (!recruit) {
    return res.status(401).json({ status: 'error', message: 'Recruit registry not found' });
  }

  const newId = db.scores.length > 0 ? Math.max(...db.scores.map((s: Score) => s.id)) + 1 : 1;
  const newScore: Score = {
    id: newId,
    recruit_id: recruit.id,
    score: parseInt(score || 0),
    input_mode: input_mode || 'pointer',
    accuracy: parseFloat(accuracy || 100)
  };

  db.scores.push(newScore);
  db.scores.sort((a: Score, b: Score) => b.score - a.score);
  saveDB(db);

  res.json({
    status: 'success',
    message: 'Score logged successfully',
    data: newScore
  });
});

app.get('/logout.php', (req, res) => {
  res.setHeader('Set-Cookie', 'user_id=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT');
  res.redirect('/index.php');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Node PHP-Emulator server running on port ${PORT}`);
});

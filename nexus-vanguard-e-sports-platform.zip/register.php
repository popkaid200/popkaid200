<?php
require_once 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if already logged in
if (isset($_SESSION['user'])) {
    header('Location: game.php');
    exit;
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ign = trim($_POST['ign'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? 'Flex';
    $skill_level = $_POST['skill_level'] ?? 'Casual';

    if (empty($ign) || empty($email)) {
        $error_message = 'IGN and Email are strictly required.';
    } else {
        try {
            // First check if user already exists
            $stmt = $pdo->prepare("SELECT * FROM recruits WHERE ign = ? OR email = ?");
            $stmt->execute([$ign, $email]);
            $existing = $stmt->fetch();

            if ($existing) {
                // If exists, log them in directly as that recruit (simulating frictionless e-sports trial session)
                $_SESSION['user'] = $existing;
                header('Location: game.php');
                exit;
            } else {
                // Insert new recruit
                $stmt = $pdo->prepare("INSERT INTO recruits (ign, email, role, skill_level) VALUES (?, ?, ?, ?)");
                $stmt->execute([$ign, $email, $role, $skill_level]);
                
                // Get inserted recruit
                $recruit_id = $pdo->lastInsertId();
                $stmt = $pdo->prepare("SELECT * FROM recruits WHERE id = ?");
                $stmt->execute([$recruit_id]);
                $_SESSION['user'] = $stmt->fetch();

                header('Location: game.php');
                exit;
            }
        } catch (\PDOException $e) {
            $error_message = 'Database registration error: ' . $e->getMessage();
        }
    }
}

include 'header.php';
?>

<main class="flex-grow flex items-center justify-center p-6">
    <div class="w-full max-w-md bg-[#0A0A0A] border-2 border-neon-purple/20 rounded-xl p-8 corner-border shadow-[0_0_50px_rgba(188,0,255,0.05)]">
        <div class="text-center space-y-2 mb-8">
            <h2 class="font-display font-black text-2xl text-slate-100 tracking-tighter italic uppercase">
                RECRUIT PROTOCOL <span class="text-neon-purple">//</span> SIGN-ON
            </h2>
            <p class="text-xs text-slate-400 font-mono uppercase tracking-wider">
                Authorized entry required for Nexus trial execution
            </p>
        </div>

        <?php if (!empty($error_message)): ?>
            <div class="p-3 mb-6 bg-neon-pink/10 border border-neon-pink/30 rounded text-xs font-mono text-neon-pink uppercase tracking-wide">
                <i data-lucide="alert-triangle" class="inline w-4 h-4 mr-1.5 align-text-bottom"></i>
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <form action="register.php" method="POST" class="space-y-6">
            <!-- IGN -->
            <div class="space-y-1.5">
                <label for="ign" class="block text-[11px] font-mono text-neon-cyan font-bold uppercase tracking-widest">
                    In-Game Name (IGN)
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <i data-lucide="gamepad-2" class="w-4 h-4"></i>
                    </div>
                    <input 
                        type="text" 
                        name="ign" 
                        id="ign" 
                        required 
                        placeholder="e.g. VIPER_X"
                        class="block w-full pl-10 pr-4 py-2.5 bg-[#111] border border-white/10 hover:border-neon-cyan/40 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan rounded text-sm font-mono text-white transition-all uppercase"
                    />
                </div>
            </div>

            <!-- Email -->
            <div class="space-y-1.5">
                <label for="email" class="block text-[11px] font-mono text-neon-cyan font-bold uppercase tracking-widest">
                    Comm Address (Email)
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </div>
                    <input 
                        type="email" 
                        name="email" 
                        id="email" 
                        required 
                        placeholder="e.g. recruit@nexus.gg"
                        class="block w-full pl-10 pr-4 py-2.5 bg-[#111] border border-white/10 hover:border-neon-cyan/40 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan rounded text-sm font-mono text-white transition-all"
                    />
                </div>
            </div>

            <!-- Roster Role -->
            <div class="space-y-1.5">
                <label for="role" class="block text-[11px] font-mono text-neon-purple font-bold uppercase tracking-widest">
                    Tactical Specialty (Role)
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <i data-lucide="shield" class="w-4 h-4"></i>
                    </div>
                    <select 
                        name="role" 
                        id="role"
                        class="block w-full pl-10 pr-4 py-2.5 bg-[#111] border border-white/10 hover:border-neon-purple/40 focus:border-neon-purple focus:outline-none focus:ring-1 focus:ring-neon-purple rounded text-sm font-mono text-white transition-all"
                    >
                        <option value="Duelist">Duelist (Fragger)</option>
                        <option value="Initiator">Initiator (Scout)</option>
                        <option value="Controller">Controller (Tactician)</option>
                        <option value="Sentinel">Sentinel (Defense)</option>
                        <option value="Flex">Flex Roster</option>
                    </select>
                </div>
            </div>

            <!-- Skill Level -->
            <div class="space-y-1.5">
                <label for="skill_level" class="block text-[11px] font-mono text-neon-purple font-bold uppercase tracking-widest">
                    Competitive Tier (Skill)
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <i data-lucide="trending-up" class="w-4 h-4"></i>
                    </div>
                    <select 
                        name="skill_level" 
                        id="skill_level"
                        class="block w-full pl-10 pr-4 py-2.5 bg-[#111] border border-white/10 hover:border-neon-purple/40 focus:border-neon-purple focus:outline-none focus:ring-1 focus:ring-neon-purple rounded text-sm font-mono text-white transition-all"
                    >
                        <option value="Radiant / Challenger">Radiant / Challenger</option>
                        <option value="Immortal / Grandmaster">Immortal / Grandmaster</option>
                        <option value="Diamond / Master">Diamond / Master</option>
                        <option value="Platinum / Diamond">Platinum / Diamond</option>
                        <option value="Gold / Silver">Gold / Silver</option>
                    </select>
                </div>
            </div>

            <!-- Submit Button -->
            <button 
                type="submit" 
                class="w-full py-3 bg-gradient-to-r from-neon-purple to-neon-cyan text-black font-display font-black text-sm tracking-wider uppercase rounded hover:scale-102 hover:shadow-[0_0_20px_rgba(0,243,255,0.3)] transition-all cursor-pointer"
            >
                INITIALIZE TRIAL CLEARANCE
            </button>
        </form>
    </div>
</main>

<?php include 'footer.php'; ?>

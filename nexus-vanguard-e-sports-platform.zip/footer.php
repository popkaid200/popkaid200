    <footer class="mt-auto border-t border-cyber-border bg-[#0A0A0A] py-8 text-center text-xs text-slate-500 font-mono">
        <div class="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
                &copy; <?php echo date('Y'); ?> NEXUS VANGUARD GLOBAL. ALL SYSTEM RIGHTS PERSISTED.
            </div>
            <div class="flex gap-6 text-slate-400">
                <a href="#" class="hover:text-neon-cyan transition-colors">// PRIVACY_PROTOCOL</a>
                <a href="#" class="hover:text-neon-cyan transition-colors">// SECURITY_CLEARANCE</a>
                <a href="schema.sql" target="_blank" class="text-neon-cyan hover:underline transition-colors">// VIEW_SQL_SCHEMA</a>
            </div>
        </div>
    </footer>
    <script>
        // Initialize Lucide Icons
        lucide.createIcons();

        // Simple Clock script
        setInterval(() => {
            const display = document.getElementById('live-time-display');
            if (display) {
                const now = new Date();
                const utcString = now.toISOString().replace('T', ' ').substring(0, 19);
                display.textContent = utcString + ' UTC';
            }
        }, 1000);
    </script>
</body>
</html>

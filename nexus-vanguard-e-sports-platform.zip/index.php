<?php
require_once 'db.php';
include 'header.php';

// Fetch Top 10 Highscores with recruit IGNs
$rankings = [];
try {
    $stmt = $pdo->query("
        SELECT recruits.ign, recruits.role, scores.score, scores.input_mode, scores.accuracy, scores.played_at 
        FROM scores 
        JOIN recruits ON scores.recruit_id = recruits.id 
        ORDER BY scores.score DESC 
        LIMIT 10
    ");
    $rankings = $stmt->fetchAll();
} catch (\PDOException $e) {
    // Silent fail or default rankings
}
?>

<main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-12 flex flex-col gap-12">
    <!-- Hero / Title Section -->
    <div class="text-center space-y-4 max-w-3xl mx-auto py-8">
        <div class="text-xs font-mono text-neon-cyan uppercase tracking-[0.2em] font-bold">
            Vanguard Scouting Protocol v4.8
        </div>
        <h1 class="font-display font-black text-4xl sm:text-5xl lg:text-6xl tracking-tighter leading-none italic uppercase text-slate-100">
            NEXUS VANGUARD <br />
            <span class="text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple neon-text-cyan">
                // TRIAL_01
            </span>
        </h1>
        <p class="text-[#E0E0E0] text-lg sm:text-xl leading-relaxed font-sans border-l-4 border-neon-purple pl-4 max-w-2xl mx-auto text-left md:text-center">
            Welcome to Nexus Vanguard E-Sports. We are searching for the next generation of top-tier players to join our professional team. Do you have the reflexes and the mechanics? Prove it in our AR trials.
        </p>
        
        <div class="pt-6">
            <?php if ($current_user): ?>
                <a href="game.php" class="inline-block px-8 py-4 bg-gradient-to-r from-neon-cyan to-neon-purple text-black font-display font-black text-lg tracking-wider uppercase hover:scale-105 hover:shadow-[0_0_25px_rgba(0,243,255,0.4)] transition-all rounded">
                    ENTER MATRIX TRIAL
                </a>
            <?php else: ?>
                <a href="register.php" class="inline-block px-8 py-4 bg-neon-pink text-white font-display font-black text-lg tracking-wider uppercase hover:scale-105 hover:shadow-[0_0_25px_rgba(255,0,85,0.4)] transition-all rounded">
                    REGISTER IGN TO TEST
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Features / Bento Info Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Feature 1 -->
        <div class="bg-[#0A0A0A] border-2 border-neon-cyan/20 rounded-xl p-6 corner-border hover:border-neon-cyan/50 transition-all">
            <div class="w-12 h-12 bg-neon-cyan/10 border border-neon-cyan/30 rounded flex items-center justify-center mb-4">
                <i data-lucide="sparkles" class="w-6 h-6 text-neon-cyan"></i>
            </div>
            <h3 class="font-display font-bold text-lg text-slate-100 mb-2">AR WEBCAM TRACKING</h3>
            <p class="text-xs text-slate-400 font-mono leading-relaxed uppercase">
                Using cutting-edge computer vision with MediaPipe, track your actual index finger in real time to target incoming nodes. Pure biological latency test.
            </p>
        </div>

        <!-- Feature 2 -->
        <div class="bg-[#0A0A0A] border-2 border-neon-purple/20 rounded-xl p-6 corner-border hover:border-neon-purple/50 transition-all">
            <div class="w-12 h-12 bg-neon-purple/10 border border-neon-purple/30 rounded flex items-center justify-center mb-4">
                <i data-lucide="mouse-pointer-click" class="w-6 h-6 text-neon-purple"></i>
            </div>
            <h3 class="font-display font-bold text-lg text-slate-100 mb-2">TACTICAL POINTER MODE</h3>
            <p class="text-xs text-slate-400 font-mono leading-relaxed uppercase">
                No camera? No problem. Switch to mouse sweep input mode to test micro-precision mechanical click accuracy. Ideal for FPS and MOBA specialists.
            </p>
        </div>

        <!-- Feature 3 -->
        <div class="bg-[#0A0A0A] border-2 border-neon-pink/20 rounded-xl p-6 corner-border hover:border-neon-pink/50 transition-all">
            <div class="w-12 h-12 bg-neon-pink/10 border border-neon-pink/30 rounded flex items-center justify-center mb-4">
                <i data-lucide="trophy" class="w-6 h-6 text-neon-pink"></i>
            </div>
            <h3 class="font-display font-bold text-lg text-slate-100 mb-2">VANGUARD LEADERBOARD</h3>
            <p class="text-xs text-slate-400 font-mono leading-relaxed uppercase">
                Submit and sync highscores directly to the central recruit matrix. Scout coordinators filter the top candidates daily for team roster openings.
            </p>
        </div>
    </div>

    <!-- Leaderboard Rankings -->
    <div class="bg-[#0A0A0A] border-2 border-neon-cyan/20 rounded-xl p-6 corner-border shadow-[0_0_50px_rgba(0,243,255,0.05)]">
        <div class="flex items-center justify-between mb-6">
            <h2 class="font-display font-black text-xl tracking-tighter italic text-neon-cyan uppercase flex items-center gap-2">
                <i data-lucide="award" class="text-neon-cyan w-5 h-5"></i>
                VANGUARD RANKINGS <span class="text-neon-purple">//</span> ACTIVE
            </h2>
            <a href="index.php" class="p-1.5 hover:bg-cyber-gray border border-cyber-border hover:border-neon-cyan rounded text-slate-400 hover:text-neon-cyan transition-all" title="Refresh">
                <i data-lucide="rotate-cw" class="w-4 h-4"></i>
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left font-mono text-xs">
                <thead>
                    <tr class="border-b border-cyber-border text-slate-500 uppercase tracking-wider">
                        <th class="py-3 px-4">Rank</th>
                        <th class="py-3 px-4">Recruit</th>
                        <th class="py-3 px-4">Role</th>
                        <th class="py-3 px-4">Input</th>
                        <th class="py-3 px-4">Accuracy</th>
                        <th class="py-3 px-4 text-right">Trial Score</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-cyber-border/40">
                    <?php if (count($rankings) > 0): ?>
                        <?php foreach ($rankings as $index => $row): ?>
                            <tr class="hover:bg-white/5 transition-colors">
                                <td class="py-4 px-4 font-bold text-slate-400">
                                    #<?php echo $index + 1; ?>
                                </td>
                                <td class="py-4 px-4 text-slate-200 font-bold">
                                    <?php echo htmlspecialchars($row['ign']); ?>
                                </td>
                                <td class="py-4 px-4 text-slate-400">
                                    <?php echo htmlspecialchars($row['role']); ?>
                                </td>
                                <td class="py-4 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] uppercase <?php echo $row['input_mode'] === 'camera' ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/40' : 'bg-neon-purple/20 text-neon-purple border border-neon-purple/40'; ?>">
                                        <?php echo htmlspecialchars($row['input_mode']); ?>
                                    </span>
                                </td>
                                <td class="py-4 px-4 text-neon-green">
                                    <?php echo number_format($row['accuracy'], 1); ?>%
                                </td>
                                <td class="py-4 px-4 text-right font-display font-bold text-neon-cyan text-sm">
                                    <?php echo number_format($row['score']); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="py-8 text-center text-slate-500 uppercase">
                                No matrix scores recorded yet. Be the first!
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<?php include 'footer.php'; ?>

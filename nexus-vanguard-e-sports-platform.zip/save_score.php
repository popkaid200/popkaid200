<?php
require_once 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

if (!isset($_SESSION['user'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized recruit clearance']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recruit_id = $_SESSION['user']['id'];
    $score = intval($_POST['score'] ?? 0);
    $input_mode = $_POST['input_mode'] ?? 'pointer';
    $accuracy = floatval($_POST['accuracy'] ?? 100.0);

    try {
        $stmt = $pdo->prepare("INSERT INTO scores (recruit_id, score, input_mode, accuracy) VALUES (?, ?, ?, ?)");
        $stmt->execute([$recruit_id, $score, $input_mode, $accuracy]);

        echo json_encode([
            'status' => 'success', 
            'message' => 'Roster score logged successfully',
            'data' => [
                'score' => $score,
                'accuracy' => $accuracy,
                'input_mode' => $input_mode
            ]
        ]);
        exit;
    } catch (\PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Matrix recording failure: ' . $e->getMessage()]);
        exit;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Method unauthorized']);
    exit;
}
?>

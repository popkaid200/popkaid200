/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface EEsportsUser {
  ign: string;
  username: string;
  passwordHash: string; // Stored as-is or simulated
  highScore: number;
  totalScore: number;
}

export interface GameStar {
  id: string;
  x: number; // Percentage width (0 to 100)
  y: number; // Percentage height (0 to 100)
  radius: number; // Radius in pixels
  points: number;
  color: string;
  spawnTime: number;
  lifetime: number; // duration in ms
  type: 'standard' | 'golden' | 'vanguard' | 'decaying';
}

export type ViewState = 'home' | 'register' | 'game';

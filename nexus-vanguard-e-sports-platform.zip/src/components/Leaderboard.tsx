import { useEffect, useState } from 'react';
import { Trophy, Shield, Zap, RefreshCw } from 'lucide-react';
import { EEsportsUser } from '../types';
import { playSound } from '../utils/audio';

export default function Leaderboard() {
  const [leaderboard, setLeaderboard] = useState<EEsportsUser[]>([]);

  const loadLeaderboard = () => {
    // Fetch users from localStorage
    const storedUsersString = localStorage.getItem('nexus_vanguard_users');
    let usersList: EEsportsUser[] = [];

    if (storedUsersString) {
      try {
        usersList = JSON.parse(storedUsersString);
      } catch (e) {
        console.error('Failed to parse users', e);
      }
    }

    // Default bots to make the leaderboard look highly competitive and alive!
    const defaultBots: EEsportsUser[] = [
      { ign: 'V1per_Shroud', username: 'viper', passwordHash: '123', highScore: 320, totalScore: 1250 },
      { ign: 'Neo_Faker', username: 'faker', passwordHash: '123', highScore: 290, totalScore: 1100 },
      { ign: 'S1mple_Acolyte', username: 's1mple', passwordHash: '123', highScore: 250, totalScore: 980 },
      { ign: 'Ghost_Aim', username: 'ghost', passwordHash: '123', highScore: 180, totalScore: 640 },
      { ign: 'Zero_Ping', username: 'ping', passwordHash: '123', highScore: 150, totalScore: 450 },
    ];

    // Merge actual users and default bots
    // For any user with the same IGN/username as bot, override with actual user data.
    const combined: EEsportsUser[] = [...usersList];
    defaultBots.forEach((bot) => {
      const exists = combined.some((u) => u.username === bot.username || u.ign.toLowerCase() === bot.ign.toLowerCase());
      if (!exists) {
        combined.push(bot);
      }
    });

    // Sort by highScore descending
    combined.sort((a, b) => b.highScore - a.highScore);
    setLeaderboard(combined);
  };

  useEffect(() => {
    loadLeaderboard();
    // Set up custom event to reload leaderboard when score changes
    window.addEventListener('scoreUpdated', loadLeaderboard);
    return () => {
      window.removeEventListener('scoreUpdated', loadLeaderboard);
    };
  }, []);

  const handleRefresh = () => {
    playSound('click');
    loadLeaderboard();
  };

  return (
    <div className="w-full bg-[#0A0A0A] border-2 border-neon-cyan/20 rounded-xl p-6 corner-border transition-all shadow-[0_0_50px_rgba(0,243,255,0.05)]" id="leaderboard-section">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <h2 className="font-display font-black text-xl tracking-tighter italic text-neon-cyan uppercase">
            VANGUARD RANKINGS <span className="text-neon-purple">//</span> ACTIVE
          </h2>
        </div>
        <button
          onClick={handleRefresh}
          className="p-1.5 hover:bg-cyber-gray border border-cyber-border hover:border-neon-cyan rounded text-slate-400 hover:text-neon-cyan transition-all cursor-pointer"
          title="Refresh Standings"
          id="btn-refresh-leaderboard"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <p className="text-xs text-slate-400 font-mono mb-4 border-b border-cyber-border pb-2 uppercase tracking-widest">
        SYSTEM RECRUITMENT STATUS: ACTIVE TRIALS
      </p>

      <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
        {leaderboard.map((user, index) => {
          const isTop3 = index < 3;
          const rankColors = [
            'from-amber-400 to-yellow-600 shadow-[0_0_10px_rgba(245,158,11,0.2)]', // Gold
            'from-slate-300 to-slate-500 shadow-[0_0_10px_rgba(148,163,184,0.2)]', // Silver
            'from-amber-700 to-amber-900 shadow-[0_0_10px_rgba(180,83,9,0.2)]',  // Bronze
          ];

          return (
            <div
              key={user.username}
              className={`flex items-center justify-between p-3 rounded-md transition-all ${
                isTop3 
                  ? 'bg-cyber-gray/90 border border-slate-700' 
                  : 'bg-cyber-gray/30 hover:bg-cyber-gray/50 border border-cyber-border'
              }`}
              id={`leaderboard-user-${user.username}`}
            >
              <div className="flex items-center gap-3">
                {/* Rank Badge */}
                <div
                  className={`w-7 h-7 rounded-sm flex items-center justify-center font-display font-bold text-sm ${
                    isTop3
                      ? `bg-gradient-to-br ${rankColors[index]} text-black`
                      : 'bg-cyber-border text-slate-400 border border-slate-800'
                  }`}
                >
                  {index + 1}
                </div>

                {/* Player IGN */}
                <div>
                  <div className="font-display font-bold tracking-wide text-sm flex items-center gap-1.5">
                    {user.ign}
                    {isTop3 && <Shield className="w-3.5 h-3.5 text-neon-cyan" />}
                  </div>
                  <div className="text-[10px] font-mono text-slate-500 uppercase">
                    ID: @{user.username}
                  </div>
                </div>
              </div>

              {/* High Score & Total points */}
              <div className="text-right">
                <div className="font-mono font-bold text-sm text-neon-cyan flex items-center justify-end gap-1">
                  <Zap className="w-3 h-3 text-neon-green" />
                  {user.highScore} <span className="text-[10px] text-slate-400 font-sans font-normal">PTS</span>
                </div>
                <div className="text-[10px] font-mono text-slate-400">
                  Total Accum: {user.totalScore}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { ShieldAlert, LogIn, UserPlus, Gamepad2, Skull, Eye, EyeOff } from 'lucide-react';
import { playSound } from '../utils/audio';
import { EEsportsUser } from '../types';

interface HomeViewProps {
  onNavigate: (view: 'home' | 'register' | 'game') => void;
  onLoginSuccess: (user: EEsportsUser) => void;
}

export default function HomeView({ onNavigate, onLoginSuccess }: HomeViewProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [infoMessage, setInfoMessage] = useState('');

  // Auto-set dummy guest account for easy demonstration if empty
  useEffect(() => {
    const existingUsers = localStorage.getItem('nexus_vanguard_users');
    if (!existingUsers) {
      const initialUsers: EEsportsUser[] = [
        {
          ign: 'Apex_Legend',
          username: 'guest',
          passwordHash: 'vanguard', // Stored simple plain text for this local prototype
          highScore: 120,
          totalScore: 350
        }
      ];
      localStorage.setItem('nexus_vanguard_users', JSON.stringify(initialUsers));
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!username.trim() || !password.trim()) {
      setError('Awaiting login inputs. Please enter credentials.');
      playSound('danger');
      return;
    }

    const storedUsersString = localStorage.getItem('nexus_vanguard_users');
    let usersList: EEsportsUser[] = [];
    if (storedUsersString) {
      try {
        usersList = JSON.parse(storedUsersString);
      } catch (err) {
        setError('Database corrupted. Re-initializing...');
        playSound('danger');
        return;
      }
    }

    const foundUser = usersList.find(
      (u) => u.username.toLowerCase() === username.trim().toLowerCase() && u.passwordHash === password
    );

    if (foundUser) {
      playSound('success');
      onLoginSuccess(foundUser);
      onNavigate('game');
    } else {
      setError('ACCESS DENIED: Invalid username or security passcode.');
      playSound('danger');
    }
  };

  const autofillDemo = () => {
    playSound('click');
    setUsername('guest');
    setPassword('vanguard');
    setInfoMessage('Demo credentials filled. Ready for login authorization!');
    setTimeout(() => setInfoMessage(''), 4000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center" id="home-view-container">
      {/* Left Column: Epic About / Lore Panel */}
      <div className="lg:col-span-7 space-y-6" id="lore-panel">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-neon-cyan/10 border border-neon-cyan/30 rounded text-neon-cyan text-xs font-mono tracking-widest uppercase">
          <Gamepad2 className="w-3.5 h-3.5 animate-pulse" />
          Vanguard Scouting Protocol v4.8
        </div>

        <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl tracking-tighter leading-none italic uppercase text-slate-100" id="main-heading">
          NEXUS VANGUARD <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple neon-text-cyan">
            // TRIAL_01
          </span>
        </h1>

        <p className="text-[#E0E0E0] text-lg sm:text-xl leading-relaxed font-sans border-l-4 border-neon-purple pl-4" id="about-intro-paragraph">
          Welcome to Nexus Vanguard E-Sports. We are searching for the next generation of top-tier players to join our professional team. Do you have the reflexes and the mechanics? Prove it in our AR trials.
        </p>

        <div className="grid grid-cols-2 gap-4 pt-4" id="stat-boxes">
          <div className="bg-cyber-gray/40 border border-cyber-border p-4 rounded-md">
            <div className="font-mono text-neon-cyan text-xs uppercase tracking-wider">Scouting Divisions</div>
            <div className="font-display font-bold text-2xl mt-1 text-slate-100">FPS / MOBA</div>
          </div>
          <div className="bg-cyber-gray/40 border border-cyber-border p-4 rounded-md">
            <div className="font-mono text-neon-green text-xs uppercase tracking-wider">Required Latency</div>
            <div className="font-display font-bold text-2xl mt-1 text-slate-100">&lt; 15 MS</div>
          </div>
        </div>

        {/* Dynamic cyber news ticker */}
        <div className="bg-cyber-dark border border-cyber-border rounded px-4 py-2 flex items-center gap-3 text-xs font-mono" id="news-ticker">
          <span className="w-2 h-2 rounded-full bg-neon-green animate-ping shrink-0" />
          <span className="text-neon-cyan uppercase font-bold shrink-0">[LIVE FEED]</span>
          <marquee className="text-slate-400">
            CHAMPIONSHIP RESERVES RECRUITING NOW // HAND TRACKING TRIALS SECURE OVER 400 RECRUIT ENTRIES // HIGH SCORE TO BE MATCHED AT 300+ PTS // PREPARE YOUR WEBCAM FOR ACCURATE AR POSITIONING
          </marquee>
        </div>
      </div>

      {/* Right Column: Portal Login Form */}
      <div className="lg:col-span-5 bg-cyber-dark/90 border border-cyber-border p-6 sm:p-8 rounded-lg corner-border shadow-xl backdrop-blur-md relative overflow-hidden scanline" id="login-panel">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-neon-purple/15 rounded border border-neon-purple/30">
            <Skull className="w-5 h-5 text-neon-purple" />
          </div>
          <div>
            <h2 className="font-display font-bold text-lg text-slate-100 uppercase tracking-wide">Secure Authorization</h2>
            <p className="text-xs text-slate-400 font-mono">AUTHORIZED PERSONNEL PORTAL</p>
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1.5">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-cyber-gray border border-cyber-border hover:border-neon-cyan/50 focus:border-neon-cyan focus:outline-none p-3 rounded text-sm text-slate-100 font-mono transition-all"
              placeholder="ENTER SECURE USERNAME"
              autoComplete="username"
              id="input-username"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1.5">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-cyber-gray border border-cyber-border hover:border-neon-cyan/50 focus:border-neon-cyan focus:outline-none p-3 pr-10 rounded text-sm text-slate-100 font-mono transition-all"
                placeholder="ENTER PASSPHRASE"
                autoComplete="current-password"
                id="input-password"
              />
              <button
                type="button"
                onClick={() => { playSound('click'); setShowPassword(!showPassword); }}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-neon-cyan"
                id="btn-toggle-password"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3 bg-neon-pink/10 border border-neon-pink/30 text-neon-pink text-xs font-mono rounded flex items-center gap-2" id="login-error-msg">
              <ShieldAlert className="w-4 h-4 shrink-0 animate-bounce" />
              <span>{error}</span>
            </div>
          )}

          {infoMessage && (
            <div className="p-3 bg-neon-green/10 border border-neon-green/30 text-neon-green text-xs font-mono rounded" id="login-info-msg">
              {infoMessage}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-neon-cyan to-neon-purple hover:from-neon-cyan/80 hover:to-neon-purple/80 text-black font-display font-extrabold uppercase py-3 rounded tracking-wider transition-all shadow-[0_0_15px_rgba(0,240,255,0.25)] flex items-center justify-center gap-2 cursor-pointer"
            id="btn-submit-login"
          >
            <LogIn className="w-4 h-4" />
            Establish Connection
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-cyber-border space-y-4 text-center">
          <p className="text-xs text-slate-400">First time in our sector?</p>
          
          <button
            onClick={() => {
              playSound('click');
              onNavigate('register');
            }}
            className="w-full border border-neon-purple hover:border-neon-cyan bg-neon-purple/5 hover:bg-neon-cyan/5 text-neon-purple hover:text-neon-cyan font-display font-semibold uppercase py-2.5 rounded tracking-wide transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
            id="btn-register-redirect"
          >
            <UserPlus className="w-4 h-4" />
            Register / Join Now
          </button>

          {/* Quick Demo Assist */}
          <button
            onClick={autofillDemo}
            className="text-[11px] font-mono text-slate-500 hover:text-neon-green transition-all underline cursor-pointer"
            type="button"
            id="btn-demo-fill"
          >
            Tactical Override: Use Guest Demo Account
          </button>
        </div>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { UserPlus, ArrowLeft, CheckCircle2, ShieldAlert, Cpu, Award } from 'lucide-react';
import { playSound } from '../utils/audio';
import { EEsportsUser } from '../types';

interface RegisterViewProps {
  onNavigate: (view: 'home' | 'register' | 'game') => void;
}

export default function RegisterView({ onNavigate }: RegisterViewProps) {
  const [ign, setIgn] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validations
    if (!ign.trim()) {
      setError('Player identity tag (IGN) is required.');
      playSound('danger');
      return;
    }
    if (!username.trim()) {
      setError('Vanguard secure username is required.');
      playSound('danger');
      return;
    }
    if (username.trim().toLowerCase() === 'guest') {
      setError('Reserved keyword. Choose a different username.');
      playSound('danger');
      return;
    }
    if (password.length < 4) {
      setError('Passphrase must be at least 4 alphanumeric characters.');
      playSound('danger');
      return;
    }
    if (password !== confirmPassword) {
      setError('Security passphrase confirmation mismatch.');
      playSound('danger');
      return;
    }

    // Load existing database
    const storedUsersString = localStorage.getItem('nexus_vanguard_users');
    let usersList: EEsportsUser[] = [];
    if (storedUsersString) {
      try {
        usersList = JSON.parse(storedUsersString);
      } catch (err) {
        usersList = [];
      }
    }

    // Check if username already exists
    const userExists = usersList.some(
      (u) => u.username.toLowerCase() === username.trim().toLowerCase()
    );
    if (userExists) {
      setError('USERNAME DECLARED: Account already logged in global registry.');
      playSound('danger');
      return;
    }

    // Check if IGN already exists
    const ignExists = usersList.some(
      (u) => u.ign.toLowerCase() === ign.trim().toLowerCase()
    );
    if (ignExists) {
      setError('IGN TAKEN: This callsign is active under another athlete.');
      playSound('danger');
      return;
    }

    // Create and save new user
    const newUser: EEsportsUser = {
      ign: ign.trim(),
      username: username.trim(),
      passwordHash: password, // For simulation
      highScore: 0,
      totalScore: 0
    };

    usersList.push(newUser);
    localStorage.setItem('nexus_vanguard_users', JSON.stringify(usersList));

    // Trigger leaderboard update event
    window.dispatchEvent(new Event('scoreUpdated'));

    playSound('success');
    setIsSuccess(true);
  };

  return (
    <div className="max-w-md mx-auto" id="register-view-container">
      {!isSuccess ? (
        <div className="bg-cyber-dark/95 border border-cyber-border p-6 sm:p-8 rounded-lg corner-border shadow-xl backdrop-blur-md relative overflow-hidden scanline" id="reg-form-panel">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-neon-cyan/15 rounded border border-neon-cyan/30">
                <UserPlus className="w-5 h-5 text-neon-cyan" />
              </div>
              <div>
                <h2 className="font-display font-bold text-lg text-slate-100 uppercase tracking-wide">Recruit Registration</h2>
                <p className="text-xs text-slate-400 font-mono">INITIATE COMBAT IDENTIFICATION</p>
              </div>
            </div>
            <button
              onClick={() => { playSound('click'); onNavigate('home'); }}
              className="text-xs font-mono text-slate-400 hover:text-neon-cyan flex items-center gap-1 transition-all"
              id="btn-back-to-login"
            >
              <ArrowLeft className="w-3 h-3" /> LOGIN
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1">
                In-Game Name (IGN)
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={ign}
                  onChange={(e) => setIgn(e.target.value)}
                  className="w-full bg-cyber-gray border border-cyber-border hover:border-neon-cyan/50 focus:border-neon-cyan focus:outline-none p-3 pl-10 rounded text-sm text-slate-100 font-mono transition-all"
                  placeholder="e.g., FAKER_ACOLITE"
                  id="reg-input-ign"
                />
                <Award className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-500" />
              </div>
              <p className="text-[10px] text-slate-500 font-mono mt-1">This is your public callsign visible on the score list.</p>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1">
                Username
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-cyber-gray border border-cyber-border hover:border-neon-cyan/50 focus:border-neon-cyan focus:outline-none p-3 pl-10 rounded text-sm text-slate-100 font-mono transition-all"
                  placeholder="SECURE LOGIN CREDENTIAL"
                  autoComplete="username"
                  id="reg-input-username"
                />
                <Cpu className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-500" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1">
                Secure Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-cyber-gray border border-cyber-border hover:border-neon-cyan/50 focus:border-neon-cyan focus:outline-none p-3 rounded text-sm text-slate-100 font-mono transition-all"
                placeholder="MINIMUM 4 CHARACTERS"
                autoComplete="new-password"
                id="reg-input-password"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1">
                Confirm Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-cyber-gray border border-cyber-border hover:border-neon-cyan/50 focus:border-neon-cyan focus:outline-none p-3 rounded text-sm text-slate-100 font-mono transition-all"
                placeholder="CONFIRM SECURE PASSPHRASE"
                autoComplete="new-password"
                id="reg-input-confirm"
              />
            </div>

            {error && (
              <div className="p-3 bg-neon-pink/10 border border-neon-pink/30 text-neon-pink text-xs font-mono rounded flex items-center gap-2" id="reg-error-msg">
                <ShieldAlert className="w-4 h-4 shrink-0 animate-bounce" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-neon-purple to-neon-pink hover:from-neon-purple/80 hover:to-neon-pink/80 text-white font-display font-bold uppercase py-3 rounded tracking-wider transition-all shadow-[0_0_15px_rgba(189,0,255,0.25)] flex items-center justify-center gap-2 cursor-pointer"
              id="btn-reg-submit"
            >
              Establish Contract
            </button>
          </form>
        </div>
      ) : (
        <div className="bg-cyber-dark/95 border border-neon-green/40 p-8 rounded-lg corner-border shadow-[0_0_20px_rgba(57,255,20,0.15)] text-center space-y-6 relative overflow-hidden" id="reg-success-panel">
          <div className="w-16 h-16 bg-neon-green/10 border border-neon-green/40 rounded-full flex items-center justify-center mx-auto text-neon-green animate-pulse">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h2 className="font-display font-black text-2xl text-neon-green tracking-wide uppercase">RECRUIT ENLISTED</h2>
            <p className="text-sm text-slate-400 font-mono uppercase tracking-widest">
              PLAYER FILE GENERATED SUCCESSFULLY
            </p>
          </div>

          <div className="bg-cyber-gray/60 border border-cyber-border p-4 rounded text-left space-y-2 font-mono text-xs text-slate-300">
            <div><span className="text-slate-500">CALLSIGN:</span> <span className="text-neon-cyan font-bold">{ign}</span></div>
            <div><span className="text-slate-500">IDENTIFIER:</span> <span className="text-slate-100">@{username}</span></div>
            <div><span className="text-slate-500">ACCESS RANK:</span> <span className="text-neon-purple font-bold">VANGUARD INITIATE</span></div>
            <div><span className="text-slate-500">TEST STATUS:</span> <span className="text-neon-green font-bold animate-pulse">READY FOR AR TRIALS</span></div>
          </div>

          <button
            onClick={() => {
              playSound('click');
              onNavigate('home');
            }}
            className="w-full bg-neon-green text-black font-display font-extrabold uppercase py-3 rounded tracking-wider hover:bg-neon-green/80 transition-all shadow-[0_0_15px_rgba(57,255,20,0.25)] cursor-pointer"
            id="btn-return-login"
          >
            Go to Login Portal
          </button>
        </div>
      )}
    </div>
  );
}

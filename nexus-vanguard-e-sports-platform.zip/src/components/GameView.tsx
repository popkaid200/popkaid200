import React, { useEffect, useRef, useState } from 'react';
import { LogOut, Camera, MousePointerClick, Play, RotateCcw, Award, Zap, Crosshair, Sparkles, HelpCircle } from 'lucide-react';
import { playSound } from '../utils/audio';
import { EEsportsUser, GameStar } from '../types';

interface GameViewProps {
  currentUser: EEsportsUser;
  onLogout: () => void;
  onUpdateUserStats: (updatedUser: EEsportsUser) => void;
}

export default function GameView({ currentUser, onLogout, onUpdateUserStats }: GameViewProps) {
  // Game states
  const [inputMode, setInputMode] = useState<'camera' | 'pointer'>('pointer');
  const [gameActive, setGameActive] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30); // 30 second rounds
  const [isRoundMode, setIsRoundMode] = useState(true); // timed vs sandbox
  const [cameraLoading, setCameraLoading] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [handDetected, setHandDetected] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Refs for AR and Rendering
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointerPosRef = useRef({ x: 200, y: 150 }); // normalized to canvas size or raw
  const starsRef = useRef<GameStar[]>([]);
  const hitParticlesRef = useRef<{x: number; y: number; color: string; life: number}[]>([]);
  const lastTimeRef = useRef<number>(0);
  const rafIdRef = useRef<number | null>(null);
  const cameraInstanceRef = useRef<any>(null);
  const handsInstanceRef = useRef<any>(null);

  // Load High Score on Mount
  const [personalBest, setPersonalBest] = useState(currentUser.highScore);
  const [accumulatedPoints, setAccumulatedPoints] = useState(currentUser.totalScore);

  // Initialize canvas size and target star
  useEffect(() => {
    // Generate first star
    spawnStar();

    return () => {
      stopCameraAndTracking();
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
    };
  }, []);

  // Update loop for rendering and physics
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize handler
    const resizeCanvas = () => {
      canvas.width = 640;
      canvas.height = 480;
    };
    resizeCanvas();

    const gameLoop = (timestamp: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = timestamp;
      const deltaTime = timestamp - lastTimeRef.current;
      lastTimeRef.current = timestamp;

      // Update and draw
      renderGame(ctx, canvas, deltaTime);

      rafIdRef.current = requestAnimationFrame(gameLoop);
    };

    rafIdRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
    };
  }, [gameActive, inputMode, handDetected, cameraActive]);

  // Timed Mode Timer
  useEffect(() => {
    let timerId: any;
    if (gameActive && isRoundMode && timeLeft > 0) {
      timerId = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerId);
            endGameRound();
            return 0;
          }
          if (prev <= 6) {
            playSound('danger'); // Countdown warning beep
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [gameActive, isRoundMode, timeLeft]);

  // Handle Input Mode Swap
  const handleModeSwap = async (mode: 'camera' | 'pointer') => {
    playSound('click');
    setInputMode(mode);
    setErrorMessage('');

    if (mode === 'camera') {
      await startCameraAndTracking();
    } else {
      stopCameraAndTracking();
    }
  };

  // Start Camera and MediaPipe Hands
  const startCameraAndTracking = async () => {
    setCameraLoading(true);
    setCameraActive(false);
    setErrorMessage('');

    try {
      const video = videoRef.current;
      if (!video) throw new Error('Webcam container unavailable.');

      // Check MediaPipe availability in window
      const mpHands = (window as any).Hands;
      const mpCamera = (window as any).Camera;

      if (!mpHands || !mpCamera) {
        throw new Error('MediaPipe Vision model is loading or blocked by network. Try pointer fallback mode.');
      }

      // Request stream to verify camera hardware permission before starting MediaPipe
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 }
      });
      video.srcObject = stream;
      await video.play();

      // Initialize MediaPipe Hands
      const hands = new mpHands({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
      });

      hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.6,
        minTrackingConfidence: 0.6
      });

      hands.onResults(onHandposeResults);
      handsInstanceRef.current = hands;

      // Initialize Camera Utility
      const camera = new mpCamera(video, {
        onFrame: async () => {
          if (handsInstanceRef.current) {
            await handsInstanceRef.current.send({ image: video });
          }
        },
        width: 640,
        height: 480
      });

      cameraInstanceRef.current = camera;
      await camera.start();
      
      setCameraActive(true);
      setCameraLoading(false);
      playSound('success');
    } catch (err: any) {
      console.error(err);
      setCameraLoading(false);
      setCameraActive(false);
      setInputMode('pointer');
      setErrorMessage(
        err.name === 'NotAllowedError' || err.message?.includes('permission')
          ? 'CAMERA ACCESS BLOCKED: Please grant camera access permissions in your browser bar.'
          : err.message || 'Failed to start AR camera tracking.'
      );
      playSound('danger');
    }
  };

  // Stop Camera Streams
  const stopCameraAndTracking = () => {
    try {
      if (cameraInstanceRef.current) {
        cameraInstanceRef.current.stop();
        cameraInstanceRef.current = null;
      }
      if (handsInstanceRef.current) {
        handsInstanceRef.current.close();
        handsInstanceRef.current = null;
      }
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
        videoRef.current.srcObject = null;
      }
    } catch (e) {
      console.warn('Error during camera teardown', e);
    }
    setCameraActive(false);
    setHandDetected(false);
  };

  // Callback for MediaPipe Hand Results
  const onHandposeResults = (results: any) => {
    if (!results) return;

    if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
      setHandDetected(true);
      
      // Landmark index 8 is the Index Finger Tip
      const landmarks = results.multiHandLandmarks[0];
      const indexFingerTip = landmarks[8];
      
      const canvas = canvasRef.current;
      if (canvas && indexFingerTip) {
        // Mirrored X translation to make interaction natural (webcam mirror)
        const x = (1 - indexFingerTip.x) * canvas.width;
        const y = indexFingerTip.y * canvas.height;
        
        pointerPosRef.current = { x, y };

        // Process collisions actively in game
        if (gameActive) {
          checkTargetCollisions(x, y);
        }
      }
    } else {
      setHandDetected(false);
    }
  };

  // Spawn Target Star
  const spawnStar = () => {
    const starTypes: Array<GameStar['type']> = ['standard', 'standard', 'standard', 'standard', 'golden', 'decaying'];
    const selectedType = starTypes[Math.floor(Math.random() * starTypes.length)];

    let points = 10;
    let color = '#00f0ff'; // Neon Cyan
    let lifetime = 6000; // 6 seconds default

    if (selectedType === 'golden') {
      points = 20;
      color = '#ffd700'; // Pure gold
      lifetime = 4500;
    } else if (selectedType === 'decaying') {
      points = 15;
      color = '#ff0055'; // Intense red
      lifetime = 3500;
    }

    const newStar: GameStar = {
      id: Math.random().toString(),
      x: 10 + Math.random() * 80, // Percentage range 10-90% to avoid extreme edges
      y: 15 + Math.random() * 70, // Percentage range 15-85%
      radius: selectedType === 'golden' ? 16 : 20,
      points,
      color,
      spawnTime: Date.now(),
      lifetime,
      type: selectedType
    };

    starsRef.current = [newStar];
  };

  // Mouse/Touch Pointer Interaction fallback
  const handlePointerMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (inputMode !== 'pointer') return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    pointerPosRef.current = { x, y };

    if (gameActive) {
      checkTargetCollisions(x, y);
    }
  };

  // Detect Star Collisions
  const checkTargetCollisions = (cursorX: number, cursorY: number) => {
    const stars = starsRef.current;
    const canvas = canvasRef.current;
    if (!canvas) return;

    stars.forEach((star) => {
      // Calculate star pixel position
      const starX = (star.x / 100) * canvas.width;
      const starY = (star.y / 100) * canvas.height;

      // Distance calculation
      const dx = cursorX - starX;
      const dy = cursorY - starY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Star hit boundary (star radius + fuzzy buffer pointer size)
      const hitRadius = star.radius + 15;

      if (dist < hitRadius) {
        // Trigger capture events
        handleStarCapture(star);
      }
    });
  };

  // Process Successful Capture
  const handleStarCapture = (star: GameStar) => {
    // Web audio fx triggers
    if (star.type === 'golden') {
      playSound('golden');
    } else if (star.type === 'decaying') {
      playSound('capture');
    } else {
      playSound('capture');
    }

    // Accumulate points
    const pointsGained = star.points;
    setScore((prev) => prev + pointsGained);

    // Save and dispatch to localStorage actively
    const updatedAccumulated = accumulatedPoints + pointsGained;
    setAccumulatedPoints(updatedAccumulated);

    // Hit particle explosion FX
    const canvas = canvasRef.current;
    if (canvas) {
      const starX = (star.x / 100) * canvas.width;
      const starY = (star.y / 100) * canvas.height;
      createHitParticles(starX, starY, star.color);
    }

    // Refresh star target instantly
    spawnStar();
  };

  // Particle Explosions
  const createHitParticles = (x: number, y: number, color: string) => {
    for (let i = 0; i < 12; i++) {
      hitParticlesRef.current.push({
        x,
        y,
        color,
        life: 1.0 // Normalized life value decaying inside render loop
      });
    }
  };

  // Start Reflex Trial
  const startGame = () => {
    playSound('powerup');
    setScore(0);
    setTimeLeft(30);
    setGameActive(true);
    spawnStar();
  };

  // Game over state
  const endGameRound = () => {
    setGameActive(false);
    playSound('gameover');

    // Process high scores
    let finalPB = personalBest;
    if (score > personalBest) {
      finalPB = score;
      setPersonalBest(score);
    }

    // Update database
    const storedUsersString = localStorage.getItem('nexus_vanguard_users');
    if (storedUsersString) {
      try {
        const usersList: EEsportsUser[] = JSON.parse(storedUsersString);
        const matchIndex = usersList.findIndex((u) => u.username === currentUser.username);

        if (matchIndex !== -1) {
          // Keep highest score, accumulate total points
          const updatedUser: EEsportsUser = {
            ...usersList[matchIndex],
            highScore: Math.max(usersList[matchIndex].highScore, score),
            totalScore: usersList[matchIndex].totalScore + score
          };

          usersList[matchIndex] = updatedUser;
          localStorage.setItem('nexus_vanguard_users', JSON.stringify(usersList));
          
          // Propagate back to parent state
          onUpdateUserStats(updatedUser);

          // Dispatch event to refresh live leaderboard
          window.dispatchEvent(new Event('scoreUpdated'));
        }
      } catch (err) {
        console.error('Failed to sync scores with database', err);
      }
    }
  };

  // Render Engine (Canvas drawing)
  const renderGame = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, deltaTime: number) => {
    // Clear Canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Draw Camera Feed as mirrored background (If camera mode & active)
    if (inputMode === 'camera' && cameraActive && videoRef.current) {
      ctx.save();
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      ctx.restore();

      // Tint screen with cyber sci-fi dark filter
      ctx.fillStyle = 'rgba(10, 10, 15, 0.45)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    } else {
      // Offline grid pattern fallback background
      ctx.fillStyle = '#07070a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = '#12121e';
      ctx.lineWidth = 1;
      const step = 40;
      for (let x = 0; x < canvas.width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Static cyberpunk HUD circle background
      ctx.strokeStyle = 'rgba(189, 0, 255, 0.04)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, 150, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Draw scanning HUD boundary corners
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 2;
    // Top-Left corner
    ctx.beginPath(); ctx.moveTo(20, 40); ctx.lineTo(20, 20); ctx.lineTo(40, 20); ctx.stroke();
    // Top-Right corner
    ctx.beginPath(); ctx.moveTo(canvas.width - 20, 40); ctx.lineTo(canvas.width - 20, 20); ctx.lineTo(canvas.width - 40, 20); ctx.stroke();
    // Bottom-Left corner
    ctx.beginPath(); ctx.moveTo(20, canvas.height - 40); ctx.lineTo(20, canvas.height - 20); ctx.lineTo(40, canvas.height - 20); ctx.stroke();
    // Bottom-Right corner
    ctx.beginPath(); ctx.moveTo(canvas.width - 20, canvas.height - 40); ctx.lineTo(canvas.width - 20, canvas.height - 20); ctx.lineTo(canvas.width - 40, canvas.height - 20); ctx.stroke();

    // 2. Render and decay target stars
    const now = Date.now();
    const activeStars = starsRef.current;
    
    activeStars.forEach((star, index) => {
      const elapsed = now - star.spawnTime;
      const ratioLeft = Math.max(0, 1 - elapsed / star.lifetime);

      if (ratioLeft <= 0 && gameActive) {
        // Target expired. Play danger blip and generate new target
        if (star.type === 'decaying') {
          playSound('danger');
        }
        spawnStar();
        return;
      }

      // Draw star target
      const sx = (star.x / 100) * canvas.width;
      const sy = (star.y / 100) * canvas.height;
      const currentRadius = star.radius * (0.4 + 0.6 * ratioLeft); // pulse in scale on spawn

      // Draw outer cyber glow ring
      ctx.shadowBlur = 15;
      ctx.shadowColor = star.color;
      ctx.strokeStyle = star.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(sx, sy, currentRadius + 5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0; // reset shadow

      // Draw solid core
      ctx.fillStyle = star.color + (star.type === 'decaying' ? '55' : '22');
      ctx.beginPath();
      ctx.arc(sx, sy, currentRadius, 0, Math.PI * 2);
      ctx.fill();

      // Draw inner target symbol (Cyborg cross)
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(sx - currentRadius * 0.5, sy);
      ctx.lineTo(sx + currentRadius * 0.5, sy);
      ctx.moveTo(sx, sy - currentRadius * 0.5);
      ctx.lineTo(sx, sy + currentRadius * 0.5);
      ctx.stroke();

      // Draw timer countdown sector on the boundary
      if (gameActive) {
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(sx, sy, currentRadius + 8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * ratioLeft);
        ctx.stroke();
      }

      // Type descriptive HUD overlay
      ctx.fillStyle = star.color;
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      const label = star.type === 'golden' ? 'CRITICAL DOUBLE' : star.type === 'decaying' ? 'OVERLOAD FLUX' : 'TARGET';
      ctx.fillText(label, sx, sy - currentRadius - 15);
    });

    // 3. Render explosive hit particles
    const particles = hitParticlesRef.current;
    hitParticlesRef.current = particles.filter((p) => {
      p.life -= deltaTime * 0.003; // decay particle
      if (p.life <= 0) return false;

      // Drift physics
      const angle = Math.random() * Math.PI * 2;
      const speed = 50 * p.life;
      p.x += Math.cos(angle) * speed * (deltaTime / 1000);
      p.y += Math.sin(angle) * speed * (deltaTime / 1000);

      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.life;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3 * p.life, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1.0;
      return true;
    });

    // 4. Render Active Pointer crosshair & trails
    const cursor = pointerPosRef.current;

    // Outer Target Crosshair
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 1.5;
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#00f0ff';
    
    ctx.beginPath();
    // Circular bounds
    ctx.arc(cursor.x, cursor.y, 14, 0, Math.PI * 2);
    ctx.stroke();

    // Crosshair ticks
    ctx.beginPath();
    ctx.moveTo(cursor.x - 22, cursor.y); ctx.lineTo(cursor.x - 8, cursor.y);
    ctx.moveTo(cursor.x + 8, cursor.y); ctx.lineTo(cursor.x + 22, cursor.y);
    ctx.moveTo(cursor.x, cursor.y - 22); ctx.lineTo(cursor.x, cursor.y - 8);
    ctx.moveTo(cursor.x, cursor.y + 8); ctx.lineTo(cursor.x, cursor.y + 22);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Small glowing inner dot
    ctx.fillStyle = '#39ff14';
    ctx.beginPath();
    ctx.arc(cursor.x, cursor.y, 3, 0, Math.PI * 2);
    ctx.fill();

    // 5. HUD Stats Panel inside Canvas
    ctx.fillStyle = 'rgba(10, 10, 15, 0.7)';
    ctx.strokeStyle = '#1e1e2f';
    ctx.lineWidth = 1;
    ctx.fillRect(10, 10, 190, 40);
    ctx.strokeRect(10, 10, 190, 40);

    ctx.font = '10px monospace';
    ctx.fillStyle = '#8888aa';
    ctx.textAlign = 'left';
    ctx.fillText(`AIM RETICLE POS:`, 18, 25);
    ctx.fillStyle = '#00f0ff';
    ctx.fillText(`X:${Math.round(cursor.x)} Y:${Math.round(cursor.y)}`, 115, 25);

    ctx.fillStyle = '#8888aa';
    ctx.fillText(`INPUT DEVICE:`, 18, 38);
    ctx.fillStyle = inputMode === 'camera' ? '#39ff14' : '#bd00ff';
    ctx.fillText(inputMode === 'camera' ? 'AR NEURAL VISION' : 'TACTICAL POINTER', 100, 38);

    // If Camera mode, print detection state
    if (inputMode === 'camera') {
      ctx.fillStyle = 'rgba(10, 10, 15, 0.7)';
      ctx.fillRect(canvas.width - 150, 10, 140, 30);
      ctx.strokeRect(canvas.width - 150, 10, 140, 30);
      
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      if (handDetected) {
        ctx.fillStyle = '#39ff14';
        ctx.fillText('● TARGET DETECTED', canvas.width - 80, 28);
      } else {
        ctx.fillStyle = '#ff0055';
        ctx.fillText('▲ HAND SIGNAL SEARCH...', canvas.width - 80, 28);
      }
    }

    // 6. Game Over Score Overlay
    if (!gameActive && timeLeft === 0) {
      ctx.fillStyle = 'rgba(5, 5, 8, 0.85)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = 'bold 24px "Orbitron", sans-serif';
      ctx.fillStyle = '#00f0ff';
      ctx.textAlign = 'center';
      ctx.fillText('TRIALS COMPLETED', canvas.width / 2, canvas.height / 2 - 40);

      ctx.font = '14px monospace';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`COMBAT SCORE SCORE: ${score} PTS`, canvas.width / 2, canvas.height / 2);
      
      if (score >= personalBest && score > 0) {
        ctx.fillStyle = '#39ff14';
        ctx.font = 'bold 12px monospace';
        ctx.fillText('★ NEW PERSONAL BEST LOGGED IN VANGUARD!', canvas.width / 2, canvas.height / 2 + 30);
      } else {
        ctx.fillStyle = '#8888aa';
        ctx.fillText(`Current Personal Best: ${personalBest} PTS`, canvas.width / 2, canvas.height / 2 + 30);
      }

      ctx.font = '10px monospace';
      ctx.fillStyle = '#555577';
      ctx.fillText('PRESS INITIALIZE RUN TO LOG ANOTHER SCOUTING ENTRY', canvas.width / 2, canvas.height / 2 + 70);
    }
  };

  return (
    <div className="space-y-6" id="game-view-container">
      {/* Top Banner Status Bar */}
      <div className="bg-cyber-dark/90 border border-cyber-border p-4 rounded-lg flex flex-col md:flex-row items-center justify-between gap-4 backdrop-blur-md relative overflow-hidden" id="dashboard-hud-header">
        {/* User Identity info */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-sm bg-gradient-to-br from-neon-cyan to-neon-purple p-0.5 flex items-center justify-center font-display font-black text-black">
            VX
          </div>
          <div>
            <div className="text-xs text-slate-400 font-mono uppercase tracking-widest">RECRUIT FILE IN FOCUS:</div>
            <div className="font-display font-extrabold text-lg text-slate-100 tracking-wide flex items-center gap-2">
              {currentUser.ign}
              <span className="text-xs font-mono text-neon-cyan px-2 py-0.5 bg-neon-cyan/10 border border-neon-cyan/20 rounded uppercase">
                @{currentUser.username}
              </span>
            </div>
          </div>
        </div>

        {/* Global Stats values */}
        <div className="flex items-center gap-6" id="dashboard-scores">
          <div className="text-right">
            <div className="text-[10px] text-slate-500 font-mono uppercase">PERSONAL BEST</div>
            <div className="font-mono font-bold text-lg text-neon-cyan flex items-center justify-end gap-1">
              <Award className="w-4 h-4 text-neon-cyan" />
              {personalBest} <span className="text-xs text-slate-400">PTS</span>
            </div>
          </div>

          <div className="text-right border-l border-cyber-border pl-6">
            <div className="text-[10px] text-slate-500 font-mono uppercase">TOTAL ACCUMULATED</div>
            <div className="font-mono font-bold text-lg text-neon-green flex items-center justify-end gap-1">
              <Zap className="w-4 h-4 text-neon-green" />
              {accumulatedPoints} <span className="text-xs text-slate-400">PTS</span>
            </div>
          </div>
        </div>

        {/* Logout button */}
        <button
          onClick={() => {
            playSound('gameover');
            stopCameraAndTracking();
            onLogout();
          }}
          className="border border-neon-pink/40 hover:border-neon-pink bg-neon-pink/5 hover:bg-neon-pink/20 text-neon-pink text-xs font-mono py-2 px-4 rounded transition-all uppercase tracking-widest flex items-center gap-2 cursor-pointer"
          id="btn-logout"
        >
          <LogOut className="w-3.5 h-3.5" />
          Disconnect Panel
        </button>
      </div>

      {/* Main Game Interface Board */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6" id="game-arena-grid">
        {/* Left Side: Game Stage and controllers */}
        <div className="xl:col-span-8 flex flex-col items-center space-y-4" id="arena-col">
          {/* Controllers Card */}
          <div className="w-full bg-cyber-dark/80 border border-cyber-border p-4 rounded-lg flex flex-wrap items-center justify-between gap-4" id="arena-controllers">
            <div className="flex items-center gap-2">
              <h3 className="font-display font-bold text-sm uppercase tracking-wider text-slate-200">Reflex Trial Canvas</h3>
            </div>

            {/* Timed Mode Toggle */}
            <div className="flex items-center gap-3 bg-cyber-gray px-3 py-1.5 rounded border border-cyber-border text-xs font-mono">
              <span className="text-slate-400 uppercase">MODE:</span>
              <button
                onClick={() => { playSound('click'); setIsRoundMode(true); }}
                className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                  isRoundMode ? 'bg-neon-cyan text-black font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
                disabled={gameActive}
                id="btn-mode-timed"
              >
                30s SPEED TRIAL
              </button>
              <button
                onClick={() => { playSound('click'); setIsRoundMode(false); }}
                className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                  !isRoundMode ? 'bg-neon-cyan text-black font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
                disabled={gameActive}
                id="btn-mode-sandbox"
              >
                INFINI-SANDBOX
              </button>
            </div>

            {/* Input Selection controller */}
            <div className="flex items-center gap-1.5 p-1 bg-cyber-gray rounded border border-cyber-border" id="aim-method-selector">
              <button
                onClick={() => handleModeSwap('camera')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded transition-all cursor-pointer ${
                  inputMode === 'camera'
                    ? 'bg-gradient-to-r from-neon-green/30 to-neon-green/10 border border-neon-green/40 text-neon-green font-bold'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
                id="btn-switch-camera"
              >
                <Camera className="w-3.5 h-3.5" />
                AR WEBCAM AIM
              </button>

              <button
                onClick={() => handleModeSwap('pointer')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded transition-all cursor-pointer ${
                  inputMode === 'pointer'
                    ? 'bg-gradient-to-r from-neon-purple/30 to-neon-purple/10 border border-neon-purple/40 text-neon-purple font-bold'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
                id="btn-switch-pointer"
              >
                <MousePointerClick className="w-3.5 h-3.5" />
                TACTICAL MOUSE AIM
              </button>
            </div>
          </div>

          {/* Fallback Camera Access Warning */}
          {errorMessage && (
            <div className="w-full p-4 bg-neon-pink/15 border border-neon-pink/30 rounded text-xs font-mono text-neon-pink" id="camera-error-hud">
              {errorMessage}
            </div>
          )}

          {/* The Canvas Stage Container */}
          <div className="w-full bg-black border-2 border-cyber-border rounded-xl shadow-2xl relative overflow-hidden aspect-[4/3] max-w-2xl" id="canvas-stage-wrapper">
            {/* The canvas target draws the visual feeds */}
            <canvas
              ref={canvasRef}
              onMouseMove={handlePointerMove}
              className={`w-full h-full block cursor-none ${
                gameActive ? 'border-neon-cyan/10' : ''
              }`}
              id="reflex-canvas"
            />

            {/* Hidden Video element for MediaPipe feed */}
            <video
              ref={videoRef}
              className="absolute pointer-events-none opacity-0 left-0 top-0 w-0 h-0"
              playsInline
              muted
              id="mediapipe-video-source"
            />

            {/* Glassmorphism Loading Screen for AR */}
            {cameraLoading && (
              <div className="absolute inset-0 bg-cyber-dark/95 flex flex-col items-center justify-center space-y-4 p-6" id="loading-ar-overlay">
                <div className="w-12 h-12 border-4 border-t-neon-green border-r-transparent border-cyber-border rounded-full animate-spin" />
                <div className="text-center">
                  <p className="font-display font-bold text-sm text-neon-green uppercase tracking-widest">BOOTING NEURAL VISION ENGINE</p>
                  <p className="text-[10px] text-slate-500 font-mono uppercase mt-1">Downloading tracking files & initializing handpose sensors...</p>
                </div>
              </div>
            )}

            {/* Pre-Game Start HUD HUD Overlay */}
            {!gameActive && (
              <div className="absolute inset-0 bg-[#050505]/95 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center space-y-6 border-4 border-neon-cyan/20 rounded-xl" id="pre-game-overlay">
                <div className="space-y-2">
                  <h3 className="font-display font-black text-3xl text-slate-100 tracking-tighter italic uppercase">
                    VANGUARD TRIALS <br />
                    <span className="text-neon-cyan neon-text-cyan text-4xl">// READY TO LAUNCH</span>
                  </h3>
                  <p className="text-xs text-slate-400 max-w-sm font-mono uppercase tracking-wider">
                    {inputMode === 'camera' 
                      ? 'Ensure your webcam has sufficient light. Aim with your INDEX FINGER TIP and align with targeted stars.'
                      : 'Use your tactical mouse pointer to sweep and destroy star coordinates with micro-precision mechanics.'}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 w-full max-w-xs justify-center">
                  <button
                    onClick={startGame}
                    className="flex-1 bg-gradient-to-r from-neon-cyan to-neon-purple hover:from-neon-cyan/80 hover:to-neon-purple/80 text-black font-display font-extrabold uppercase py-3 px-6 rounded tracking-wider transition-all shadow-[0_0_15px_rgba(0,240,255,0.3)] flex items-center justify-center gap-2 cursor-pointer"
                    id="btn-launch-trial"
                  >
                    <Play className="w-4 h-4 fill-black" />
                    INITIALIZE RUN
                  </button>
                </div>
              </div>
            )}

            {/* In-Game Active UI HUD (Top overlays) */}
            {gameActive && (
              <div className="absolute top-4 left-4 right-4 pointer-events-none flex items-center justify-between" id="active-game-overlay">
                {/* Active score count */}
                <div className="bg-cyber-dark/90 border border-cyber-border px-3 py-1.5 rounded font-mono text-xs text-slate-300 shadow flex items-center gap-2">
                  <Crosshair className="w-3.5 h-3.5 text-neon-cyan animate-spin" />
                  <span>TARGET RUN SCORE:</span>
                  <span className="text-neon-cyan font-bold text-sm">{score} PTS</span>
                </div>

                {/* Active countdown or status indicator */}
                {isRoundMode ? (
                  <div className={`bg-cyber-dark/90 border px-3 py-1.5 rounded font-mono text-xs shadow flex items-center gap-2 ${
                    timeLeft <= 6 ? 'border-neon-pink/60 text-neon-pink animate-pulse' : 'border-cyber-border text-slate-300'
                  }`}>
                    <span>TIME REMAINING:</span>
                    <span className="font-bold text-sm">{timeLeft}s</span>
                  </div>
                ) : (
                  <div className="bg-cyber-dark/90 border border-neon-green/30 px-3 py-1.5 rounded font-mono text-xs text-neon-green shadow flex items-center gap-2 animate-pulse">
                    <span>SANDBOX TRAINING: ACTIVE</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Quick Trial Instructions Details */}
          <div className="w-full max-w-2xl bg-cyber-dark/50 border border-cyber-border p-4 rounded-lg space-y-3" id="hud-instructions-box">
            <h4 className="font-display font-bold text-xs uppercase tracking-widest text-slate-300 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-neon-cyan" /> COMBAT TARGET SCHEMATICS:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="flex items-center gap-2 p-2 bg-cyber-gray/30 border border-cyber-border rounded">
                <span className="w-3 h-3 rounded-full bg-neon-cyan shadow-[0_0_8px_rgba(0,240,255,0.4)]" />
                <div>
                  <div className="text-slate-200">STANDARD NODES</div>
                  <div className="text-[10px] text-slate-500">+10 PTS | 6s LIFE</div>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 bg-cyber-gray/30 border border-cyber-border rounded">
                <span className="w-3 h-3 rounded-full bg-yellow-400 shadow-[0_0_8px_rgba(250,204,21,0.4)] animate-pulse" />
                <div>
                  <div className="text-slate-200">GOLDEN MULTIPLIER</div>
                  <div className="text-[10px] text-slate-500">+20 PTS | 4.5s LIFE</div>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 bg-cyber-gray/30 border border-cyber-border rounded">
                <span className="w-3 h-3 rounded-full bg-neon-pink shadow-[0_0_8px_rgba(255,0,85,0.4)]" />
                <div>
                  <div className="text-slate-200">OVERLOAD FLUX</div>
                  <div className="text-[10px] text-slate-500">+15 PTS | FAST DECAY</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Pro Player Leaderboard Rankings */}
        <div className="xl:col-span-4" id="ranking-aside-panel">
          <div className="sticky top-4 space-y-4">
            <div className="bg-cyber-gray/30 border border-cyber-border p-4 rounded-lg flex flex-col justify-center space-y-2 text-center" id="aimlab-badge">
              <Sparkles className="w-6 h-6 text-neon-cyan mx-auto animate-pulse" />
              <div className="font-display font-bold text-sm text-slate-200 uppercase tracking-wider">AIMLAB SCOUTING PROGRAM</div>
              <p className="text-[10px] font-mono text-slate-500 leading-normal uppercase">
                Scores &gt; 120 trigger elite reserve recruitment notifications directly to head coaching nodes.
              </p>
            </div>
            
            {/* Live Standings Panel */}
            <div className="w-full">
              {/* Fallback to show leaderboards inside this page view */}
              <div className="bg-cyber-dark/40 border border-cyber-border rounded-lg p-2 text-xs font-mono text-center text-slate-500 uppercase">
                VANGUARD SECURE DATABASE LINKED IN REAL TIME
              </div>
              <div className="mt-2 text-left">
                {/* Embedded ranking component */}
                <RankingEmbed />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Embedded simple ranking panel to keep it fast
function RankingEmbed() {
  const [leaderboard, setLeaderboard] = useState<EEsportsUser[]>([]);

  const loadLeaderboard = () => {
    const storedUsersString = localStorage.getItem('nexus_vanguard_users');
    let usersList: EEsportsUser[] = [];

    if (storedUsersString) {
      try {
        usersList = JSON.parse(storedUsersString);
      } catch (e) {
        console.error('Failed to parse users', e);
      }
    }

    const defaultBots: EEsportsUser[] = [
      { ign: 'V1per_Shroud', username: 'viper', passwordHash: '123', highScore: 320, totalScore: 1250 },
      { ign: 'Neo_Faker', username: 'faker', passwordHash: '123', highScore: 290, totalScore: 1100 },
      { ign: 'S1mple_Acolyte', username: 's1mple', passwordHash: '123', highScore: 250, totalScore: 980 },
      { ign: 'Ghost_Aim', username: 'ghost', passwordHash: '123', highScore: 180, totalScore: 640 },
      { ign: 'Zero_Ping', username: 'ping', passwordHash: '123', highScore: 150, totalScore: 450 },
    ];

    const combined: EEsportsUser[] = [...usersList];
    defaultBots.forEach((bot) => {
      const exists = combined.some((u) => u.username === bot.username || u.ign.toLowerCase() === bot.ign.toLowerCase());
      if (!exists) {
        combined.push(bot);
      }
    });

    combined.sort((a, b) => b.highScore - a.highScore);
    setLeaderboard(combined);
  };

  useEffect(() => {
    loadLeaderboard();
    window.addEventListener('scoreUpdated', loadLeaderboard);
    return () => {
      window.removeEventListener('scoreUpdated', loadLeaderboard);
    };
  }, []);

  return (
    <div className="bg-cyber-dark/80 border border-cyber-border rounded-lg p-5">
      <div className="flex items-center gap-2 mb-4">
        <Award className="w-5 h-5 text-neon-cyan" />
        <h3 className="font-display font-bold text-sm tracking-wider text-slate-100 uppercase">Live Leaderboard</h3>
      </div>
      <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
        {leaderboard.map((user, idx) => (
          <div key={user.username} className="flex items-center justify-between p-2 rounded bg-cyber-gray/30 border border-cyber-border text-xs">
            <div className="flex items-center gap-2">
              <span className={`w-5 h-5 rounded-full flex items-center justify-center font-display font-bold ${
                idx === 0 ? 'bg-neon-cyan text-black' : idx === 1 ? 'bg-neon-purple text-white' : idx === 2 ? 'bg-neon-pink text-white' : 'bg-cyber-border text-slate-500'
              }`}>
                {idx + 1}
              </span>
              <span className="font-bold text-slate-200">{user.ign}</span>
            </div>
            <span className="font-mono text-neon-green font-bold">{user.highScore} PTS</span>
          </div>
        ))}
      </div>
    </div>
  );
}

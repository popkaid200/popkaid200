import { useState, useEffect } from 'react';
import { ShieldCheck, Cpu, Terminal, Radio, Gamepad2 } from 'lucide-react';
import HomeView from './components/HomeView';
import RegisterView from './components/RegisterView';
import GameView from './components/GameView';
import Leaderboard from './components/Leaderboard';
import { ViewState, EEsportsUser } from './types';
import { playSound } from './utils/audio';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [currentUser, setCurrentUser] = useState<EEsportsUser | null>(null);
  const [systemTime, setSystemTime] = useState('');

  // Track system clock in a high-tech format
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setSystemTime(
        now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Sync user state with active local storage updates
  const handleUpdateUserStats = (updatedUser: EEsportsUser) => {
    setCurrentUser(updatedUser);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('home');
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-neon-cyan selection:text-black bg-[#050505] text-[#E0E0E0] font-sans border-4 border-[#1A1A1A]">
      {/* Bold Typography Custom Header */}
      <header className="h-20 border-b border-neon-cyan/30 flex items-center justify-between px-4 sm:px-8 bg-gradient-to-r from-[#0A0A0A] to-[#121212] sticky top-0 z-50" id="master-header">
        <div 
          className="flex items-center gap-4 cursor-pointer" 
          onClick={() => { playSound('click'); setCurrentView('home'); }}
          id="brand-logo"
        >
          {/* Custom Rotated Geometric Logo from Design Theme */}
          <div className="w-10 h-10 bg-neon-cyan rotate-45 flex items-center justify-center transition-transform hover:scale-115 duration-300">
            <div className="w-6 h-6 bg-[#050505] rotate-45" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tighter italic text-neon-cyan">
              NEXUS VANGUARD <span className="text-neon-purple">//</span> RECRUIT
            </h1>
            <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest leading-none">
              TRIAL_MATRIX_RUN
            </div>
          </div>
        </div>

        {/* System telemetry data display */}
        <div className="hidden lg:flex items-center gap-8 text-[11px] font-mono text-slate-400" id="header-telemetry">
          <div className="flex flex-col">
            <span className="text-[9px] uppercase tracking-widest text-neon-cyan/60 font-bold">Beacon Signal</span>
            <span className="text-xs font-bold text-neon-green tracking-tight">ACTIVE // STABLE</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] uppercase tracking-widest text-neon-purple/60 font-bold">Engine Kernel</span>
            <span className="text-xs font-bold text-slate-100 tracking-tight">MEDIAPIPE_H_V5</span>
          </div>
          <div className="flex items-center gap-1.5 bg-[#111] border border-white/5 px-3 py-1.5 rounded">
            <Terminal className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-300 font-bold">{systemTime}</span>
          </div>
        </div>

        {/* Right side Profile display in header */}
        <div className="flex items-center gap-3">
          {currentUser ? (
            <div className="flex items-center gap-3" id="header-user-status">
              <div className="text-right">
                <div className="text-[9px] uppercase tracking-widest text-neon-cyan/60 font-black">Recruit Active</div>
                <div className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">{currentUser.ign}</div>
              </div>
              <div className="w-10 h-10 rounded-full border-2 border-neon-purple p-0.5 animate-pulse">
                <div className="w-full h-full rounded-full bg-gradient-to-tr from-neon-purple to-neon-cyan" />
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-neon-pink/10 border border-neon-pink/30 rounded" id="header-guest-status">
              <span className="w-2 h-2 rounded-full bg-neon-pink animate-ping shrink-0" />
              <span className="text-[10px] font-mono text-neon-pink font-bold uppercase tracking-widest">
                UNAUTHORIZED DECK
              </span>
            </div>
          )}
        </div>
      </header>

      {/* Main Grid Viewport */}
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 py-8" id="master-viewport">
        {currentView === 'game' && currentUser ? (
          /* Page 3: Active AR trials viewport (takes full widescreen layout) */
          <div className="animate-fade-in" id="game-view-wrapper">
            <GameView 
              currentUser={currentUser}
              onLogout={handleLogout}
              onUpdateUserStats={handleUpdateUserStats}
            />
          </div>
        ) : (
          /* Pages 1 & 2: Landing page split grid layout (form on left, live leaderboard ranking stats on right) */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="auth-panel-grid">
            {/* Primary functional widget (Home Login or Register Form) */}
            <div className="lg:col-span-8 space-y-6">
              {currentView === 'home' && (
                <div className="animate-fade-in" id="home-view-wrapper">
                  <HomeView 
                    onNavigate={(view) => setCurrentView(view)}
                    onLoginSuccess={(user) => setCurrentUser(user)}
                  />
                </div>
              )}
              {currentView === 'register' && (
                <div className="animate-fade-in" id="register-view-wrapper">
                  <RegisterView onNavigate={(view) => setCurrentView(view)} />
                </div>
              )}
            </div>

            {/* Desktop Side Leaderboard display */}
            <div className="lg:col-span-4 lg:sticky lg:top-24" id="ranking-panel-wrapper">
              <Leaderboard />
            </div>
          </div>
        )}
      </main>

      {/* Footer copyright */}
      <footer className="border-t border-cyber-border bg-black py-6 text-center text-xs font-mono text-slate-500" id="master-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-neon-cyan" />
            <span>NEXUS VANGUARD © 2026. ALL SECTOR RIGHTS SIGNALS PERSISTED.</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="hover:text-neon-cyan transition-all cursor-pointer">SECURE ARCHITECTURE</span>
            <span className="text-slate-800">|</span>
            <span className="hover:text-neon-purple transition-all cursor-pointer">SCOUTING CHARTER</span>
          </div>
        </div>
      </footer>
    </div>
  );
}


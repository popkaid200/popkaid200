<?php
// Database configuration for XAMPP (MySQL)
$host = 'localhost';
$db   = 'nexus_vanguard';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // FALLBACK FOR PREVIEW / DEMO MODE
    // In our container/preview environment, we use SQLite or a local file so the app remains fully functional!
    $sqlite_file = __DIR__ . '/nexus_vanguard.sqlite';
    try {
        $pdo = new PDO("sqlite:$sqlite_file");
        // Create tables if they don't exist in SQLite
        $pdo->exec("CREATE TABLE IF NOT EXISTS recruits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ign TEXT UNIQUE,
            email TEXT UNIQUE,
            role TEXT,
            skill_level TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recruit_id INTEGER,
            score INTEGER,
            input_mode TEXT,
            accuracy REAL,
            played_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (recruit_id) REFERENCES recruits(id)
        )");
    } catch (\PDOException $se) {
        die("Connection failed: " . $e->getMessage() . " | Fallback SQLite failed: " . $se->getMessage());
    }
}
?>

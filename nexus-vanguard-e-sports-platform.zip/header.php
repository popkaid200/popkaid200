<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_user = isset($_SESSION['user']) ? $_SESSION['user'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexus Vanguard | E-Sports Recruitment & AR Trials</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@500;600;700&family=JetBrains+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        display: ['Orbitron', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        'neon-cyan': '#00F3FF',
                        'neon-purple': '#BC00FF',
                        'neon-green': '#39ff14',
                        'neon-pink': '#ff0055',
                        'cyber-dark': '#050505',
                        'cyber-gray': '#111111',
                        'cyber-border': '#1A1A1A',
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background-color: #050505;
            color: #E0E0E0;
            background-image: 
              linear-gradient(rgba(26, 26, 26, 0.5) 1px, transparent 1px),
              linear-gradient(90deg, rgba(26, 26, 26, 0.5) 1px, transparent 1px);
            background-size: 30px 30px;
        }
        .neon-text-cyan {
            text-shadow: 0 0 8px rgba(0, 243, 255, 0.75), 0 0 20px rgba(0, 243, 255, 0.4);
        }
        .neon-border-cyan {
            box-shadow: 0 0 15px rgba(0, 243, 255, 0.35), inset 0 0 8px rgba(0, 243, 255, 0.2);
            border-color: #00F3FF;
        }
        .corner-border {
            position: relative;
        }
        .corner-border::before, .corner-border::after {
            content: "";
            position: absolute;
            width: 16px;
            height: 16px;
            border-color: #00F3FF;
            border-style: solid;
            pointer-events: none;
        }
        .corner-border::before {
            top: -2px;
            left: -2px;
            border-width: 3px 0 0 3px;
        }
        .corner-border::after {
            bottom: -2px;
            right: -2px;
            border-width: 0 3px 3px 0;
        }
    </style>
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- MediaPipe Hands & Camera Utilities for AR tracking -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>
</head>
<body class="min-h-screen flex flex-col font-sans">
    <header class="h-20 border-b border-neon-cyan/30 flex items-center justify-between px-4 sm:px-8 bg-gradient-to-r from-[#0A0A0A] to-[#121212] sticky top-0 z-50">
        <a href="index.php" class="flex items-center gap-4 cursor-pointer">
            <div class="w-10 h-10 bg-neon-cyan rotate-45 flex items-center justify-center transition-transform hover:scale-110 duration-300">
                <div class="w-6 h-6 bg-[#050505] rotate-45"></div>
            </div>
            <div>
                <h1 class="text-xl sm:text-2xl font-black tracking-tighter italic text-neon-cyan uppercase">
                    NEXUS VANGUARD <span class="text-neon-purple">//</span> RECRUIT
                </h1>
                <div class="text-[10px] font-mono text-slate-500 uppercase tracking-widest leading-none">
                    TRIAL_MATRIX_RUN
                </div>
            </div>
        </a>

        <div class="hidden lg:flex items-center gap-8 text-[11px] font-mono text-slate-400">
            <div class="flex flex-col">
                <span class="text-[9px] uppercase tracking-widest text-neon-cyan/60 font-bold">Beacon Signal</span>
                <span class="text-xs font-bold text-neon-green tracking-tight">ACTIVE // STABLE</span>
            </div>
            <div class="flex flex-col">
                <span class="text-[9px] uppercase tracking-widest text-neon-purple/60 font-bold">Engine Kernel</span>
                <span class="text-xs font-bold text-slate-100 tracking-tight">MEDIAPIPE_H_V5</span>
            </div>
            <div class="flex items-center gap-1.5 bg-[#111] border border-white/5 px-3 py-1.5 rounded">
                <i data-lucide="terminal" class="w-3.5 h-3.5 text-slate-500"></i>
                <span class="text-slate-300 font-bold" id="live-time-display"><?php echo date('Y-m-d H:i:s'); ?> UTC</span>
            </div>
        </div>

        <div class="flex items-center gap-4">
            <?php if ($current_user): ?>
                <div class="flex items-center gap-3">
                    <div class="text-right">
                        <div class="text-[9px] uppercase tracking-widest text-neon-cyan/60 font-black">Recruit Active</div>
                        <div class="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider"><?php echo htmlspecialchars($current_user['ign']); ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-full border-2 border-neon-purple p-0.5 animate-pulse relative group cursor-pointer">
                        <div class="w-full h-full rounded-full bg-gradient-to-tr from-neon-purple to-neon-cyan"></div>
                        <!-- Logout menu -->
                        <div class="absolute right-0 top-12 hidden group-hover:block bg-cyber-dark border border-neon-cyan/30 rounded shadow-lg p-2 min-w-[120px] z-50">
                            <a href="logout.php" class="block w-full text-left px-3 py-1.5 text-xs font-mono hover:bg-neon-pink/20 hover:text-white rounded text-slate-300 transition-colors">
                                <i data-lucide="log-out" class="inline w-3 h-3 mr-1"></i> LOGOUT
                            </a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="flex items-center gap-2 px-3 py-1.5 bg-neon-pink/10 border border-neon-pink/30 rounded">
                    <span class="w-2 h-2 rounded-full bg-neon-pink animate-ping shrink-0"></span>
                    <span class="text-[10px] font-mono text-neon-pink font-bold uppercase tracking-widest">
                        UNAUTHORIZED DECK
                    </span>
                </div>
            <?php endif; ?>
        </div>
    </header>
